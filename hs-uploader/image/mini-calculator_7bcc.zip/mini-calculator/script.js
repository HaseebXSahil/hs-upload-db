/* ============================================
   ✨ MINI CALCULATOR — Logic & Interactions
   ============================================ */

(function () {
  'use strict';

  const expressionEl = document.getElementById('expression');
  const resultEl     = document.getElementById('result');
  const keypad        = document.querySelector('.keypad');

  // State
  let expression = '';      // raw expression like "12+8*3"
  let lastResult = null;    // numeric last result
  let justEvaluated = false; // true right after '=' was pressed

  const OP_MAP = { '+': '+', '-': '-', '*': '×', '/': '÷' };
  const OP_REVERSE = { '×': '*', '÷': '/' };

  /* ---------- Rendering ---------- */
  function prettyExpr(raw) {
    // Convert internal operators to pretty symbols for display
    let out = '';
    for (const ch of raw) {
      if (ch === '*') out += '×';
      else if (ch === '/') out += '÷';
      else out += ch;
    }
    return out || '0';
  }

  function render() {
    expressionEl.textContent = expression ? prettyExpr(expression) : '0';

    // Live preview result
    const preview = safeEval(expression);
    if (preview === null) {
      if (expression === '') {
        resultEl.textContent = lastResult !== null ? formatNum(lastResult) : '0';
        resultEl.classList.remove('error');
      } else {
        // Don't show preview while typing invalid/partial — keep last shown
        resultEl.textContent = formatNum(lastResult !== null ? lastResult : 0);
        resultEl.classList.remove('error');
      }
    } else {
      resultEl.textContent = formatNum(preview);
      resultEl.classList.remove('error');
    }
  }

  function showError(msg) {
    resultEl.textContent = msg;
    resultEl.classList.add('error');
  }

  /* ---------- Number formatting ---------- */
  function formatNum(n) {
    if (n === null || n === undefined || Number.isNaN(n)) return 'Error';
    if (!isFinite(n)) return '∞';

    // Round to avoid float artifacts (e.g. 0.1 + 0.2)
    const rounded = Math.round((n + Number.EPSILON) * 1e10) / 1e10;

    // Trim trailing zeros from decimals
    let str = String(rounded);
    if (str.includes('.')) {
      str = str.replace(/\.?0+$/, '');
    }
    return str;
  }

  /* ---------- Safe evaluator ---------- */
  // Allows only digits, + - * / . and parentheses-free math.
  function safeEval(expr) {
    if (!expr) return null;
    if (!/^-?\d+(\.\d+)?([+\-*/]\d+(\.\d+)?)*$/.test(expr)) return null;
    try {
      // Use Function constructor (safer than eval) — only numbers/operators pass the regex above
      // eslint-disable-next-line no-new-func
      const val = Function('"use strict"; return (' + expr + ')')();
      if (typeof val !== 'number' || !isFinite(val)) return null;
      return val;
    } catch (e) {
      return null;
    }
  }

  /* ---------- Input handlers ---------- */
  function inputNumber(value) {
    if (justEvaluated) {
      // Start fresh expression after '='
      expression = '';
      justEvaluated = false;
    }
    // Avoid leading zeros like "00" -> "0"
    // Find current number segment
    const segments = expression.split(/[+\-*/]/);
    const current = segments[segments.length - 1];

    if (value === '0' && current === '0') return; // ignore extra leading zeros

    // Replace lone '0' with new digit
    if (current === '0' && value !== '.') {
      expression = expression.slice(0, -1) + value;
    } else {
      expression += value;
    }
    render();
  }

  function inputDot() {
    if (justEvaluated) {
      expression = '';
      justEvaluated = false;
    }
    const segments = expression.split(/[+\-*/]/);
    const current = segments[segments.length - 1];

    // Only one decimal per number segment
    if (current.includes('.')) return;

    // If empty or just an operator, prepend 0
    if (current === '' || /[+\-*/]$/.test(expression)) {
      expression += '0.';
    } else {
      expression += '.';
    }
    render();
  }

  function inputOperator(op) {
    justEvaluated = false;
    if (expression === '') {
      // Allow negative sign at start
      if (op === '-') {
        expression = '-';
        render();
      }
      return;
    }

    // If last char is operator, replace it
    if (/[+\-*/]$/.test(expression)) {
      // Don't allow replacing '-' with another op if expression is just '-'
      if (expression === '-' && op !== '-') return;
      expression = expression.slice(0, -1) + op;
    } else {
      expression += op;
    }
    render();
  }

  function calculate() {
    if (!expression) {
      if (lastResult !== null) {
        // Just re-display last result; nothing to compute
        resultEl.textContent = formatNum(lastResult);
      }
      return;
    }

    // Handle division by zero explicitly
    if (/\/0(?!\.\d*[1-9])/.test(expression)) {
      showError('Cannot divide by 0');
      expression = '';
      lastResult = null;
      justEvaluated = true;
      return;
    }

    const val = safeEval(expression);
    if (val === null) {
      showError('Error');
      expression = '';
      lastResult = null;
      justEvaluated = true;
      return;
    }

    lastResult = val;
    resultEl.textContent = formatNum(val);
    resultEl.classList.remove('error');
    // Update expression display to show the evaluated form
    expressionEl.textContent = prettyExpr(expression) + ' =';
    expression = formatNum(val);
    justEvaluated = true;
  }

  function clearAll() {
    expression = '';
    lastResult = null;
    justEvaluated = false;
    render();
  }

  function backspace() {
    if (justEvaluated) {
      // After '=', backspace clears (acts like reset)
      clearAll();
      return;
    }
    expression = expression.slice(0, -1);
    render();
  }

  /* ---------- Click / tap dispatch ---------- */
  function handleAction(action, value) {
    switch (action) {
      case 'num':     inputNumber(value); break;
      case 'dot':     inputDot(); break;
      case 'op':      inputOperator(value); break;
      case 'equals':  calculate(); break;
      case 'clear':   clearAll(); break;
      case 'backspace': backspace(); break;
    }
  }

  keypad.addEventListener('click', function (e) {
    const btn = e.target.closest('button.btn');
    if (!btn) return;
    const action = btn.dataset.action;
    const value  = btn.dataset.value;
    handleAction(action, value);
    // Visual feedback
    btn.classList.add('pressed');
    setTimeout(() => btn.classList.remove('pressed'), 90);
  });

  /* ---------- Keyboard support ---------- */
  const KEY_TO_BTN = {
    '0': 'button[data-value="0"]',
    '1': 'button[data-value="1"]',
    '2': 'button[data-value="2"]',
    '3': 'button[data-value="3"]',
    '4': 'button[data-value="4"]',
    '5': 'button[data-value="5"]',
    '6': 'button[data-value="6"]',
    '7': 'button[data-value="7"]',
    '8': 'button[data-value="8"]',
    '9': 'button[data-value="9"]',
    '.': 'button[data-action="dot"]',
    '+': 'button[data-value="+"]',
    '-': 'button[data-value="-"]',
    '*': 'button[data-value="*"]',
    '/': 'button[data-value="/"]',
    'Enter': 'button[data-action="equals"]',
    '=': 'button[data-action="equals"]',
    'Backspace': 'button[data-action="backspace"]',
    'Escape': 'button[data-action="clear"]',
    'c': 'button[data-action="clear"]',
    'C': 'button[data-action="clear"]'
  };

  function flashButton(selector) {
    if (!selector) return;
    const btn = document.querySelector(selector);
    if (!btn) return;
    btn.classList.add('pressed');
    setTimeout(() => btn.classList.remove('pressed'), 90);
  }

  document.addEventListener('keydown', function (e) {
    // Prevent default scrolling on space/etc. — we don't use space though
    const key = e.key;

    if (key === 'Enter' || key === '=') {
      e.preventDefault();
      calculate();
      flashButton('button[data-action="equals"]');
      return;
    }

    if (key === 'Backspace') {
      e.preventDefault();
      backspace();
      flashButton('button[data-action="backspace"]');
      return;
    }

    if (key === 'Escape' || key === 'c' || key === 'C') {
      e.preventDefault();
      clearAll();
      flashButton('button[data-action="clear"]');
      return;
    }

    // Numbers
    if (/^[0-9]$/.test(key)) {
      inputNumber(key);
      flashButton(`button[data-value="${key}"]`);
      return;
    }

    // Dot
    if (key === '.') {
      inputDot();
      flashButton('button[data-action="dot"]');
      return;
    }

    // Operators
    if (key === '+' || key === '-' || key === '*' || key === '/') {
      e.preventDefault();
      inputOperator(key);
      flashButton(`button[data-value="${key}"]`);
      return;
    }
  });

  /* ---------- Initialize ---------- */
  render();

  // Prevent double-tap zoom on iOS for buttons
  document.addEventListener('dblclick', function (e) {
    e.preventDefault();
  }, { passive: false });

})();
