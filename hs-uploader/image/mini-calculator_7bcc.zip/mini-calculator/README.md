# ✨ Mini Calculator ✨

A clean, glossy, mobile-friendly calculator built with **HTML + CSS + JavaScript**.

## 🎨 Theme
- Classic Black / Starry ✨
- Dark charcoal calculator body
- Silver/white accents
- Twinkling stars in the background
- Glossy button highlights

## ✨ Features
- ➕ Addition
- ➖ Subtraction
- ✖️ Multiplication
- ➗ Division
- 🟰 Calculate (=)
- 🔄 Clear / Reset
- ⌫ Backspace
- ⌨️ Full keyboard support
- 🧮 Live calculation preview
- ⚠️ Error handling (e.g. division by zero)
- 📱 Responsive mobile-first layout
- ✨ Star/emoji decorations

## ⌨️ Keyboard Shortcuts
| Key            | Action          |
|----------------|-----------------|
| `0`–`9`        | Enter number    |
| `.`            | Decimal point   |
| `+ - * /`      | Operators       |
| `Enter` / `=`  | Calculate       |
| `Backspace`    | Delete last     |
| `Esc` / `c`    | Clear all       |

## 📦 How to Use
1. Unzip the file.
2. Open `index.html` in any modern browser (Chrome, Safari, Firefox, Edge).
3. No build step, no server required — fully offline.

## 📱 Mobile Installation (PWA-style, no install needed)
1. Open `index.html` in your phone's browser.
2. Use browser menu → **"Add to Home Screen"**.
3. Launch like a native app.

## 📁 File Structure
```
mini-calculator/
├── index.html      # Markup
├── styles.css      # Theme + responsive styles
├── script.js       # Calculator logic + keyboard support
└── README.md       # This file
```

## 🎨 Color Palette
| Element              | Color       |
|----------------------|-------------|
| Background           | `#000000`   |
| Calculator body      | `#1a1a1a`   |
| Text                 | `#ffffff`   |
| Buttons              | `#2a2a2a`   |
| Borders/highlights   | `#c0c0c0` (subtle) |
| Star accents         | `#ffd700`   |

---
Made with ✨ — enjoy calculating!
