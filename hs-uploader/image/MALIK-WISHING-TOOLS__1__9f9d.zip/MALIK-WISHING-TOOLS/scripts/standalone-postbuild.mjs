#!/usr/bin/env node
/**
 * MALIK WISHING TOOLS — standalone post-build helper
 * --------------------------------------------------
 * With `output: "standalone"` (local / VPS / Docker), Next.js produces a
 * minimal server in .next/standalone — but static assets and public files
 * must be copied in manually. On Netlify the standalone output is disabled
 * (NETLIFY=1), so this script simply does nothing.
 */

import fs from "node:fs";
import path from "node:path";
import { cpSync } from "node:fs";

const nextDir = path.join(process.cwd(), ".next");
const standaloneDir = path.join(nextDir, "standalone");

if (process.env.NETLIFY) {
  console.log("[postbuild] Netlify deploy detected — skipping standalone packaging.");
  process.exit(0);
}

if (!fs.existsSync(standaloneDir)) {
  console.log("[postbuild] No standalone output found — skipping.");
  process.exit(0);
}

const staticSrc = path.join(nextDir, "static");
const staticDst = path.join(standaloneDir, ".next", "static");
if (fs.existsSync(staticSrc) && !fs.existsSync(staticDst)) {
  cpSync(staticSrc, staticDst, { recursive: true });
  console.log("[postbuild] Copied .next/static -> standalone");
}

const publicSrc = path.join(process.cwd(), "public");
const publicDst = path.join(standaloneDir, "public");
if (fs.existsSync(publicSrc) && !fs.existsSync(publicDst)) {
  cpSync(publicSrc, publicDst, { recursive: true });
  console.log("[postbuild] Copied public -> standalone");
}

console.log("[postbuild] Standalone server ready: node .next/standalone/server.js");
