#!/usr/bin/env node
/**
 * MALIK WISHING TOOLS — Prisma provider auto-sync
 * ------------------------------------------------
 * Keeps prisma/schema.prisma in sync with DATABASE_URL:
 *   - postgres:// / postgresql://  ->  provider "postgresql" (Neon, Supabase, RDS…)
 *   - file:...  or nothing          ->  provider "sqlite" (zero-config local)
 *
 * This lets the SAME project run locally with SQLite out of the box and on
 * Netlify / Vercel with Neon PostgreSQL, without hand-editing the schema.
 * The script is idempotent and safe to run on every install/build.
 */

import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const schemaPath = path.join(root, "prisma", "schema.prisma");

// ---------- read DATABASE_URL (env first, then .env file) ----------
function readEnvFile(file) {
  try {
    const raw = fs.readFileSync(file, "utf8");
    const out = {};
    for (const line of raw.split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let v = m[2].trim();
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
        v = v.slice(1, -1);
      }
      out[m[1]] = v;
    }
    return out;
  } catch {
    return {};
  }
}

let url = process.env.DATABASE_URL;
if (!url) {
  const fromFile = readEnvFile(path.join(root, ".env"));
  url = fromFile.DATABASE_URL;
}

const isPostgres = typeof url === "string" && /^postgres(ql)?:\/\//i.test(url.trim());

// ---------- rewrite schema.prisma ----------
if (!fs.existsSync(schemaPath)) {
  console.error("[db-provider] prisma/schema.prisma not found — nothing to sync.");
  process.exit(0);
}

let schema = fs.readFileSync(schemaPath, "utf8");
const original = schema;

// Replace the datasource block wholesale (handles both sqlite and postgres variants)
const datasourceRegex = /datasource\s+db\s*\{[\s\S]*?\n\}/;
const newDatasource = isPostgres
  ? [
      "datasource db {",
      '  provider = "postgresql"',
      '  url      = env("DATABASE_URL")',
      "}",
    ].join("\n")
  : [
      "datasource db {",
      '  provider = "sqlite"',
      '  url      = env("DATABASE_URL")',
      "}",
    ].join("\n");

if (datasourceRegex.test(schema)) {
  schema = schema.replace(datasourceRegex, newDatasource);
} else {
  console.error("[db-provider] Could not locate datasource block in schema.prisma.");
  process.exit(1);
}

if (schema !== original) {
  fs.writeFileSync(schemaPath, schema);
  console.log(`[db-provider] schema.prisma provider -> ${isPostgres ? "postgresql" : "sqlite"}`);
} else {
  console.log(`[db-provider] schema.prisma already uses ${isPostgres ? "postgresql" : "sqlite"}`);
}
