#!/usr/bin/env node
/**
 * MALIK WISHING TOOLS — database schema sync for deploys
 * ------------------------------------------------------
 * When DATABASE_URL points at PostgreSQL/Neon (Netlify, Vercel, any host),
 * runs `prisma db push --skip-generate` so the tables exist before the app
 * serves traffic. For SQLite (local) this is skipped — the database file
 * ships with the project and `npm run setup` manages it.
 */

import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();

function readEnvFile(file) {
  try {
    const raw = fs.readFileSync(file, "utf8");
    const out = {};
    for (const line of raw.split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let v = m[2].trim();
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
        v = v.slice(1, -1);
      }
      out[m[1]] = v;
    }
    return out;
  } catch {
    return {};
  }
}

let url = process.env.DATABASE_URL;
if (!url) {
  url = readEnvFile(path.join(root, ".env")).DATABASE_URL;
}

const isPostgres = typeof url === "string" && /^postgres(ql)?:\/\//i.test(url.trim());

if (!isPostgres) {
  console.log("[db-sync] SQLite target detected — nothing to sync (local database ships ready).");
  process.exit(0);
}

console.log("[db-sync] PostgreSQL/Neon target detected — syncing schema (prisma db push)…");
const res = spawnSync("npx", ["prisma", "db", "push", "--skip-generate"], {
  stdio: "inherit",
  env: process.env,
  cwd: root,
});
if (res.status !== 0) {
  console.error(
    "[db-sync] Failed to sync the database schema. Check that DATABASE_URL is a valid " +
      "PostgreSQL connection string (Neon) and that the database is reachable."
  );
  process.exit(res.status ?? 1);
}
console.log("[db-sync] Database schema is up to date.");
