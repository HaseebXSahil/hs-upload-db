#!/usr/bin/env python3
"""Creates a demo Birthday Wishes website ZIP used for testing the platform."""
import zipfile, os

HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Happy Birthday!</title>
<link rel="stylesheet" href="style.css"/>
</head>
<body>
  <div class="stars" aria-hidden="true"></div>
  <main class="card">
    <div class="balloon b1"></div>
    <div class="balloon b2"></div>
    <div class="balloon b3"></div>
    <h1>Happy Birthday!</h1>
    <p class="msg">Wishing you a day filled with love, laughter and cake!<br/>May all your wishes come true.</p>
    <button id="celebrate">Celebrate!</button>
    <p class="from">With love from <b>Malik Wishing Tools</b></p>
  </main>
  <script src="script.js"></script>
</body>
</html>"""

CSS = """*{margin:0;padding:0;box-sizing:border-box}
body{min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:'Segoe UI',system-ui,sans-serif;background:linear-gradient(135deg,#1a0533,#4a1259 50%,#7a1f6c);overflow:hidden;color:#fff}
.card{text-align:center;padding:48px 36px;max-width:480px;border-radius:24px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);backdrop-filter:blur(14px);position:relative;z-index:2;margin:16px}
h1{font-size:44px;background:linear-gradient(90deg,#ffd86b,#ff8bd2,#b388ff);-webkit-background-clip:text;background-clip:text;color:transparent;animation:shine 3s ease-in-out infinite}
@keyframes shine{50%{filter:brightness(1.3)}}
.msg{margin:18px 0 26px;color:#f3e9ff;line-height:1.6}
button{padding:14px 38px;border:none;border-radius:999px;font-size:16px;font-weight:700;color:#5a1a7a;background:linear-gradient(120deg,#ffe08a,#ffb3f0);cursor:pointer;transition:transform .2s}
button:hover{transform:scale(1.06)}
.from{margin-top:26px;font-size:13px;color:rgba(255,255,255,.65)}
.balloon{position:absolute;bottom:-140px;width:54px;height:68px;border-radius:50% 50% 48% 48%;opacity:.8;animation:rise 9s linear infinite;z-index:1}
.b1{left:12%;background:#ff5e7a;animation-delay:0s}
.b2{left:48%;background:#ffd86b;animation-delay:3s;width:44px;height:56px}
.b3{left:78%;background:#7af0ff;animation-delay:6s}
@keyframes rise{to{transform:translateY(-120vh) rotate(30deg)}}
.stars{position:fixed;inset:0;background-image:radial-gradient(2px 2px at 20% 30%,#fff,transparent),radial-gradient(1px 1px at 60% 20%,#fff,transparent),radial-gradient(1.6px 1.6px at 80% 60%,#fff,transparent),radial-gradient(1.2px 1.2px at 35% 70%,#fff,transparent),radial-gradient(1.8px 1.8px at 10% 85%,#fff,transparent);opacity:.7}"""

JS = """document.getElementById('celebrate').addEventListener('click', function () {
  for (let i = 0; i < 60; i++) {
    const c = document.createElement('div');
    c.textContent = ['🎉','🎂','🎈','✨','💜'][Math.floor(Math.random() * 5)];
    c.style.cssText = 'position:fixed;font-size:' + (14 + Math.random() * 26) + 'px;left:' + Math.random() * 100 + 'vw;top:-40px;z-index:10;pointer-events:none;transition:transform 3s linear,opacity 3s;';
    document.body.appendChild(c);
    requestAnimationFrame(() => {
      c.style.transform = 'translateY(' + (window.innerHeight + 80) + 'px) rotate(' + (Math.random() * 720 - 360) + 'deg)';
      c.style.opacity = '0';
    });
    setTimeout(() => c.remove(), 3200);
  }
});"""

os.makedirs("scripts/demo-site", exist_ok=True)
with open("scripts/demo-site/index.html", "w") as f: f.write(HTML)
with open("scripts/demo-site/style.css", "w") as f: f.write(CSS)
with open("scripts/demo-site/script.js", "w") as f: f.write(JS)

with zipfile.ZipFile("scripts/demo-birthday-site.zip", "w", zipfile.ZIP_DEFLATED) as z:
    z.write("scripts/demo-site/index.html", "birthday-website/index.html")
    z.write("scripts/demo-site/style.css", "birthday-website/style.css")
    z.write("scripts/demo-site/script.js", "birthday-website/script.js")

print("Created scripts/demo-birthday-site.zip")
