document.getElementById('celebrate').addEventListener('click', function () {
  for (let i = 0; i < 60; i++) {
    const c = document.createElement('div');
    c.textContent = ['🎉','🎂','🎈','✨','💜'][Math.floor(Math.random() * 5)];
    c.style.cssText = 'position:fixed;font-size:' + (14 + Math.random() * 26) + 'px;left:' + Math.random() * 100 + 'vw;top:-40px;z-index:10;pointer-events:none;transition:transform 3s linear,opacity 3s;';
    document.body.appendChild(c);
    requestAnimationFrame(() => {
      c.style.transform = 'translateY(' + (window.innerHeight + 80) + 'px) rotate(' + (Math.random() * 720 - 360) + 'deg)';
      c.style.opacity = '0';
    });
    setTimeout(() => c.remove(), 3200);
  }
});