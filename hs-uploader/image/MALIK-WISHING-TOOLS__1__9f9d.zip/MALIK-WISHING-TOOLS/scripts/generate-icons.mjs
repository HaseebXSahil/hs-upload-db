/**
 * Generates MALIK WISHING TOOLS PWA icons (gradient gift-box motif).
 * Run: node scripts/generate-icons.mjs
 */
import sharp from "sharp";
import { mkdirSync } from "fs";

const OUT = "public/icons";
mkdirSync(OUT, { recursive: true });

const svg = (pad = 0) => `
<svg width="512" height="512" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#d946ef"/>
      <stop offset="55%" stop-color="#a855f7"/>
      <stop offset="100%" stop-color="#7c3aed"/>
    </linearGradient>
    <linearGradient id="gold" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#f7d78c"/>
      <stop offset="100%" stop-color="#d4af37"/>
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="35%" r="65%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.35"/>
      <stop offset="100%" stop-color="#ffffff" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect x="0" y="0" width="512" height="512" rx="${pad ? 0 : 110}" fill="url(#bg)"/>
  <rect x="0" y="0" width="512" height="512" rx="${pad ? 0 : 110}" fill="url(#glow)"/>
  <g transform="translate(256,272)">
    <rect x="-118" y="-16" width="236" height="150" rx="26" fill="url(#gold)"/>
    <rect x="-132" y="-52" width="264" height="52" rx="22" fill="#fbe3a8"/>
    <rect x="-24" y="-52" width="48" height="186" fill="#ffffff" opacity="0.55"/>
    <path d="M0 -78 C -30 -130, -108 -122, -96 -78 C -88 -50, -40 -52, 0 -78 Z" fill="#fbe3a8"/>
    <path d="M0 -78 C 30 -130, 108 -122, 96 -78 C 88 -50, 40 -52, 0 -78 Z" fill="#fbe3a8"/>
  </g>
  <g fill="#ffffff">
    <path d="M416 96 l10 26 26 10 -26 10 -10 26 -10 -26 -26 -10 26 -10 z" opacity="0.95"/>
    <path d="M96 120 l7 18 18 7 -18 7 -7 18 -7 -18 -18 -7 18 -7 z" opacity="0.8"/>
    <path d="M150 400 l6 15 15 6 -15 6 -6 15 -6 -15 -15 -6 15 -6 z" opacity="0.7"/>
    <path d="M420 380 l7 18 18 7 -18 7 -7 18 -7 -18 -18 -7 18 -7 z" opacity="0.8"/>
  </g>
</svg>`;

await sharp(Buffer.from(svg(0))).resize(512, 512).png().toFile(`${OUT}/icon-512.png`);
await sharp(Buffer.from(svg(0))).resize(192, 192).png().toFile(`${OUT}/icon-192.png`);
await sharp(Buffer.from(svg(1))).resize(512, 512).png().toFile(`${OUT}/icon-maskable-512.png`);
await sharp(Buffer.from(svg(1))).resize(192, 192).png().toFile(`${OUT}/icon-maskable-192.png`);
console.log("Icons generated in", OUT);
