#!/usr/bin/env bash
# ============================================================
# MALIK WISHING TOOLS — final deliverable packager
# Creates download/MALIK-WISHING-TOOLS.zip with a ready-to-run
# project (source + pre-seeded demo database + docs).
# ============================================================
set -euo pipefail

ROOT="/home/z/my-project"
OUT="/home/z/my-project/download"
STAGE="/tmp/mwt-package"
ZIP_NAME="MALIK-WISHING-TOOLS"

rm -rf "$STAGE"
mkdir -p "$STAGE/$ZIP_NAME" "$OUT"

cd "$ROOT"

# --- Files & folders to ship ---
cp -r src prisma public scripts "$STAGE/$ZIP_NAME/"
mkdir -p "$STAGE/$ZIP_NAME/db"
cp package.json package-lock.json bun.lock tsconfig.json next.config.ts postcss.config.mjs \
   tailwind.config.ts components.json eslint.config.mjs README.md .env.example \
   netlify.toml \
   "$STAGE/$ZIP_NAME/"

# --- Portable .env (SQLite, resolved by prisma/ convention) ---
cat > "$STAGE/$ZIP_NAME/.env" <<'ENV'
# MALIK WISHING TOOLS - default local configuration (SQLite, zero setup).
# See .env.example for all options and the README for Neon/PostgreSQL + Vercel.
DATABASE_URL="file:./custom.db"
ENV

# --- Pre-seeded demo database (2 demo websites, 1 category, settings) ---
cp db/custom.db "$STAGE/$ZIP_NAME/prisma/custom.db"

# --- .gitignore tuned for this project ---
cat > "$STAGE/$ZIP_NAME/.gitignore" <<'GIT'
node_modules/
.next/
out/
build/
.env
*.log
storage/
prisma/*.db-journal
prisma/*.db
GIT

# --- Quick-start script ---
cat > "$STAGE/$ZIP_NAME/start.sh" <<'SH'
#!/usr/bin/env bash
# MALIK WISHING TOOLS - one-command quick start (SQLite, no configuration)
set -e
echo "🎁 MALIK WISHING TOOLS - setting up..."
if command -v bun >/dev/null 2>&1; then PM="bun"; else PM="npm"; fi
$PM install
$PM run setup
echo ""
echo "✅ Setup complete!"
echo "   Admin panel : http://localhost:3000/admin   (Khan@1373 / Khan@1373)"
echo "   Public site : http://localhost:3000"
echo ""
if [ "$1" = "--prod" ]; then
  $PM run build && $PM start
else
  $PM run dev
fi
SH
chmod +x "$STAGE/$ZIP_NAME/start.sh"

# --- Package ---
cd "$STAGE"
rm -f "$OUT/$ZIP_NAME.zip"
zip -rq "$OUT/$ZIP_NAME.zip" "$ZIP_NAME" -x "*.DS_Store"

ls -la "$OUT/$ZIP_NAME.zip"
echo "---- contents summary ----"
unzip -l "$OUT/$ZIP_NAME.zip" | head -18
unzip -l "$OUT/$ZIP_NAME.zip" | tail -3
