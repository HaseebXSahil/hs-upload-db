#!/usr/bin/env bash
# MALIK WISHING TOOLS — full workflow verification
# Admin login → upload demo ZIP → publish → open hosted site → public API
set -uo pipefail

BASE="http://127.0.0.1:3111"
JAR="/tmp/mwt-cookies.txt"
rm -f "$JAR"

pass() { echo "✅ PASS: $1"; }
fail() { echo "❌ FAIL: $1"; FAILED=1; }
FAILED=0

echo "=== 1. Homepage renders ==="
HOME_HTML=$(curl -s "$BASE/")
echo "$HOME_HTML" | grep -q "MALIK WISHING TOOLS" && pass "Homepage contains brand title" || fail "Homepage brand title missing"
echo "$HOME_HTML" | grep -qi "Malik Mushahid" && pass "Homepage shows creator credit" || fail "Creator credit missing"

echo "=== 2. Public sites API ==="
PUB=$(curl -s "$BASE/api/public/sites/")
echo "$PUB" | grep -q '"sites":\[' && pass "Public sites API responds" || fail "Public sites API: $PUB"

echo "=== 3. Admin login (Khan@1373) ==="
LOGIN=$(curl -s -c "$JAR" -X POST "$BASE/api/admin/login/" \
  -H "Content-Type: application/json" \
  -H "Origin: $BASE" \
  -d '{"username":"Khan@1373","password":"Khan@1373"}')
echo "$LOGIN" | grep -q '"ok":true' && pass "Login accepted" || fail "Login failed: $LOGIN"

echo "=== 4. Upload demo ZIP ==="
UP=$(curl -s -b "$JAR" -X POST "$BASE/api/admin/sites/" \
  -H "Origin: $BASE" \
  -F "name=Workflow Test Site" \
  -F "slug=workflow-test" \
  -F "description=Automated verification upload" \
  -F "published=true" \
  -F "mode=zip" \
  -F "zip=@/home/z/my-project/scripts/demo-birthday-site.zip;type=application/zip")
echo "$UP" | grep -q '"ok":true' && pass "ZIP uploaded & site created" || fail "Upload failed: $UP"

echo "=== 5. Open hosted website at /sites/workflow-test/ ==="
SITE_HTML=$(curl -s -L "$BASE/sites/workflow-test/")
echo "$SITE_HTML" | grep -qi "<html" && pass "Hosted site serves HTML" || fail "Hosted site did not serve HTML: $(echo "$SITE_HTML" | head -c 200)"

echo "=== 6. Site asset resolution (relative path) ==="
CSS=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/sites/workflow-test/style.css")
JS=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/sites/workflow-test/script.js")
[ "$CSS" = "200" ] && pass "style.css served (200)" || fail "style.css -> $CSS"
[ "$JS" = "200" ] && pass "script.js served (200)" || fail "script.js -> $JS"

echo "=== 7. Admin site list contains the new site ==="
LIST=$(curl -s -b "$JAR" "$BASE/api/admin/sites/")
echo "$LIST" | grep -q "workflow-test" && pass "Site visible in admin list" || fail "Site missing in admin list"

echo "=== 8. Unauthed admin API is blocked ==="
CODE=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/api/admin/sites/")
[ "$CODE" = "401" ] && pass "Admin API protected (401)" || fail "Admin API returned $CODE"

echo "=== 9. Unpublish hides site from public ==="
SITE_ID=$(echo "$LIST" | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>{const j=JSON.parse(d);const s=j.sites.find(s=>s.slug==='workflow-test');console.log(s?s.id:'')})")
UNP=$(curl -s -b "$JAR" -X PATCH "$BASE/api/admin/sites/$SITE_ID/" \
  -H "Content-Type: application/json" -H "Origin: $BASE" \
  -d '{"published":false}')
PUBCODE=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/sites/workflow-test/")
[ "$PUBCODE" = "404" ] && pass "Unpublished site hidden from public (404)" || fail "Unpublished site still visible ($PUBCODE)"

echo "=== 10. Re-publish + update files keeps URL ==="
REP=$(curl -s -b "$JAR" -X PATCH "$BASE/api/admin/sites/$SITE_ID/" \
  -H "Content-Type: application/json" -H "Origin: $BASE" \
  -d '{"published":true}')
PUBCODE2=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/sites/workflow-test/")
[ "$PUBCODE2" = "200" ] && pass "Re-published site live again (200)" || fail "Re-publish failed ($PUBCODE2)"

echo "=== 11. Path traversal blocked ==="
TRAV=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/sites/workflow-test/..%2f..%2f..%2fetc%2fpasswd")
[ "$TRAV" = "404" ] && pass "Path traversal rejected (404)" || fail "Path traversal returned $TRAV"

echo ""
if [ "$FAILED" = "0" ]; then echo "🎉 ALL WORKFLOW TESTS PASSED"; else echo "⚠️ SOME TESTS FAILED"; exit 1; fi
