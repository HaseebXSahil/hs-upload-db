#!/usr/bin/env bash
# MALIK WISHING TOOLS - one-command quick start (SQLite, no configuration)
set -e
echo "🎁 MALIK WISHING TOOLS - setting up..."
if command -v bun >/dev/null 2>&1; then PM="bun"; else PM="npm"; fi
$PM install
$PM run setup
echo ""
echo "✅ Setup complete!"
echo "   Admin panel : http://localhost:3000/admin   (Khan@1373 / Khan@1373)"
echo "   Public site : http://localhost:3000"
echo ""
if [ "$1" = "--prod" ]; then
  $PM run build && $PM start
else
  $PM run dev
fi
