import { db } from "@/lib/db";

/**
 * Slug generation with uniqueness guarantee.
 */

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/[\s_]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 60);
}

const RESERVED_SLUGS = new Set(["admin", "api", "sites", "_next", "static", "public", "favicon.ico", "manifest.webmanifest", "sw.js", "offline.html"]);

export async function uniqueSlug(desired: string, ignoreSiteId?: string): Promise<string> {
  let base = slugify(desired);
  if (!base || RESERVED_SLUGS.has(base)) base = base ? `${base}-site` : "site";
  let candidate = base;
  let n = 2;
  // Guard against infinite loops
  for (let i = 0; i < 100; i++) {
    const existing = await db.site.findUnique({ where: { slug: candidate }, select: { id: true } });
    if (!existing || existing.id === ignoreSiteId) return candidate;
    candidate = `${base}-${n++}`;
  }
  return `${base}-${Date.now().toString(36)}`;
}

export function validSlug(slug: string): boolean {
  return /^[a-z0-9][a-z0-9-]{1,59}$/.test(slug) && !RESERVED_SLUGS.has(slug);
}
