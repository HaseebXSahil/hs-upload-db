import JSZip from "jszip";
import { isBlockedPath } from "@/lib/mime";

/**
 * MALIK WISHING TOOLS - Secure upload processing
 * Validates & extracts ZIP archives / HTML uploads with strict protections:
 *  - Zip bomb protection (entry count, total size, compression ratio)
 *  - Path traversal protection (.., absolute paths, drive letters, backslashes)
 *  - Dangerous file extension blocklist
 *  - Automatic detection of the entry point (index.html)
 *  - Automatic unwrap of a single wrapper folder (e.g. "my-site/...")
 */

export interface ProcessedFile {
  path: string;
  data: Buffer;
  mime: string;
}

export interface ProcessResult {
  files: ProcessedFile[];
  warnings: string[];
}

export const LIMITS = {
  maxZipSize: 60 * 1024 * 1024, // 60 MB compressed
  maxTotalUncompressed: 80 * 1024 * 1024, // 80 MB
  maxFileCount: 800,
  maxSingleFile: 25 * 1024 * 1024, // 25 MB
  maxCompressionRatio: 200,
};

export class UploadError extends Error {}

/** Normalize and sanitize a zip entry path. Returns null when the path is unsafe/junk. */
function sanitizeEntryPath(rawName: string): string | null {
  let name = rawName.replace(/\\/g, "/");
  // Strip drive letters and leading slashes
  name = name.replace(/^[a-zA-Z]:/, "").replace(/^\/+/, "");
  const segments: string[] = [];
  for (const seg of name.split("/")) {
    if (seg === "" || seg === ".") continue;
    if (seg === "..") return null; // path traversal attempt
    // Strip control chars and trim spaces/dots at the end (Windows quirk)
    const clean = seg.replace(/[\x00-\x1f\x7f]/g, "").replace(/[. ]+$/, "");
    if (!clean) continue;
    segments.push(clean);
  }
  if (segments.length === 0) return null;
  return segments.join("/");
}

function isJunkPath(path: string): boolean {
  const parts = path.split("/");
  if (parts.some((p) => p === "__MACOSX" || p === ".DS_Store")) return true;
  const base = parts[parts.length - 1];
  if (base.startsWith("._") || base === ".DS_Store" || base === "Thumbs.db") return true;
  return false;
}

/** If every file lives under one top folder, unwrap it (common with folder-zips). */
function unwrapCommonRoot(files: ProcessedFile[]): ProcessedFile[] {
  if (files.length === 0) return files;
  const first = files[0].path.split("/")[0];
  if (files.length === 1 && !files[0].path.includes("/")) return files;
  const allShareRoot = files.every((f) => f.path.startsWith(first + "/"));
  if (!allShareRoot) return files;
  // Only unwrap when the root folder itself has no loose index.html sibling logic:
  // i.e. root folder contains the entry point inside it.
  return files.map((f) => ({ ...f, path: f.path.slice(first.length + 1) }));
}

/** Process an uploaded ZIP buffer into safe website files. */
export async function processZip(buffer: Buffer): Promise<ProcessResult> {
  const warnings: string[] = [];
  if (buffer.length > LIMITS.maxZipSize) {
    throw new UploadError(`ZIP file is too large (max ${Math.round(LIMITS.maxZipSize / 1024 / 1024)} MB).`);
  }

  let zip: JSZip;
  try {
    zip = await JSZip.loadAsync(buffer);
  } catch {
    throw new UploadError("This file is not a valid ZIP archive.");
  }

  const entries = Object.values(zip.files).filter((e) => !e.dir);
  if (entries.length === 0) throw new UploadError("The ZIP archive is empty.");
  if (entries.length > LIMITS.maxFileCount) {
    throw new UploadError(`ZIP contains too many files (${entries.length}). Max is ${LIMITS.maxFileCount}.`);
  }

  // Compression ratio check (zip bomb guard)
  for (const entry of entries) {
    if (entry._data?.compressedSize > 0 && entry._data?.uncompressedSize / entry._data.compressedSize > LIMITS.maxCompressionRatio && entry._data.uncompressedSize > 1024 * 1024) {
      throw new UploadError("Suspicious compression detected in ZIP (possible zip bomb). Upload rejected.");
    }
  }

  const files: ProcessedFile[] = [];
  let total = 0;

  for (const entry of entries) {
    const safePath = sanitizeEntryPath(entry.name);
    if (!safePath) {
      warnings.push(`Skipped unsafe path: ${entry.name}`);
      continue;
    }
    if (isJunkPath(safePath)) continue;
    if (isBlockedPath(safePath)) {
      warnings.push(`Skipped blocked file type: ${safePath}`);
      continue;
    }
    const data = Buffer.from(await entry.async("arraybuffer"));
    if (data.length > LIMITS.maxSingleFile) {
      throw new UploadError(`File "${safePath}" exceeds the ${Math.round(LIMITS.maxSingleFile / 1024 / 1024)} MB single-file limit.`);
    }
    total += data.length;
    if (total > LIMITS.maxTotalUncompressed) {
      throw new UploadError(`Uncompressed website exceeds ${Math.round(LIMITS.maxTotalUncompressed / 1024 / 1024)} MB limit.`);
    }
    files.push({ path: safePath, data, mime: "", });
  }

  if (files.length === 0) throw new UploadError("No usable website files were found in the ZIP.");

  const unwrapped = unwrapCommonRoot(files);
  if (unwrapped.length !== files.length || unwrapped[0]?.path !== files[0]?.path) {
    warnings.push("Files were found inside a wrapper folder — it was unwrapped automatically.");
  }

  // Detect blocked leftovers after unwrap
  const finalFiles = unwrapped.filter((f) => !isBlockedPath(f.path));
  if (finalFiles.length !== unwrapped.length) {
    warnings.push("Some files with unsupported types were removed.");
  }
  if (finalFiles.length === 0) throw new UploadError("All files in the ZIP were blocked by the security filter.");

  return { files: finalFiles, warnings };
}

/** Process a loose-file upload (HTML + assets) from a FormData object. */
export async function processLooseFiles(form: FormData): Promise<ProcessResult> {
  const warnings: string[] = [];
  const files: ProcessedFile[] = [];
  let total = 0;

  for (const [field, value] of form.entries()) {
    if (!(value instanceof File)) continue;
    if (value.size === 0) continue;
    const rawName = (value as File & { webkitRelativePath?: string }).webkitRelativePath || value.name;
    const safePath = sanitizeEntryPath(rawName);
    if (!safePath) {
      warnings.push(`Skipped unsafe path: ${rawName}`);
      continue;
    }
    if (isBlockedPath(safePath)) {
      warnings.push(`Skipped blocked file type: ${safePath}`);
      continue;
    }
    const data = Buffer.from(await value.arrayBuffer());
    if (data.length > LIMITS.maxSingleFile) {
      throw new UploadError(`File "${safePath}" exceeds the single-file limit.`);
    }
    total += data.length;
    if (total > LIMITS.maxTotalUncompressed) {
      throw new UploadError(`Total upload exceeds the ${Math.round(LIMITS.maxTotalUncompressed / 1024 / 1024)} MB limit.`);
    }
    files.push({ path: safePath, data, mime: "" });
  }

  if (files.length === 0) throw new UploadError("No files were provided.");
  return { files, warnings };
}

/** Find the entry point (index.html) among processed files. */
export function findEntry(files: ProcessedFile[]): string | null {
  const htmlFiles = files.filter((f) => /\.html?$/i.test(f.path));
  if (htmlFiles.length === 0) return null;
  const exact = htmlFiles.find((f) => f.path.toLowerCase() === "index.html");
  if (exact) return exact.path;
  const rootIndex = htmlFiles.find((f) => /^index\.html?$/i.test(f.path.split("/").pop() ?? ""));
  if (rootIndex) return rootIndex.path;
  return htmlFiles.sort((a, b) => a.path.split("/").length - b.path.split("/").length)[0].path;
}
