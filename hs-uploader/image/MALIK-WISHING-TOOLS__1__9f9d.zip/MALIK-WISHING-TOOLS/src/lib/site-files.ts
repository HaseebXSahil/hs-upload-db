import { gzipSync, gunzipSync } from "zlib";
import { db } from "@/lib/db";
import { ProcessedFile } from "@/lib/upload";
import { getMime } from "@/lib/mime";

/**
 * MALIK WISHING TOOLS - Site file engine
 * Stores uploaded website files in the database (default, portable across
 * Vercel + Neon) or on local disk (STORAGE_DRIVER=local, for VPS hosting).
 * Every file replacement snapshots the previous state for version restore.
 */

const MAX_VERSIONS_PER_SITE = 5;

interface FilePayload {
  path: string;
  mime: string;
  data: Buffer;
}

// ---------------- Version snapshots ----------------

export async function snapshotCurrentFiles(siteId: string, note?: string): Promise<number> {
  const site = await db.site.findUnique({ where: { id: siteId }, select: { currentVersion: true } });
  if (!site) throw new Error("Site not found");
  const files = await db.siteFile.findMany({ where: { siteId } });
  const payload = JSON.stringify(
    files.map((f) => ({ path: f.path, mime: f.mime, data: Buffer.from(f.data).toString("base64") }))
  );
  const snapshot = gzipSync(Buffer.from(payload));
  const version = site.currentVersion;
  await db.siteVersion.upsert({
    where: { siteId_version: { siteId, version } },
    update: { snapshot, fileCount: files.length, sizeBytes: snapshot.length, note: note ?? null },
    create: { siteId, version, snapshot, fileCount: files.length, sizeBytes: snapshot.length, note: note ?? null },
  });
  // Prune old versions beyond the newest MAX_VERSIONS_PER_SITE
  const versions = await db.siteVersion.findMany({
    where: { siteId },
    orderBy: { version: "desc" },
    select: { id: true },
    skip: MAX_VERSIONS_PER_SITE,
  });
  if (versions.length > 0) {
    await db.siteVersion.deleteMany({ where: { id: { in: versions.map((v) => v.id) } } });
  }
  return version;
}

async function writeFiles(siteId: string, files: FilePayload[]): Promise<void> {
  const driver = process.env.STORAGE_DRIVER ?? "db";
  if (driver === "local") {
    const fs = await import("fs/promises");
    const path = await import("path");
    const root = process.env.LOCAL_STORAGE_DIR ?? path.join(process.cwd(), "storage", "sites");
    const siteRoot = path.resolve(path.join(root, siteId));
    for (const f of files) {
      // Defense in depth: refuse any path that escapes the site directory
      if (f.path.split("/").some((seg) => seg === ".." || seg === "")) {
        throw new Error(`Unsafe file path rejected: ${f.path}`);
      }
      const dest = path.resolve(path.join(siteRoot, f.path));
      if (!dest.startsWith(siteRoot + path.sep)) {
        throw new Error(`Unsafe file path rejected: ${f.path}`);
      }
      await fs.mkdir(path.dirname(dest), { recursive: true });
      await fs.writeFile(dest, f.data);
    }
  } else {
    // DB driver: chunk very large payloads to stay within SQLite limits
    for (const f of files) {
      await db.siteFile.upsert({
        where: { siteId_path: { siteId, path: f.path } },
        update: { data: f.data, mime: f.mime, size: f.data.length, updatedAt: new Date() },
        create: { siteId, path: f.path, data: f.data, mime: f.mime, size: f.data.length },
      });
    }
  }
}

/**
 * Write a set of files to a site.
 *  - mode "replace": the new file set becomes the entire website (old files removed)
 *  - mode "merge": given files are added/overwritten, everything else is kept
 * Snapshots existing files first (unless snapshot:false) for version restore.
 */
export async function writeSiteFiles(
  siteId: string,
  files: ProcessedFile[],
  opts: { mode: "replace" | "merge"; snapshot?: boolean; note?: string } = { mode: "replace" }
): Promise<{ sizeBytes: number; fileCount: number }> {
  const existing = await db.siteFile.findMany({ where: { siteId }, select: { path: true } });
  if (opts.snapshot !== false && existing.length > 0) {
    await snapshotCurrentFiles(siteId, opts.note ?? "Auto-snapshot before update");
  }

  const driver = process.env.STORAGE_DRIVER ?? "db";
  const payloads: FilePayload[] = files.map((f) => ({
    path: f.path,
    mime: f.mime || guessMime(f.path),
    data: f.data,
  }));

  if (driver === "local") {
    if (opts.mode === "replace") await deleteLocalDir(siteId);
  } else if (opts.mode === "replace" && existing.length > 0) {
    // Remove DB rows that are not part of the new file set
    const keep = new Set(payloads.map((p) => p.path));
    const stale = existing.map((e) => e.path).filter((p) => !keep.has(p));
    if (stale.length > 0) {
      await db.siteFile.deleteMany({ where: { siteId, path: { in: stale } } });
    }
  }
  await writeFiles(siteId, payloads);

  let sizeBytes: number;
  let fileCount: number;
  if (opts.mode === "replace") {
    sizeBytes = files.reduce((sum, f) => sum + f.data.length, 0);
    fileCount = files.length;
  } else {
    const kept = existing.filter((e) => !payloads.some((p) => p.path === e.path)).length;
    fileCount = kept + payloads.length;
    if (driver === "local") {
      const all = await listSiteFiles(siteId);
      sizeBytes = all.reduce((s, f) => s + f.size, 0);
      fileCount = all.length;
    } else {
      const agg = await db.siteFile.aggregate({ where: { siteId }, _sum: { size: true }, _count: true });
      sizeBytes = agg._sum.size ?? 0;
      fileCount = agg._count;
    }
  }
  await db.site.update({ where: { id: siteId }, data: { sizeBytes, fileCount } });
  return { sizeBytes, fileCount };
}

/** Replace the whole file set of a site (used on create/update). */
export async function replaceSiteFiles(
  siteId: string,
  files: ProcessedFile[],
  opts: { snapshot?: boolean; note?: string } = {}
): Promise<{ sizeBytes: number; fileCount: number }> {
  return writeSiteFiles(siteId, files, { mode: "replace", ...opts });
}

function guessMime(path: string): string {
  return getMime(path);
}

export async function readSiteFile(siteId: string, path: string): Promise<Buffer | null> {
  const driver = process.env.STORAGE_DRIVER ?? "db";
  if (driver === "local") {
    try {
      const fs = await import("fs/promises");
      const pathMod = await import("path");
      const root = process.env.LOCAL_STORAGE_DIR ?? pathMod.join(process.cwd(), "storage", "sites");
      const dest = pathMod.join(root, siteId, path);
      // Ensure resolved path stays inside the site directory
      if (!pathMod.resolve(dest).startsWith(pathMod.resolve(pathMod.join(root, siteId)))) return null;
      return await fs.readFile(dest);
    } catch {
      return null;
    }
  }
  const row = await db.siteFile.findUnique({
    where: { siteId_path: { siteId, path } },
    select: { data: true },
  });
  return row ? Buffer.from(row.data) : null;
}

export async function listSiteFiles(siteId: string): Promise<{ path: string; mime: string; size: number; updatedAt: Date }[]> {
  const driver = process.env.STORAGE_DRIVER ?? "db";
  if (driver === "local") {
    const fs = await import("fs/promises");
    const pathMod = await import("path");
    const root = process.env.LOCAL_STORAGE_DIR ?? pathMod.join(process.cwd(), "storage", "sites");
    const out: { path: string; mime: string; size: number; updatedAt: Date }[] = [];
    async function walk(dir: string, rel: string) {
      let entries;
      try {
        entries = await fs.readdir(dir, { withFileTypes: true });
      } catch {
        return;
      }
      for (const e of entries) {
        const full = pathMod.join(dir, e.name);
        const relPath = rel ? `${rel}/${e.name}` : e.name;
        if (e.isDirectory()) await walk(full, relPath);
        else {
          const stat = await fs.stat(full).catch(() => null);
          if (stat) out.push({ path: relPath, mime: guessMime(relPath), size: stat.size, updatedAt: stat.mtime });
        }
      }
    }
    await walk(pathMod.join(root, siteId), "");
    return out.sort((a, b) => a.path.localeCompare(b.path));
  }
  const rows = await db.siteFile.findMany({
    where: { siteId },
    select: { path: true, mime: true, size: true, updatedAt: true },
    orderBy: { path: "asc" },
  });
  return rows;
}

export async function deleteSiteFile(siteId: string, path: string): Promise<void> {
  const driver = process.env.STORAGE_DRIVER ?? "db";
  if (driver === "local") {
    const fs = await import("fs/promises");
    const pathMod = await import("path");
    const root = process.env.LOCAL_STORAGE_DIR ?? pathMod.join(process.cwd(), "storage", "sites");
    await fs.rm(pathMod.join(root, siteId, path), { force: true });
    return;
  }
  await db.siteFile.deleteMany({ where: { siteId, path } });
}

async function deleteLocalDir(siteId: string): Promise<void> {
  const fs = await import("fs/promises");
  const pathMod = await import("path");
  const root = process.env.LOCAL_STORAGE_DIR ?? pathMod.join(process.cwd(), "storage", "sites");
  await fs.rm(pathMod.join(root, siteId), { recursive: true, force: true });
}

export async function deleteAllSiteFiles(siteId: string): Promise<void> {
  const driver = process.env.STORAGE_DRIVER ?? "db";
  if (driver === "local") {
    await deleteLocalDir(siteId);
  }
  await db.siteFile.deleteMany({ where: { siteId } });
}

// ---------------- Version restore ----------------

export async function restoreVersion(siteId: string, version: number): Promise<{ restored: number }> {
  const snap = await db.siteVersion.findUnique({
    where: { siteId_version: { siteId, version } },
  });
  if (!snap) throw new Error("Version not found");
  const json = JSON.parse(gunzipSync(Buffer.from(snap.snapshot)).toString("utf8")) as {
    path: string;
    mime: string;
    data: string;
  }[];
  const files: ProcessedFile[] = json.map((f) => ({ path: f.path, mime: f.mime, data: Buffer.from(f.data, "base64") }));
  // Snapshot the current state before rolling back
  await snapshotCurrentFiles(siteId, "Auto-snapshot before restore");
  await replaceSiteFiles(siteId, files, { snapshot: false, note: `Restored v${version}` });
  await db.site.update({ where: { id: siteId }, data: { currentVersion: { increment: 1 } } });
  return { restored: files.length };
}
