import { db } from "@/lib/db";
import { hashPassword } from "@/lib/auth";
import { DEFAULT_SETTINGS } from "@/lib/settings";

/**
 * First-run bootstrap: creates the admin account (from env or platform defaults)
 * and seeds default public settings. Runs once per process, lazily.
 */

let bootstrapPromise: Promise<void> | null = null;

export function ensureBootstrap(): Promise<void> {
  if (!bootstrapPromise) {
    bootstrapPromise = doBootstrap().catch((e) => {
      bootstrapPromise = null; // allow retry on next request
      throw e;
    });
  }
  return bootstrapPromise;
}

async function doBootstrap(): Promise<void> {
  const username = process.env.ADMIN_USERNAME?.trim() || "Khan@1373";
  const password = process.env.ADMIN_PASSWORD || "Khan@1373";

  const existing = await db.admin.findUnique({ where: { username } });
  if (!existing) {
    const anyAdmin = await db.admin.findFirst();
    if (!anyAdmin) {
      await db.admin.create({
        data: { username, passwordHash: hashPassword(password) },
      });
      console.log(`[MWT] Admin account created for "${username}". Password is stored as a scrypt hash.`);
    }
  }

  // Seed any missing public settings
  const keys = Object.keys(DEFAULT_SETTINGS).map((k) => `public_${k}`);
  const rows = await db.setting.findMany({ where: { key: { in: keys } }, select: { key: true } });
  const present = new Set(rows.map((r) => r.key));
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) {
    const key = `public_${k}`;
    if (present.has(key)) continue;
    await db.setting.create({ data: { key, value: String(v) } });
  }
}
