import { SignJWT, jwtVerify } from "jose";
import { scryptSync, randomBytes, timingSafeEqual } from "crypto";
import { db } from "@/lib/db";
import { cookies } from "next/headers";
import { NextRequest, NextResponse } from "next/server";

/**
 * MALIK WISHING TOOLS - Admin Authentication
 * - Passwords hashed with scrypt (random salt, timing-safe compare)
 * - Sessions are signed JWTs (HS256) stored in httpOnly SameSite=Strict cookies
 * - Secret comes from AUTH_SECRET env, or is auto-generated & persisted in DB
 */

const SESSION_COOKIE = "mwt_admin_session";
const SESSION_TTL_SECONDS = 60 * 60 * 12; // 12 hours

let cachedSecret: Uint8Array | null = null;

async function getSecret(): Promise<Uint8Array> {
  if (cachedSecret) return cachedSecret;
  let secret = process.env.AUTH_SECRET?.trim();
  if (!secret) {
    // Fall back to a persistent auto-generated secret (survives restarts via DB)
    const row = await db.setting.findUnique({ where: { key: "internal_auth_secret" } });
    if (row) {
      secret = row.value;
    } else {
      secret = crypto.getRandomValues(new Uint8Array(48)).reduce((s, b) => s + b.toString(16).padStart(2, "0"), "");
      await db.setting.upsert({
        where: { key: "internal_auth_secret" },
        update: { value: secret },
        create: { key: "internal_auth_secret", value: secret },
      });
    }
  }
  cachedSecret = new TextEncoder().encode(secret);
  return cachedSecret;
}

// ---------- Password hashing (scrypt) ----------

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const derived = scryptSync(password, salt, 64);
  const saltHex = salt.toString("hex");
  const hashHex = derived.toString("hex");
  return `scrypt$${saltHex}$${hashHex}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [scheme, saltHex, hashHex] = stored.split("$");
    if (scheme !== "scrypt" || !saltHex || !hashHex) return false;
    const salt = Buffer.from(saltHex, "hex");
    const derived = scryptSync(password, salt, 64);
    const expected = Buffer.from(hashHex, "hex");
    if (derived.length !== expected.length) return false;
    return timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

// ---------- Session tokens ----------

export async function createSessionToken(adminId: string): Promise<string> {
  const secret = await getSecret();
  return await new SignJWT({ sub: adminId, role: "admin" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_TTL_SECONDS}s`)
    .sign(secret);
}

export async function verifySessionToken(token: string): Promise<string | null> {
  try {
    const secret = await getSecret();
    const { payload } = await jwtVerify(token, secret);
    if (payload.role !== "admin" || typeof payload.sub !== "string") return null;
    return payload.sub;
  } catch {
    return null;
  }
}

// ---------- Cookie helpers ----------

export async function setSessionCookie(response: NextResponse, token: string) {
  response.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    maxAge: SESSION_TTL_SECONDS,
    path: "/",
  });
}

export async function clearSessionCookie(response: NextResponse) {
  response.cookies.set(SESSION_COOKIE, "", {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    maxAge: 0,
    path: "/",
  });
}

export async function getSessionAdminId(): Promise<string | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return await verifySessionToken(token);
}

export async function isAuthenticated(): Promise<boolean> {
  return (await getSessionAdminId()) !== null;
}

// ---------- API guards ----------

export class AuthError extends Error {}

/**
 * Throws AuthError if the request has no valid admin session.
 * Also enforces same-origin for state-changing requests (CSRF defense:
 * uploaded sandboxed sites live on opaque origins -> Origin will be null).
 */
export async function requireAdmin(req: NextRequest): Promise<string> {
  const adminId = await getSessionAdminId();
  if (!adminId) throw new AuthError("Unauthorized");
  const method = req.method.toUpperCase();
  if (method !== "GET" && method !== "HEAD") {
    const origin = req.headers.get("origin");
    if (origin) {
      const host = req.headers.get("host");
      try {
        const originHost = new URL(origin).host;
        if (host && originHost !== host) throw new AuthError("Cross-origin request rejected");
      } catch {
        throw new AuthError("Invalid origin");
      }
    }
    if (req.headers.get("sec-fetch-site") === "cross-site") {
      throw new AuthError("Cross-site request rejected");
    }
  }
  return adminId;
}

export function authErrorResponse(e: unknown) {
  if (e instanceof AuthError) {
    return NextResponse.json({ error: e.message }, { status: 401 });
  }
  console.error(e);
  return NextResponse.json({ error: "Internal server error" }, { status: 500 });
}
