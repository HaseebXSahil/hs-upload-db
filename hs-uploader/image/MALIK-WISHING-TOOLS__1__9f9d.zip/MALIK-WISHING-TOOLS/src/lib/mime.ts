/**
 * MALIK WISHING TOOLS - File type safety
 * MIME mapping + dangerous extension blocklist for uploaded websites.
 */

const MIME_MAP: Record<string, string> = {
  html: "text/html; charset=utf-8",
  htm: "text/html; charset=utf-8",
  css: "text/css; charset=utf-8",
  js: "application/javascript; charset=utf-8",
  mjs: "application/javascript; charset=utf-8",
  json: "application/json; charset=utf-8",
  map: "application/json; charset=utf-8",
  txt: "text/plain; charset=utf-8",
  md: "text/plain; charset=utf-8",
  xml: "application/xml; charset=utf-8",
  csv: "text/csv; charset=utf-8",
  ics: "text/calendar; charset=utf-8",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  gif: "image/gif",
  webp: "image/webp",
  avif: "image/avif",
  svg: "image/svg+xml",
  bmp: "image/bmp",
  ico: "image/x-icon",
  cur: "image/x-icon",
  mp3: "audio/mpeg",
  wav: "audio/wav",
  ogg: "audio/ogg",
  m4a: "audio/mp4",
  aac: "audio/aac",
  flac: "audio/flac",
  mp4: "video/mp4",
  webm: "video/webm",
  mov: "video/quicktime",
  woff: "font/woff",
  woff2: "font/woff2",
  ttf: "font/ttf",
  otf: "font/otf",
  eot: "application/vnd.ms-fontobject",
  pdf: "application/pdf",
  zip: "application/zip",
  webmanifest: "application/manifest+json",
  manifest: "application/manifest+json",
  wasm: "application/wasm",
  vtt: "text/vtt; charset=utf-8",
  srt: "text/plain; charset=utf-8",
};

/** Extensions that must never be hosted (server-side executables / scripts). */
export const BLOCKED_EXTENSIONS = new Set([
  "php", "phtml", "php5", "php7", "phps",
  "asp", "aspx", "asax", "ascx", "cshtml", "vbhtml",
  "jsp", "jspx", "do", "action",
  "cgi", "pl", "py", "rb", "sh", "bash", "zsh", "fish", "csh",
  "exe", "dll", "so", "bin", "msi", "com", "scr", "bat", "cmd", "ps1", "vbs", "wsf",
  "jar", "class", "war", "apk", "app", "deb", "rpm",
  "htaccess", "htpasswd",
  "env", "sql", "db", "sqlite", "sqlite3", "mdb",
  "c", "cpp", "h", "hpp", "cs", "go", "rs", "java", "kt", "swift",
]);

export function getExtension(path: string): string {
  const base = path.split("/").pop() ?? "";
  const idx = base.lastIndexOf(".");
  return idx > 0 ? base.slice(idx + 1).toLowerCase() : "";
}

export function getMime(path: string, fallback = "application/octet-stream"): string {
  return MIME_MAP[getExtension(path)] ?? fallback;
}

export function isBlockedPath(path: string): boolean {
  const ext = getExtension(path);
  if (BLOCKED_EXTENSIONS.has(ext)) return true;
  const base = (path.split("/").pop() ?? "").toLowerCase();
  // Block dotfiles that configure servers
  if (base === ".htaccess" || base === ".htpasswd" || base === ".env" || base === "web.config") return true;
  return false;
}

export function isHtmlPath(path: string): boolean {
  const ext = getExtension(path);
  return ext === "html" || ext === "htm";
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}
