import { PrismaClient } from '@prisma/client'
import path from "path";

/**
 * MALIK WISHING TOOLS — Prisma client singleton.
 *
 * Note on SQLite portability: the Prisma CLI resolves relative `file:` URLs
 * against the schema directory (prisma/), while the Node runtime resolves
 * them against process.cwd(). We normalize here so both always point at the
 * same database file, no matter how the app is started (dev, start, or the
 * standalone output). PostgreSQL/Neon URLs are untouched.
 */

function normalizeDatabaseUrl(raw: string | undefined): string | undefined {
  if (!raw || !raw.startsWith("file:")) return raw;
  const rest = raw.slice(5);
  const [pathPart, query] = (() => {
    const qIndex = rest.indexOf("?");
    return qIndex === -1 ? [rest, ""] : [rest.slice(0, qIndex), rest.slice(qIndex)];
  })();
  if (path.isAbsolute(pathPart)) return raw;

  // Base = project root (handle the standalone server which runs inside .next/standalone)
  let base = process.cwd();
  if (path.basename(base) === "standalone" && path.basename(path.dirname(base)) === ".next") {
    base = path.resolve(base, "..", "..");
  }
  // Match the Prisma CLI convention: relative to the schema directory
  const abs = path.resolve(base, "prisma", pathPart);
  return `file:${abs}${query}`;
}

const resolvedUrl = normalizeDatabaseUrl(process.env.DATABASE_URL);
if (resolvedUrl && resolvedUrl !== process.env.DATABASE_URL) {
  process.env.DATABASE_URL = resolvedUrl;
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "production" ? [] : [],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
