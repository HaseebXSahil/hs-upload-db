import { db } from "@/lib/db";
import { ensureBootstrap } from "@/lib/bootstrap";
import { getSettings, contactLinks } from "@/lib/settings";
import { HomeClient } from "@/components/public/home-client";
import { formatBytes } from "@/lib/mime";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await ensureBootstrap();

  const [sites, settings] = await Promise.all([
    db.site.findMany({
      where: { published: true },
      include: { category: { select: { id: true, name: true, slug: true } } },
      orderBy: [{ featured: "desc" }, { updatedAt: "desc" }],
    }),
    getSettings(),
  ]);

  const categories = await db.category.findMany({
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
  });

  const totalViews = sites.reduce((s, x) => s + x.views, 0);
  const totalSize = sites.reduce((s, x) => s + x.sizeBytes, 0);

  const publicSites = sites.map((s) => ({
    id: s.id,
    name: s.name,
    slug: s.slug,
    description: s.description,
    featured: s.featured,
    views: s.views,
    hasThumbnail: !!s.thumbnailData,
    updatedAt: s.updatedAt.toISOString(),
    sizeLabel: formatBytes(s.sizeBytes),
    category: s.category ? { id: s.category.id, name: s.category.name, slug: s.category.slug } : null,
  }));

  const publicCategories = categories.map((c) => ({ id: c.id, name: c.name, slug: c.slug }));
  const contacts = contactLinks(settings);

  return (
    <HomeClient
      sites={publicSites}
      categories={publicCategories}
      settings={{
        siteTitle: settings.siteTitle,
        tagline: settings.tagline,
        heroSubtitle: settings.heroSubtitle,
        creatorName: settings.creatorName,
        creditLine: settings.creditLine,
        footerNote: settings.footerNote,
      }}
      contacts={contacts}
      stats={{
        totalSites: publicSites.length,
        totalCategories: categories.length,
        totalViews,
        totalSizeLabel: formatBytes(totalSize),
      }}
    />
  );
}
