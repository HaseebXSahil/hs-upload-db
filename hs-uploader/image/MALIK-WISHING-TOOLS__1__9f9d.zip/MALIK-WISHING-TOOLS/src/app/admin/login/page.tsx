import type { Metadata } from "next";
import { LoginForm } from "@/components/admin/login-form";
import { isAuthenticated } from "@/lib/auth";
import { redirect } from "next/navigation";

export const metadata: Metadata = { title: "Administrator Login", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

export default async function AdminLoginPage() {
  if (await isAuthenticated()) redirect("/admin/");
  return <LoginForm />;
}
