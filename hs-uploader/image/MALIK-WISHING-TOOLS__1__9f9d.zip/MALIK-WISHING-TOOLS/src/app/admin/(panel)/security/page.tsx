import { SecuritySettings } from "@/components/admin/security-settings";

export const metadata = { title: "Security Settings" };

export default function SecurityPage() {
  return <SecuritySettings />;
}
