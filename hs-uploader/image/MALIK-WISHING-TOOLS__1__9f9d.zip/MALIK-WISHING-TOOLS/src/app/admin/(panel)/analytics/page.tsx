import { AnalyticsView } from "@/components/admin/analytics-view";

export const metadata = { title: "Visitor Analytics" };

export default function AnalyticsPage() {
  return <AnalyticsView />;
}
