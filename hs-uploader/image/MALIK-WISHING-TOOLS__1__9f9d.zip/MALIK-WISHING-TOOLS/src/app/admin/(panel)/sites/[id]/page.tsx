import { db } from "@/lib/db";
import { SiteDetail } from "@/components/admin/site-detail";
import { notFound } from "next/navigation";

export const metadata = { title: "Edit Website" };
export const dynamic = "force-dynamic";

export default async function SiteDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const site = await db.site.findUnique({
    where: { id },
    include: { category: { select: { id: true, name: true } } },
  });
  if (!site) notFound();

  const categories = await db.category.findMany({ orderBy: [{ sortOrder: "asc" }, { name: "asc" }] });

  return (
    <SiteDetail
      site={{
        id: site.id,
        name: site.name,
        slug: site.slug,
        description: site.description,
        categoryId: site.categoryId,
        categoryName: site.category?.name ?? null,
        published: site.published,
        featured: site.featured,
        spaMode: site.spaMode,
        isolated: site.isolated,
        entryFile: site.entryFile,
        fileCount: site.fileCount,
        sizeBytes: site.sizeBytes,
        views: site.views,
        hasThumbnail: !!site.thumbnailData,
        createdAt: site.createdAt.toISOString(),
        updatedAt: site.updatedAt.toISOString(),
      }}
      categories={categories.map((c) => ({ id: c.id, name: c.name }))}
    />
  );
}
