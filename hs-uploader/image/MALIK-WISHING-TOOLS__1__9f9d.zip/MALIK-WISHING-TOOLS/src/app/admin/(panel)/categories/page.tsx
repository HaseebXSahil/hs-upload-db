import { CategoriesManager } from "@/components/admin/categories-manager";

export const metadata = { title: "Categories" };
export const dynamic = "force-dynamic";

export default function CategoriesPage() {
  return <CategoriesManager />;
}
