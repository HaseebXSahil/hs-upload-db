import { SitesManager } from "@/components/admin/sites-manager";

export const metadata = { title: "Manage Websites" };
export const dynamic = "force-dynamic";

export default function ManageSitesPage() {
  return <SitesManager />;
}
