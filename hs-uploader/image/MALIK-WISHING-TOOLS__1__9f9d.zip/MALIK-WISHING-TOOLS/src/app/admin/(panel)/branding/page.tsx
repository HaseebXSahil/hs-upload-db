import { BrandingSettings } from "@/components/admin/branding-settings";

export const metadata = { title: "Branding Settings" };
export const dynamic = "force-dynamic";

export default function BrandingPage() {
  return <BrandingSettings />;
}
