import type { Metadata } from "next";
import { getSessionAdminId } from "@/lib/auth";
import { redirect } from "next/navigation";
import { AdminSidebar } from "@/components/admin/sidebar";

export const metadata: Metadata = {
  title: { default: "Admin Dashboard", template: "%s | MWT Admin" },
  robots: { index: false, follow: false },
};
export const dynamic = "force-dynamic";

export default async function AdminPanelLayout({ children }: { children: React.ReactNode }) {
  const adminId = await getSessionAdminId();
  if (!adminId) redirect("/admin/login");

  return (
    <div className="min-h-screen bg-[#0a0a14] text-[#eceaf6] flex">
      <AdminSidebar />
      <div className="flex-1 min-w-0 flex flex-col">
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1400px] w-full mx-auto">{children}</main>
        <footer className="border-t border-white/5 px-6 py-4 text-center text-xs text-white/30">
          MALIK WISHING TOOLS Admin — secured by Malik Mushahid
        </footer>
      </div>
    </div>
  );
}
