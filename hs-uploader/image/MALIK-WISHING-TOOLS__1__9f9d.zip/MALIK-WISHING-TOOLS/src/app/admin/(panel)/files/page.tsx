import { FileManagerView } from "@/components/admin/file-manager";
import { db } from "@/lib/db";

export const metadata = { title: "File Manager" };
export const dynamic = "force-dynamic";

export default async function FilesPage() {
  const sites = await db.site.findMany({
    orderBy: { name: "asc" },
    select: { id: true, name: true, slug: true, fileCount: true, published: true },
  });
  return <FileManagerView sites={sites} />;
}
