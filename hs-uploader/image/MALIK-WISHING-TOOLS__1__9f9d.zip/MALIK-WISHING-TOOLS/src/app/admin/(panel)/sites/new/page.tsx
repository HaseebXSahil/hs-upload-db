import { SiteForm } from "@/components/admin/site-form";
import { db } from "@/lib/db";

export const metadata = { title: "Add New Website" };
export const dynamic = "force-dynamic";

export default async function NewSitePage() {
  const categories = await db.category.findMany({ orderBy: [{ sortOrder: "asc" }, { name: "asc" }] });
  return (
    <SiteForm
      categories={categories.map((c) => ({ id: c.id, name: c.name }))}
    />
  );
}
