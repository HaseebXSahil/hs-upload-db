import { ContactSettings } from "@/components/admin/settings-forms";

export const metadata = { title: "Contact Settings" };
export const dynamic = "force-dynamic";

export default function SettingsPage() {
  return <ContactSettings />;
}
