import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, authErrorResponse } from "@/lib/auth";
import { bad, ok, getBaseUrl } from "@/lib/api";
import { validSlug, uniqueSlug } from "@/lib/slug";
import { formatBytes } from "@/lib/mime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

// ---------- GET : site detail ----------
export async function GET(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin(req);
    const { id } = await params;
    const site = await db.site.findUnique({
      where: { id },
      include: { category: { select: { id: true, name: true, slug: true } } },
    });
    if (!site) return bad("Website not found.", 404);
    const baseUrl = getBaseUrl(req);
    return ok({
      site: {
        ...site,
        thumbnailData: undefined,
        hasThumbnail: !!site.thumbnailData,
        thumbnailUrl: site.thumbnailData ? `/api/sites/${site.id}/thumbnail?t=${site.updatedAt.getTime()}` : null,
        url: `${baseUrl}/sites/${site.slug}`,
        sizeLabel: formatBytes(site.sizeBytes),
      },
    });
  } catch (e) {
    return authErrorResponse(e);
  }
}

// ---------- PATCH : update metadata / publish state ----------
export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin(req);
    const { id } = await params;
    const site = await db.site.findUnique({ where: { id } });
    if (!site) return bad("Website not found.", 404);

    const body = await req.json().catch(() => ({}));
    const data: Record<string, unknown> = {};

    if (typeof body.name === "string" && body.name.trim()) {
      if (body.name.trim().length > 120) return bad("Name too long (max 120).");
      data.name = body.name.trim();
    }
    if (typeof body.description === "string") {
      if (body.description.length > 500) return bad("Description too long (max 500).");
      data.description = body.description.trim() || null;
    }
    if ("categoryId" in body) {
      const cid = body.categoryId === null || body.categoryId === "" ? null : String(body.categoryId);
      if (cid) {
        const cat = await db.category.findUnique({ where: { id: cid } });
        if (!cat) return bad("Category not found.");
      }
      data.categoryId = cid;
    }
    if (typeof body.published === "boolean") data.published = body.published;
    if (typeof body.featured === "boolean") data.featured = body.featured;
    if (typeof body.spaMode === "boolean") data.spaMode = body.spaMode;
    if (typeof body.isolated === "boolean") data.isolated = body.isolated;

    // Slug change (this changes the public URL — guarded on the client with a confirm)
    if (typeof body.slug === "string" && body.slug !== site.slug) {
      const desired = body.slug.trim();
      if (!validSlug(desired)) {
        return bad("URL slug may only contain lowercase letters, numbers and hyphens (2-60 chars).");
      }
      data.slug = await uniqueSlug(desired, site.id);
    }

    const updated = await db.site.update({ where: { id }, data });
    const baseUrl = getBaseUrl(req);
    return ok({
      ok: true,
      site: { ...updated, thumbnailData: undefined, hasThumbnail: !!updated.thumbnailData, url: `${baseUrl}/sites/${updated.slug}` },
    });
  } catch (e) {
    return authErrorResponse(e);
  }
}

// ---------- DELETE : remove site entirely ----------
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin(req);
    const { id } = await params;
    const site = await db.site.findUnique({ where: { id } });
    if (!site) return bad("Website not found.", 404);
    await db.site.delete({ where: { id } }); // cascades files/versions/visits
    return ok({ ok: true });
  } catch (e) {
    return authErrorResponse(e);
  }
}
