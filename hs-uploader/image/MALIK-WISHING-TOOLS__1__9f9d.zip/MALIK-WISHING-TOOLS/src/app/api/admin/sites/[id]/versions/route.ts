import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, authErrorResponse } from "@/lib/auth";
import { bad, ok } from "@/lib/api";
import { restoreVersion } from "@/lib/site-files";
import { formatBytes } from "@/lib/mime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

// ---------- GET : list available versions ----------
export async function GET(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin(req);
    const { id } = await params;
    const versions = await db.siteVersion.findMany({
      where: { siteId: id },
      orderBy: { version: "desc" },
      select: { id: true, version: true, note: true, fileCount: true, sizeBytes: true, createdAt: true },
    });
    return ok({ versions: versions.map((v) => ({ ...v, sizeLabel: formatBytes(v.sizeBytes) })) });
  } catch (e) {
    return authErrorResponse(e);
  }
}

// ---------- POST : restore a version ----------
export async function POST(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin(req);
    const { id } = await params;
    const body = await req.json().catch(() => ({}));
    const version = Number(body?.version);
    if (!Number.isInteger(version) || version < 1) return bad("Invalid version number.");

    const site = await db.site.findUnique({ where: { id }, select: { id: true } });
    if (!site) return bad("Website not found.", 404);

    try {
      const result = await restoreVersion(id, version);
      return ok({ ok: true, ...result });
    } catch {
      return bad("That version could not be restored (snapshot missing).", 404);
    }
  } catch (e) {
    return authErrorResponse(e);
  }
}
