import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, authErrorResponse } from "@/lib/auth";
import { ensureBootstrap } from "@/lib/bootstrap";
import { getSettings, saveSettings, contactLinks } from "@/lib/settings";
import { bad, ok } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------- GET : current settings ----------
export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);
    await ensureBootstrap();
    const settings = await getSettings();
    return ok({ settings, contactLinks: contactLinks(settings) });
  } catch (e) {
    return authErrorResponse(e);
  }
}

// ---------- PUT : save settings ----------
export async function PUT(req: NextRequest) {
  try {
    await requireAdmin(req);
    const body = await req.json().catch(() => ({}));
    if (!body || typeof body !== "object") return bad("Invalid payload.");

    // Validate phone / links before saving
    const errors: string[] = [];
    if ("whatsappPhone" in body) {
      const digits = String(body.whatsappPhone).replace(/[^0-9]/g, "");
      if (String(body.whatsappPhone).trim() && digits.length < 8) {
        errors.push("WhatsApp phone number must contain at least 8 digits with country code (e.g. 923001234567).");
      }
    }
    if ("whatsappLink" in body && String(body.whatsappLink).trim()) {
      try {
        const u = new URL(String(body.whatsappLink));
        if (u.protocol !== "https:") errors.push("WhatsApp link must start with https://");
      } catch {
        errors.push("WhatsApp link is not a valid URL.");
      }
    }
    if ("telegramLink" in body && String(body.telegramLink).trim()) {
      try {
        const u = new URL(String(body.telegramLink));
        if (u.protocol !== "https:") errors.push("Telegram link must start with https://");
      } catch {
        errors.push("Telegram link is not a valid URL.");
      }
    }
    if ("telegramUsername" in body && String(body.telegramUsername).replace(/^@/, "").trim()) {
      const user = String(body.telegramUsername).replace(/^@/, "").trim();
      if (!/^[A-Za-z0-9_]{4,64}$/.test(user)) errors.push("Telegram username must be 4-64 letters, numbers or underscores.");
    }
    if ("siteTitle" in body && !String(body.siteTitle).trim()) errors.push("Website title cannot be empty.");
    if ("creatorName" in body && !String(body.creatorName).trim()) errors.push("Creator name cannot be empty.");
    if (errors.length) return bad(errors.join(" "));

    const settings = await saveSettings(body);
    return ok({ ok: true, settings, contactLinks: contactLinks(settings) });
  } catch (e) {
    return authErrorResponse(e);
  }
}
