import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, authErrorResponse } from "@/lib/auth";
import { bad, ok } from "@/lib/api";
import { slugify } from "@/lib/slug";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------- GET : all categories ----------
export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);
    const categories = await db.category.findMany({
      orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
      include: { _count: { select: { sites: true } } },
    });
    return ok({ categories });
  } catch (e) {
    return authErrorResponse(e);
  }
}

// ---------- POST : create category ----------
export async function POST(req: NextRequest) {
  try {
    await requireAdmin(req);
    const body = await req.json().catch(() => ({}));
    const name = String(body?.name ?? "").trim();
    if (!name) return bad("Category name is required.");
    if (name.length > 60) return bad("Category name is too long (max 60).");

    const slug = slugify(name) || `cat-${Date.now().toString(36)}`;
    const exists = await db.category.findFirst({ where: { OR: [{ name }, { slug }] } });
    if (exists) return bad("A category with this name already exists.");

    const category = await db.category.create({
      data: { name, slug, description: String(body?.description ?? "").trim() || null },
    });
    return ok({ ok: true, category });
  } catch (e) {
    return authErrorResponse(e);
  }
}
