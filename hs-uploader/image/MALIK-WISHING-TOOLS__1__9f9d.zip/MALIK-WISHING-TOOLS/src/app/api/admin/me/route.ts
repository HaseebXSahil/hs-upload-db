import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, authErrorResponse } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const adminId = await requireAdmin(req);
    const admin = await db.admin.findUnique({
      where: { id: adminId },
      select: { username: true, lastLoginAt: true, createdAt: true },
    });
    if (!admin) return NextResponse.json({ error: "Session invalid" }, { status: 401 });
    return NextResponse.json({ admin });
  } catch (e) {
    return authErrorResponse(e);
  }
}
