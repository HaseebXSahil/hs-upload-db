import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword, createSessionToken, setSessionCookie } from "@/lib/auth";
import { ensureBootstrap } from "@/lib/bootstrap";
import { rateLimit, clientIp } from "@/lib/ratelimit";
import { bad } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  // Rate limit: 8 attempts / 10 minutes per IP
  const rl = rateLimit(`login:${clientIp(req)}`, 8, 10 * 60 * 1000);
  if (!rl.ok) {
    return NextResponse.json(
      { error: `Too many login attempts. Try again in ${Math.ceil(rl.retryAfterSec / 60)} minute(s).` },
      { status: 429, headers: { "Retry-After": String(rl.retryAfterSec) } }
    );
  }

  try {
    await ensureBootstrap();
    const body = await req.json().catch(() => null);
    const username = typeof body?.username === "string" ? body.username.trim() : "";
    const password = typeof body?.password === "string" ? body.password : "";
    if (!username || !password) return bad("Username and password are required.");

    const admin = await db.admin.findUnique({ where: { username } });
    // Uniform error message: never reveal whether the username exists
    const okPassword = admin ? verifyPassword(password, admin.passwordHash) : false;
    if (!admin || !okPassword) {
      return bad("Invalid username or password.", 401);
    }

    await db.admin.update({ where: { id: admin.id }, data: { lastLoginAt: new Date() } });
    const token = await createSessionToken(admin.id);
    const res = NextResponse.json({ ok: true, username: admin.username });
    await setSessionCookie(res, token);
    return res;
  } catch (e) {
    console.error("[login]", e);
    return bad("Login failed. Please try again.", 500);
  }
}
