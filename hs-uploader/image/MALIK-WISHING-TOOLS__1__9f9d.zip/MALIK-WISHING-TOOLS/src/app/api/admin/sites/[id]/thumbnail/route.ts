import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, authErrorResponse } from "@/lib/auth";
import { bad, ok } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

// ---------- GET : serve the thumbnail image (admin only) ----------
export async function GET(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin(req);
    const { id } = await params;
    const site = await db.site.findUnique({
      where: { id },
      select: { thumbnailData: true, thumbnailMime: true },
    });
    if (!site?.thumbnailData) return new NextResponse("Not found", { status: 404 });
    return new NextResponse(new Uint8Array(Buffer.from(site.thumbnailData)), {
      headers: {
        "Content-Type": site.thumbnailMime ?? "image/png",
        "Cache-Control": "private, max-age=60",
      },
    });
  } catch (e) {
    return authErrorResponse(e);
  }
}

// ---------- POST : upload / replace thumbnail ----------
export async function POST(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin(req);
    const { id } = await params;
    const site = await db.site.findUnique({ where: { id } });
    if (!site) return bad("Website not found.", 404);

    const contentType = req.headers.get("content-type") ?? "";
    if (!contentType.includes("multipart/form-data")) return bad("Expected multipart/form-data.");
    const form = await req.formData();
    const thumbnail = form.get("thumbnail") as File | null;
    const remove = String(form.get("remove") ?? "false") === "true";

    if (remove) {
      await db.site.update({ where: { id }, data: { thumbnailData: null, thumbnailMime: null } });
      return ok({ ok: true, hasThumbnail: false });
    }
    if (!thumbnail || thumbnail.size === 0) return bad("Please choose a thumbnail image.");

    if (thumbnail.size > 4 * 1024 * 1024) return bad("Thumbnail must be smaller than 4 MB.");
    const mime = thumbnail.type;
    if (!/^image\/(png|jpe?g|webp|gif|avif)$/.test(mime)) return bad("Thumbnail must be a PNG, JPG, WEBP or GIF image.");

    const data = Buffer.from(await thumbnail.arrayBuffer());
    await db.site.update({ where: { id }, data: { thumbnailData: data, thumbnailMime: mime } });
    return ok({ ok: true, hasThumbnail: true });
  } catch (e) {
    return authErrorResponse(e);
  }
}
