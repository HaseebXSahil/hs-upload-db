import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, authErrorResponse, verifyPassword, hashPassword } from "@/lib/auth";
import { bad, ok } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------- POST : change admin password ----------
export async function POST(req: NextRequest) {
  try {
    const adminId = await requireAdmin(req);
    const body = await req.json().catch(() => ({}));
    const currentPassword = String(body?.currentPassword ?? "");
    const newPassword = String(body?.newPassword ?? "");

    if (!currentPassword || !newPassword) return bad("Current and new passwords are required.");
    if (newPassword.length < 8) return bad("New password must be at least 8 characters long.");
    if (newPassword.length > 128) return bad("New password is too long (max 128 characters).");

    const admin = await db.admin.findUnique({ where: { id: adminId } });
    if (!admin) return bad("Account not found.", 404);
    if (!verifyPassword(currentPassword, admin.passwordHash)) {
      return bad("Current password is incorrect.", 403);
    }

    await db.admin.update({
      where: { id: adminId },
      data: { passwordHash: hashPassword(newPassword) },
    });
    return ok({ ok: true, message: "Password changed successfully." });
  } catch (e) {
    return authErrorResponse(e);
  }
}
