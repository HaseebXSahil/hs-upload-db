import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, authErrorResponse } from "@/lib/auth";
import { ensureBootstrap } from "@/lib/bootstrap";
import { bad, ok, getBaseUrl } from "@/lib/api";
import { processZip, processLooseFiles, findEntry, UploadError, LIMITS } from "@/lib/upload";
import { replaceSiteFiles } from "@/lib/site-files";
import { uniqueSlug, validSlug } from "@/lib/slug";
import { rateLimit, clientIp } from "@/lib/ratelimit";
import { getMime, isHtmlPath, formatBytes } from "@/lib/mime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

// ---------- GET /api/admin/sites : list all sites ----------
export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);
    await ensureBootstrap();
    const sites = await db.site.findMany({
      include: { category: { select: { id: true, name: true, slug: true } } },
      orderBy: { createdAt: "desc" },
    });
    const baseUrl = getBaseUrl(req);
    return ok({
      sites: sites.map((s) => ({
        ...s,
        thumbnailData: undefined,
        hasThumbnail: !!s.thumbnailData,
        url: `${baseUrl}/sites/${s.slug}`,
        sizeLabel: formatBytes(s.sizeBytes),
      })),
    });
  } catch (e) {
    return authErrorResponse(e);
  }
}

// ---------- POST /api/admin/sites : create + upload website ----------
export async function POST(req: NextRequest) {
  try {
    await requireAdmin(req);

    // Upload rate limit: 30 uploads / hour per IP
    const rl = rateLimit(`upload:${clientIp(req)}`, 30, 60 * 60 * 1000);
    if (!rl.ok) return bad(`Upload limit reached. Try again in ${Math.ceil(rl.retryAfterSec / 60)} minute(s).`, 429);

    const contentType = req.headers.get("content-type") ?? "";
    if (!contentType.includes("multipart/form-data")) {
      return bad("Upload must be sent as multipart/form-data.");
    }

    const form = await req.formData();
    const name = String(form.get("name") ?? "").trim();
    const slugInput = String(form.get("slug") ?? "").trim();
    const description = String(form.get("description") ?? "").trim();
    const categoryId = String(form.get("categoryId") ?? "").trim();
    const publishNow = String(form.get("published") ?? "true") === "true";
    const featured = String(form.get("featured") ?? "false") === "true";
    const spaMode = String(form.get("spaMode") ?? "false") === "true";
    const mode = String(form.get("mode") ?? "auto"); // auto | zip | html

    if (!name) return bad("Website name is required.");
    if (name.length > 120) return bad("Website name is too long (max 120 characters).");
    if (description && description.length > 500) return bad("Description is too long (max 500 characters).");

    // --- gather uploaded files ---
    const zipFile = form.get("zip") as File | null;
    const htmlFiles = form.getAll("files").filter((f): f is File => f instanceof File && f.size > 0);
    const thumbnail = form.get("thumbnail") as File | null;

    let processed: import("@/lib/upload").ProcessResult;
    if (mode === "zip" || (mode === "auto" && zipFile && zipFile.size > 0)) {
      if (!zipFile || zipFile.size === 0) return bad("Please choose a ZIP file to upload.");
      try {
        processed = await processZip(Buffer.from(await zipFile.arrayBuffer()));
      } catch (e) {
        if (e instanceof UploadError) return bad(e.message);
        throw e;
      }
    } else {
      if (htmlFiles.length === 0) return bad("Please attach a ZIP file or at least one HTML file.");
      try {
        processed = await processLooseFiles(form);
      } catch (e) {
        if (e instanceof UploadError) return bad(e.message);
        throw e;
      }
    }

    // mime + entry point
    for (const f of processed.files) f.mime = getMime(f.path);
    const entry = findEntry(processed.files);
    if (!entry) {
      return bad("No HTML entry point found. The upload must include an index.html (or any .html file).");
    }

    // --- slug ---
    const desired = slugInput || name;
    if (slugInput && !validSlug(slugInput)) {
      return bad("URL slug may only contain lowercase letters, numbers and hyphens (2-60 chars).");
    }
    const slug = await uniqueSlug(desired);

    // --- category (optional) ---
    if (categoryId) {
      const cat = await db.category.findUnique({ where: { id: categoryId } });
      if (!cat) return bad("Selected category no longer exists.");
    }

    // --- thumbnail ---
    let thumbnailMime: string | null = null;
    let thumbnailData: Buffer | null = null;
    if (thumbnail && thumbnail.size > 0) {
      if (thumbnail.size > 4 * 1024 * 1024) return bad("Thumbnail must be smaller than 4 MB.");
      const tmime = thumbnail.type;
      if (!/^image\/(png|jpe?g|webp|gif|avif)$/.test(tmime)) return bad("Thumbnail must be a PNG, JPG, WEBP or GIF image.");
      thumbnailMime = tmime;
      thumbnailData = Buffer.from(await thumbnail.arrayBuffer());
    }

    // --- create site + files atomically-ish ---
    const totalSize = processed.files.reduce((s, f) => s + f.data.length, 0);
    const site = await db.site.create({
      data: {
        name,
        slug,
        description: description || null,
        categoryId: categoryId || null,
        published: publishNow,
        featured,
        spaMode,
        entryFile: entry,
        sizeBytes: totalSize,
        fileCount: processed.files.length,
        currentVersion: 1,
        thumbnailMime,
        thumbnailData,
      },
    });

    await replaceSiteFiles(site.id, processed.files, { snapshot: false });

    const baseUrl = getBaseUrl(req);
    return ok({
      ok: true,
      site: { ...site, thumbnailData: undefined },
      url: `${baseUrl}/sites/${site.slug}`,
      entry,
      warnings: processed.warnings,
    });
  } catch (e) {
    console.error("[sites:POST]", e);
    return bad("Upload failed due to a server error. Please try again.", 500);
  }
}
