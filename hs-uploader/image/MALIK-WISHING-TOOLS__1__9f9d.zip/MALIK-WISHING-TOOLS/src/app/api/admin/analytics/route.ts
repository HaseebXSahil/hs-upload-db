import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, authErrorResponse } from "@/lib/auth";
import { ok } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------- GET : visitor analytics ----------
export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);

    const url = new URL(req.url);
    const days = Math.min(Math.max(Number(url.searchParams.get("days") ?? 30), 7), 90);

    const since = new Date(Date.now() - (days - 1) * 24 * 3600 * 1000);
    since.setHours(0, 0, 0, 0);

    const [visits, totals, perSite] = await Promise.all([
      db.siteVisit.findMany({
        where: { createdAt: { gte: since } },
        select: { createdAt: true, siteId: true, ipHash: true },
      }),
      db.siteVisit.aggregate({ _count: true }),
      db.site.findMany({
        orderBy: { views: "desc" },
        take: 12,
        select: { id: true, name: true, slug: true, views: true, published: true },
      }),
    ]);

    // Series per day
    const perDay = new Map<string, number>();
    for (let i = 0; i < days; i++) {
      const d = new Date(since.getTime() + i * 24 * 3600 * 1000);
      perDay.set(d.toISOString().slice(0, 10), 0);
    }
    for (const v of visits) {
      const key = v.createdAt.toISOString().slice(0, 10);
      if (perDay.has(key)) perDay.set(key, (perDay.get(key) ?? 0) + 1);
    }

    // Unique visitors (by ipHash)
    const uniqueVisitors = new Set(visits.map((v) => v.ipHash).filter(Boolean)).size;

    // Per-site visits in range
    const perSiteRange = new Map<string, number>();
    for (const v of visits) {
      if (!v.siteId) continue;
      perSiteRange.set(v.siteId, (perSiteRange.get(v.siteId) ?? 0) + 1);
    }

    return ok({
      totals: { allTime: totals._count, range: visits.length, uniqueVisitors },
      series: Array.from(perDay.entries()).map(([date, count]) => ({ date, count })),
      perSite: perSite.map((s) => ({
        ...s,
        viewsInRange: perSiteRange.get(s.id) ?? 0,
      })),
    });
  } catch (e) {
    return authErrorResponse(e);
  }
}
