import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, authErrorResponse } from "@/lib/auth";
import { bad, ok } from "@/lib/api";
import { processZip, processLooseFiles, findEntry, UploadError } from "@/lib/upload";
import { listSiteFiles, deleteSiteFile, writeSiteFiles } from "@/lib/site-files";
import { getMime, formatBytes, isHtmlPath } from "@/lib/mime";
import { rateLimit, clientIp } from "@/lib/ratelimit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

// ---------- GET : list files of a site ----------
export async function GET(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin(req);
    const { id } = await params;
    const site = await db.site.findUnique({ where: { id }, select: { id: true, entryFile: true } });
    if (!site) return bad("Website not found.", 404);
    const files = await listSiteFiles(id);
    return ok({
      entryFile: site.entryFile,
      files: files.map((f) => ({ ...f, sizeLabel: formatBytes(f.size), isHtml: isHtmlPath(f.path) })),
    });
  } catch (e) {
    return authErrorResponse(e);
  }
}

// ---------- POST : add / replace files ----------
export async function POST(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin(req);
    const rl = rateLimit(`files:${clientIp(req)}`, 60, 60 * 60 * 1000);
    if (!rl.ok) return bad("Too many uploads. Try again later.", 429);

    const { id } = await params;
    const site = await db.site.findUnique({ where: { id } });
    if (!site) return bad("Website not found.", 404);

    const contentType = req.headers.get("content-type") ?? "";
    if (!contentType.includes("multipart/form-data")) return bad("Expected multipart/form-data.");
    const form = await req.formData();
    const zipFile = form.get("zip") as File | null;

    let processed: import("@/lib/upload").ProcessResult;
    try {
      if (zipFile && zipFile.size > 0) {
        processed = await processZip(Buffer.from(await zipFile.arrayBuffer()));
      } else {
        processed = await processLooseFiles(form);
      }
    } catch (e) {
      if (e instanceof UploadError) return bad(e.message);
      throw e;
    }

    const replaceAll = String(form.get("replaceAll") ?? "false") === "true";
    for (const f of processed.files) f.mime = getMime(f.path);

    if (replaceAll) {
      await writeSiteFiles(id, processed.files, { mode: "replace", snapshot: true, note: "Files replaced by upload" });
    } else {
      // Merge: add/overwrite given files, keep the rest
      await writeSiteFiles(id, processed.files, { mode: "merge", snapshot: true, note: "Additional files uploaded" });
      const entry = findEntry(processed.files);
      if (entry && isHtmlPath(entry) && !isHtmlPath(site.entryFile)) {
        await db.site.update({ where: { id }, data: { entryFile: entry } });
      }
    }

    const updated = await db.site.findUnique({ where: { id }, select: { entryFile: true, fileCount: true, sizeBytes: true } });
    return ok({ ok: true, warnings: processed.warnings, ...updated, sizeLabel: formatBytes(updated?.sizeBytes ?? 0) });
  } catch (e) {
    console.error("[files:POST]", e);
    return bad("File upload failed.", 500);
  }
}

// ---------- DELETE : remove a single file ----------
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin(req);
    const { id } = await params;
    const site = await db.site.findUnique({ where: { id } });
    if (!site) return bad("Website not found.", 404);

    const url = new URL(req.url);
    const path = url.searchParams.get("path") ?? "";
    if (!path) return bad("Missing file path.");
    if (path === site.entryFile) return bad("This file is the entry point. Choose another entry file first or replace the website files.");

    await deleteSiteFile(id, path);
    const files = await listSiteFiles(id);
    await db.site.update({
      where: { id },
      data: { sizeBytes: files.reduce((s, f) => s + f.size, 0), fileCount: files.length },
    });
    return ok({ ok: true, remaining: files.length });
  } catch (e) {
    return authErrorResponse(e);
  }
}
