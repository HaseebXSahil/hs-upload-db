import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, authErrorResponse } from "@/lib/auth";
import { ensureBootstrap } from "@/lib/bootstrap";
import { ok } from "@/lib/api";
import { formatBytes } from "@/lib/mime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------- GET : dashboard statistics ----------
export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);
    await ensureBootstrap();

    const [totalSites, publishedSites, featuredSites, totalCategories, totalVisits, visits7d] =
      await Promise.all([
        db.site.count(),
        db.site.count({ where: { published: true } }),
        db.site.count({ where: { featured: true } }),
        db.category.count(),
        db.siteVisit.count(),
        db.siteVisit.count({ where: { createdAt: { gte: new Date(Date.now() - 7 * 24 * 3600 * 1000) } } }),
      ]);

    const sizeAgg = await db.site.aggregate({ _sum: { sizeBytes: true }, _count: true });
    const recentUploads = await db.site.findMany({
      orderBy: { createdAt: "desc" },
      take: 6,
      select: { id: true, name: true, slug: true, published: true, createdAt: true, fileCount: true, sizeBytes: true },
    });
    const topSites = await db.site.findMany({
      where: { published: true },
      orderBy: { views: "desc" },
      take: 5,
      select: { id: true, name: true, slug: true, views: true },
    });
    const admin = await db.admin.findFirst({ select: { lastLoginAt: true, createdAt: true } });

    // Visits per day for the last 14 days
    const since = new Date(Date.now() - 13 * 24 * 3600 * 1000);
    since.setHours(0, 0, 0, 0);
    const visitRows = await db.siteVisit.findMany({
      where: { createdAt: { gte: since } },
      select: { createdAt: true },
    });
    const perDay = new Map<string, number>();
    for (let i = 0; i < 14; i++) {
      const d = new Date(since.getTime() + i * 24 * 3600 * 1000);
      perDay.set(d.toISOString().slice(0, 10), 0);
    }
    for (const v of visitRows) {
      const key = v.createdAt.toISOString().slice(0, 10);
      if (perDay.has(key)) perDay.set(key, (perDay.get(key) ?? 0) + 1);
    }
    const visitSeries = Array.from(perDay.entries()).map(([date, count]) => ({ date, count }));

    return ok({
      stats: {
        totalSites,
        publishedSites,
        unpublishedSites: totalSites - publishedSites,
        featuredSites,
        totalCategories,
        totalVisits,
        visits7d,
        storageBytes: sizeAgg._sum.sizeBytes ?? 0,
        storageLabel: formatBytes(sizeAgg._sum.sizeBytes ?? 0),
        fileCount: sizeAgg._count,
        lastLoginAt: admin?.lastLoginAt ?? null,
      },
      recentUploads: recentUploads.map((r) => ({ ...r, sizeLabel: formatBytes(r.sizeBytes) })),
      topSites,
      visitSeries,
    });
  } catch (e) {
    return authErrorResponse(e);
  }
}
