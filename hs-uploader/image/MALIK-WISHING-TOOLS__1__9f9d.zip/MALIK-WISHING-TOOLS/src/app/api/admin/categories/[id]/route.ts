import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, authErrorResponse } from "@/lib/auth";
import { bad, ok } from "@/lib/api";
import { slugify } from "@/lib/slug";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

// ---------- PATCH : rename / reorder ----------
export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin(req);
    const { id } = await params;
    const category = await db.category.findUnique({ where: { id } });
    if (!category) return bad("Category not found.", 404);

    const body = await req.json().catch(() => ({}));
    const data: Record<string, unknown> = {};
    if (typeof body.name === "string" && body.name.trim()) {
      if (body.name.trim().length > 60) return bad("Category name too long (max 60).");
      data.name = body.name.trim();
      data.slug = slugify(body.name) || category.slug;
      const clash = await db.category.findFirst({ where: { name: data.name, NOT: { id } } });
      if (clash) return bad("Another category already uses this name.");
    }
    if (typeof body.description === "string") data.description = body.description.trim() || null;
    if (typeof body.sortOrder === "number") data.sortOrder = body.sortOrder;

    const updated = await db.category.update({ where: { id }, data });
    return ok({ ok: true, category: updated });
  } catch (e) {
    return authErrorResponse(e);
  }
}

// ---------- DELETE : remove category (sites become uncategorized) ----------
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin(req);
    const { id } = await params;
    const category = await db.category.findUnique({ where: { id }, include: { _count: { select: { sites: true } } } });
    if (!category) return bad("Category not found.", 404);
    await db.category.delete({ where: { id } }); // sites keep existing, become uncategorized
    return ok({ ok: true, detachedSites: category._count.sites });
  } catch (e) {
    return authErrorResponse(e);
  }
}
