import { NextRequest, NextResponse } from "next/server";
import { ok } from "@/lib/api";
import { ensureBootstrap } from "@/lib/bootstrap";
import { getSettings, contactLinks } from "@/lib/settings";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------- GET /api/public/settings : branding + contacts for the homepage ----------
export async function GET(_req: NextRequest) {
  await ensureBootstrap();
  const settings = await getSettings();
  return ok({ settings, contactLinks: contactLinks(settings) });
}
