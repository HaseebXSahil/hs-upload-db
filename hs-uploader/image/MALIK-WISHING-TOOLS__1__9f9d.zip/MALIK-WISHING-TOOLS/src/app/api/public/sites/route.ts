import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ok } from "@/lib/api";
import { ensureBootstrap } from "@/lib/bootstrap";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------- GET /api/public/sites : published sites for the homepage ----------
export async function GET(_req: NextRequest) {
  await ensureBootstrap();
  const sites = await db.site.findMany({
    where: { published: true },
    include: { category: { select: { id: true, name: true, slug: true } } },
    orderBy: [{ featured: "desc" }, { updatedAt: "desc" }],
  });
  return ok({
    sites: sites.map((s) => ({
      id: s.id,
      name: s.name,
      slug: s.slug,
      description: s.description,
      featured: s.featured,
      views: s.views,
      hasThumbnail: !!s.thumbnailData,
      updatedAt: s.updatedAt,
      category: s.category,
    })),
  });
}
