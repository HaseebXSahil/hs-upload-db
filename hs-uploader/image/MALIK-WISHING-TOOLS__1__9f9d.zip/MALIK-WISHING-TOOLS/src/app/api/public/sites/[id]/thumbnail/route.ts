import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

// ---------- GET : public thumbnail for published site cards ----------
export async function GET(_req: NextRequest, { params }: Params) {
  const { id } = await params;
  const site = await db.site.findUnique({
    where: { id },
    select: { published: true, thumbnailData: true, thumbnailMime: true },
  });
  if (!site || !site.published || !site.thumbnailData) {
    return new NextResponse("Not found", { status: 404 });
  }
  return new NextResponse(new Uint8Array(Buffer.from(site.thumbnailData)), {
    headers: {
      "Content-Type": site.thumbnailMime ?? "image/png",
      "Cache-Control": "public, max-age=120",
    },
  });
}
