import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { visitorHash } from "@/lib/api";
import { rateLimit, clientIp } from "@/lib/ratelimit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------- POST /api/track : record a homepage visit ----------
export async function POST(req: NextRequest) {
  const rl = rateLimit(`track:${clientIp(req)}`, 60, 60 * 1000);
  if (!rl.ok) return NextResponse.json({ ok: false }, { status: 429 });

  const body = await req.json().catch(() => ({}));
  const path = typeof body?.path === "string" && body.path.startsWith("/") ? body.path.slice(0, 300) : "/";

  await db.siteVisit.create({
    data: {
      siteId: null, // homepage visit
      path,
      ipHash: visitorHash(req),
      referrer: req.headers.get("referer")?.slice(0, 300) ?? null,
      userAgent: req.headers.get("user-agent")?.slice(0, 300) ?? null,
    },
  });
  return NextResponse.json({ ok: true });
}
