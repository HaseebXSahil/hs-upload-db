import type { Metadata, Viewport } from "next";
import { Outfit, Inter, Great_Vibes } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Providers } from "@/components/providers";

const outfit = Outfit({
  variable: "--font-outfit",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800", "900"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const signature = Great_Vibes({
  variable: "--font-signature",
  subsets: ["latin"],
  weight: "400",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "MALIK WISHING TOOLS — Premium Wishing Websites & Digital Celebration Tools",
    template: "%s | MALIK WISHING TOOLS",
  },
  description:
    "Discover, open and share beautifully crafted wishing websites — birthdays, anniversaries, proposals and every special moment. A premium platform by Malik Mushahid.",
  keywords: ["wishing tools", "birthday wishes", "anniversary", "greeting cards", "Malik Mushahid", "Malik Wishing Tools"],
  authors: [{ name: "Malik Mushahid" }],
  creator: "Malik Mushahid",
  applicationName: "MALIK WISHING TOOLS",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icons/icon-192.png", sizes: "192x192" }],
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "MALIK WISHING TOOLS",
  },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: "#07070f",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${outfit.variable} ${inter.variable} ${signature.variable} antialiased bg-background text-foreground`}
        style={{ fontFamily: "var(--font-inter), system-ui, sans-serif" }}
      >
        <Providers>
          {children}
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}
