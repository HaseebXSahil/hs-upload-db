import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readSiteFile } from "@/lib/site-files";
import { getMime, isHtmlPath } from "@/lib/mime";
import { getSessionAdminId } from "@/lib/auth";
import { visitorHash } from "@/lib/api";
import { rateLimit, clientIp } from "@/lib/ratelimit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Params = { params: Promise<{ slug: string; path?: string[] }> };

const MAX_BODY = 30 * 1024 * 1024;

function notFound(message: string, status = 404) {
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta name="robots" content="noindex"/>
<title>${status === 404 ? "Page not found" : "Not available"} - MALIK WISHING TOOLS</title>
<style>
  body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#07070f;color:#e7e7f2;font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif}
  .card{text-align:center;padding:48px 32px;max-width:420px}
  h1{font-size:64px;margin:0;background:linear-gradient(135deg,#f5c76a,#d946ef 60%,#a855f7);-webkit-background-clip:text;background-clip:text;color:transparent}
  p{color:#9a9ab0;margin:12px 0 28px;line-height:1.6}
  a{display:inline-block;padding:12px 28px;border-radius:999px;background:linear-gradient(135deg,#d946ef,#a855f7);color:#fff;text-decoration:none;font-weight:600}
</style>
</head>
<body><div class="card"><h1>${status}</h1><p>${message}</p><a href="/">Back to MALIK WISHING TOOLS</a></div></body>
</html>`;
  return new NextResponse(html, {
    status,
    headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" },
  });
}

/**
 * Serves uploaded websites: /sites/<slug>/...
 * - Redirects /sites/<slug> -> /sites/<slug>/ so relative asset paths resolve
 * - Clean-URL resolution: /about -> about.html or about/index.html
 * - Optional SPA fallback (site.spaMode) for client-side routing
 * - Isolation: sandboxed CSP origin for uploaded content (cannot touch admin data)
 * - View tracking for published sites (skips admin previews)
 */
export async function GET(req: NextRequest, { params }: Params) {
  const { slug, path } = await params;

  const site = await db.site.findUnique({ where: { slug } });
  if (!site) return notFound("This website does not exist on MALIK WISHING TOOLS.");

  const isAdmin = (await getSessionAdminId()) !== null;
  if (!site.published && !isAdmin) {
    return notFound("This website is not published yet. Please check back soon.");
  }

  const relParts = path ?? [];
  const url = new URL(req.url);
  const deepLink = relParts.length > 0;

  // -------- Site root: /sites/<slug> or /sites/<slug>/ --------
  if (!deepLink) {
    // Normalize /sites/<slug> -> /sites/<slug>/ so that relative asset URLs
    // inside the uploaded HTML (e.g. ./style.css) resolve to the site folder.
    if (!url.pathname.endsWith("/")) {
      return NextResponse.redirect(new URL(url.pathname + "/" + url.search, req.url), 308);
    }
    if (isAdmin && !site.published) {
      // no view counting for admin previews
    } else {
      const rl = rateLimit(`view:${site.id}:${clientIp(req)}`, 30, 60 * 1000);
      if (rl.ok) {
        await db.$transaction([
          db.site.update({ where: { id: site.id }, data: { views: { increment: 1 } } }),
          db.siteVisit.create({
            data: {
              siteId: site.id,
              path: "/",
              ipHash: visitorHash(req),
              referrer: req.headers.get("referer")?.slice(0, 300) ?? null,
              userAgent: req.headers.get("user-agent")?.slice(0, 300) ?? null,
            },
          }),
        ]);
      }
    }
    return serveBuffer(req, site.id, site.entryFile, site.isolated, true, site.published);
  }

  // -------- Deep paths --------
  const requested = relParts.map(decodeURIComponent).join("/");
  if (requested.includes("..")) return notFound("Invalid path.");

  const candidates = [requested];
  if (isHtmlPath(requested) || !requested.includes(".")) {
    candidates.push(`${requested}/index.html`);
    candidates.push(`${requested}.html`);
  }
  // Never allow the raw directory-style dotfiles
  const safeCandidates = candidates.filter((c) => !c.split("/").some((s) => s.startsWith(".")));

  for (const candidate of safeCandidates) {
    const data = await readSiteFile(site.id, candidate);
    if (data) {
      return serveBuffer(req, site.id, candidate, site.isolated, false, site.published, data);
    }
  }

  // SPA fallback: serve entry file for client-side routing
  if (site.spaMode) {
    return serveBuffer(req, site.id, site.entryFile, site.isolated, false, site.published);
  }

  return notFound("This page was not found on this website.");
}

async function serveBuffer(
  req: NextRequest,
  siteId: string,
  filePath: string,
  isolated: boolean,
  isEntry: boolean,
  published: boolean,
  preloaded?: Buffer
): Promise<NextResponse> {
  const data = preloaded ?? (await readSiteFile(siteId, filePath));
  if (!data) return notFound("This page was not found on this website.");
  if (data.length > MAX_BODY) return notFound("File too large to serve.");

  const mime = getMime(filePath);
  const isHtml = isHtmlPath(filePath);
  const headers = new Headers();
  headers.set("Content-Type", mime);
  headers.set("X-Content-Type-Options", "nosniff");
  headers.set("Referrer-Policy", "no-referrer");

  if (isHtml) {
    headers.set("Cache-Control", "no-cache");
    if (!published) headers.set("X-Robots-Tag", "noindex");
  } else {
    headers.set("Cache-Control", "public, max-age=300");
  }

  if (isolated) {
    // Sandboxed (opaque) origin: uploaded JS cannot read cookies/storage or call
    // the main application's APIs with credentials. Its own assets still load
    // because every site file response carries Access-Control-Allow-Origin: *.
    headers.set(
      "Content-Security-Policy",
      "sandbox allow-scripts allow-forms allow-popups allow-modals allow-downloads allow-presentation"
    );
  }
  headers.set("Access-Control-Allow-Origin", "*");

  const accept = req.headers.get("accept-encoding") ?? "";
  const isCompressible = /^(text\/|application\/(javascript|json|xml|manifest))/.test(mime);
  if (isCompressible && accept.includes("gzip") && data.length > 1024) {
    const { gzipSync } = await import("zlib");
    const gz = gzipSync(data);
    headers.set("Content-Encoding", "gzip");
    headers.set("Content-Length", String(gz.length));
    return new NextResponse(new Uint8Array(gz), { status: 200, headers });
  }

  headers.set("Content-Length", String(data.length));
  return new NextResponse(new Uint8Array(data), { status: 200, headers });
}
