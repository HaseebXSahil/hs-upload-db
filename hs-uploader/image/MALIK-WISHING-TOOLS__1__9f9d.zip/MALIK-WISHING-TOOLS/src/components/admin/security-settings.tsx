"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { ShieldCheck, KeyRound, Loader2, Lock, CheckCircle2, Info, Database, Globe } from "lucide-react";
import { toast } from "sonner";

export function SecuritySettings() {
  const router = useRouter();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [saving, setSaving] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast.error("New passwords do not match.");
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/admin/password/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Password change failed");
      toast.success("Password changed successfully. Use it on your next login.");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      router.refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Password change failed");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-3xl space-y-6">
      <header>
        <h1 className="font-display text-3xl font-black"><span className="mwt-gradient-text">Security Settings</span></h1>
        <p className="mt-1 text-sm text-white/45">Manage your administrator password and review platform protections.</p>
      </header>

      <section className="mwt-glass rounded-2xl p-6">
        <h2 className="font-display font-bold text-lg flex items-center gap-2">
          <KeyRound className="h-5 w-5 text-amber-300" /> Change Admin Password
        </h2>
        <form onSubmit={onSubmit} className="mt-5 space-y-4 max-w-md">
          <PasswordInput label="Current password" value={currentPassword} onChange={setCurrentPassword} autoComplete="current-password" />
          <PasswordInput label="New password (min 8 characters)" value={newPassword} onChange={setNewPassword} autoComplete="new-password" />
          <PasswordInput label="Confirm new password" value={confirmPassword} onChange={setConfirmPassword} autoComplete="new-password" />
          <button type="submit" disabled={saving} className="mwt-btn-primary inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-bold text-white disabled:opacity-60">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />} Update Password
          </button>
        </form>
      </section>

      <section className="mwt-glass rounded-2xl p-6">
        <h2 className="font-display font-bold text-lg flex items-center gap-2">
          <Lock className="h-5 w-5 text-emerald-300" /> Active Platform Protections
        </h2>
        <div className="mt-4 grid sm:grid-cols-2 gap-3 text-sm">
          {[
            "Passwords stored as scrypt hashes (never plain text)",
            "HttpOnly + SameSite=Strict signed session cookies",
            "Login rate limiting (8 attempts / 10 min per IP)",
            "Upload rate limiting (30 uploads / hour)",
            "ZIP path-traversal & zip-bomb protection",
            "Dangerous file types blocked (.php, .exe, .sh…)",
            "Uploaded sites run in a sandboxed isolated origin",
            "Cross-origin request protection on all admin APIs",
            "Private admin URL — hidden from public navigation",
            "Every admin API verifies the session server-side",
          ].map((item) => (
            <div key={item} className="flex items-start gap-2.5 rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3 text-white/70">
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-300 mt-0.5" />
              {item}
            </div>
          ))}
        </div>
      </section>

      <section className="rounded-2xl border border-sky-400/25 bg-sky-500/10 p-6 text-sm text-sky-100/80 space-y-3">
        <h3 className="font-bold flex items-center gap-2 text-sky-200"><Info className="h-4 w-4" /> Good to know</h3>
        <p className="flex gap-2"><Database className="h-4 w-4 shrink-0 mt-0.5" /> Changing the password here updates the hash immediately — the default credentials stop working right away.</p>
        <p className="flex gap-2"><Globe className="h-4 w-4 shrink-0 mt-0.5" /> The admin panel lives at <code className="rounded bg-black/30 px-1.5 py-0.5">/admin</code> and is never linked from the public website. Keep this URL private.</p>
      </section>
    </div>
  );
}

function PasswordInput({ label, value, onChange, autoComplete }: {
  label: string; value: string; onChange: (v: string) => void; autoComplete: string;
}) {
  return (
    <div>
      <label className="text-xs font-semibold uppercase tracking-wider text-white/50">{label}</label>
      <div className="relative mt-2">
        <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-[18px] w-[18px] text-white/35" />
        <input
          type="password"
          required
          minLength={currentOrNew(autoComplete) ? 1 : 8}
          value={value}
          autoComplete={autoComplete}
          onChange={(e) => onChange(e.target.value)}
          className="w-full rounded-xl bg-white/5 border border-white/10 pl-11 pr-4 py-3 text-sm text-white placeholder:text-white/30 outline-none focus:border-fuchsia-400/60 focus:ring-2 focus:ring-fuchsia-500/20 transition-all"
        />
      </div>
    </div>
  );
}

function currentOrNew(autoComplete: string): boolean {
  return autoComplete === "current-password";
}
