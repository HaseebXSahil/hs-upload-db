"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard, Globe2, PlusCircle, FolderTree, FolderOpen, BarChart3,
  MessageSquare, Palette, ShieldCheck, LogOut, Sparkles, Menu, X, ExternalLink,
} from "lucide-react";
import { toast } from "sonner";

const NAV = [
  { href: "/admin/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/sites/new/", label: "Add New Website", icon: PlusCircle },
  { href: "/admin/sites/", label: "Manage Websites", icon: Globe2 },
  { href: "/admin/categories/", label: "Categories", icon: FolderTree },
  { href: "/admin/files/", label: "File Manager", icon: FolderOpen },
  { href: "/admin/analytics/", label: "Visitor Analytics", icon: BarChart3 },
  { href: "/admin/settings/", label: "Contact Settings", icon: MessageSquare },
  { href: "/admin/branding/", label: "Branding Settings", icon: Palette },
  { href: "/admin/security/", label: "Security Settings", icon: ShieldCheck },
];

export function AdminSidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  async function logout() {
    setBusy(true);
    try {
      await fetch("/api/admin/logout/", { method: "POST" });
      toast.success("Logged out securely.");
      router.replace("/admin/login/");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  const isActive = (href: string) => {
    const p = pathname.replace(/\/+$/, "") || "/admin";
    const h = href.replace(/\/+$/, "");
    if (h === "/admin") return p === "/admin";
    return p === h || p.startsWith(h + "/") || (h === "/admin/sites" && p.startsWith("/admin/sites"));
  };

  const nav = (
    <nav className="flex-1 overflow-y-auto mwt-scroll py-4 px-3 space-y-1">
      {NAV.map(({ href, label, icon: Icon }) => (
        <Link
          key={href}
          href={href}
          onClick={() => setOpen(false)}
          className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-all ${
            isActive(href)
              ? "mwt-btn-primary text-white shadow-lg"
              : "text-white/55 hover:text-white hover:bg-white/5"
          }`}
        >
          <Icon className="h-[18px] w-[18px] shrink-0" />
          {label}
        </Link>
      ))}
    </nav>
  );

  const brand = (
    <div className="flex items-center gap-2.5 px-5 pt-6 pb-2">
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl mwt-btn-primary text-white">
        <Sparkles className="h-5 w-5" />
      </span>
      <div className="min-w-0">
        <div className="font-display font-extrabold leading-tight mwt-gradient-text truncate">MALIK WISHING</div>
        <div className="text-[10px] uppercase tracking-[0.3em] text-white/40">Admin Panel</div>
      </div>
    </div>
  );

  const footer = (
    <div className="p-4 border-t border-white/5 space-y-2">
      <a
        href="/"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium text-white/55 hover:text-white hover:bg-white/5 transition-all"
      >
        <ExternalLink className="h-[18px] w-[18px]" /> View Public Site
      </a>
      <button
        onClick={logout}
        disabled={busy}
        className="w-full flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-red-300 hover:bg-red-500/10 hover:text-red-200 transition-all disabled:opacity-50"
      >
        <LogOut className="h-[18px] w-[18px]" /> {busy ? "Logging out…" : "Logout"}
      </button>
      <p className="pt-2 text-center font-signature text-xl mwt-gradient-text">Malik Mushahid</p>
    </div>
  );

  return (
    <>
      {/* Mobile top bar */}
      <div className="lg:hidden fixed top-0 inset-x-0 z-50 h-14 bg-[#0a0a14] border-b border-white/10 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg mwt-btn-primary text-white">
            <Sparkles className="h-4 w-4" />
          </span>
          <span className="font-display font-bold mwt-gradient-text">MWT Admin</span>
        </div>
        <button
          onClick={() => setOpen(!open)}
          aria-label="Toggle admin menu"
          className="h-10 w-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-white"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>
      {open && <div className="lg:hidden fixed inset-0 z-40 bg-black/60" onClick={() => setOpen(false)} />}

      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-72 shrink-0 sticky top-0 h-screen border-r border-white/5 bg-[#0c0c18]">
        {brand}
        {nav}
        {footer}
      </aside>

      {/* Mobile drawer */}
      <aside
        className={`lg:hidden fixed inset-y-0 left-0 z-50 w-72 bg-[#0c0c18] border-r border-white/10 flex flex-col transition-transform duration-300 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {brand}
        {nav}
        {footer}
      </aside>

      {/* Spacer for mobile fixed bar */}
      <div className="lg:hidden h-14 shrink-0" />
    </>
  );
}
