"use client";

import { useEffect, useState, useRef, useCallback } from "react";
import {
  ArrowLeft, ExternalLink, Save, Loader2, Trash2, UploadCloud, FileCode2,
  History, RotateCcw, Image as ImageIcon, Eye, Globe, Star, Route, ShieldCheck, Copy, FileArchive, RefreshCw,
} from "lucide-react";
import { toast } from "sonner";
import { Loading, ErrorBox } from "@/components/admin/dashboard-view";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface SiteInfo {
  id: string; name: string; slug: string; description: string | null;
  categoryId: string | null; categoryName: string | null;
  published: boolean; featured: boolean; spaMode: boolean; isolated: boolean;
  entryFile: string; fileCount: number; sizeBytes: number; views: number;
  hasThumbnail: boolean; createdAt: string; updatedAt: string; url?: string;
}
interface FileRow { path: string; mime: string; size: number; sizeLabel: string; isHtml: boolean }
interface VersionRow { id: string; version: number; note: string | null; fileCount: number; sizeLabel: string; createdAt: string }

export function SiteDetail({ site: initial, categories }: { site: SiteInfo; categories: { id: string; name: string }[] }) {
  const [site, setSite] = useState(initial);
  const [name, setName] = useState(initial.name);
  const [slug, setSlug] = useState(initial.slug);
  const [slugTouched, setSlugTouched] = useState(false);
  const [description, setDescription] = useState(initial.description ?? "");
  const [categoryId, setCategoryId] = useState(initial.categoryId ?? "");
  const [published, setPublished] = useState(initial.published);
  const [featured, setFeatured] = useState(initial.featured);
  const [spaMode, setSpaMode] = useState(initial.spaMode);
  const [saving, setSaving] = useState(false);

  const [files, setFiles] = useState<FileRow[] | null>(null);
  const [versions, setVersions] = useState<VersionRow[] | null>(null);
  const [fileUploading, setFileUploading] = useState(false);
  const [replaceMode, setReplaceMode] = useState(false);
  const [pendingDeleteFile, setPendingDeleteFile] = useState<FileRow | null>(null);
  const [restoring, setRestoring] = useState<number | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const thumbInput = useRef<HTMLInputElement>(null);

  const loadFiles = useCallback(async () => {
    const res = await fetch(`/api/admin/sites/${initial.id}/files/`);
    if (res.ok) {
      const data = await res.json();
      setFiles(data.files);
      setVersions(null);
      const vres = await fetch(`/api/admin/sites/${initial.id}/versions/`);
      if (vres.ok) setVersions((await vres.json()).versions);
    }
  }, [initial.id]);

  useEffect(() => { loadFiles(); }, [loadFiles]);

  async function save() {
    setSaving(true);
    try {
      const patch: Record<string, unknown> = { name, description, published, featured, spaMode };
      if (slugTouched && slug !== initial.slug) patch.slug = slug;
      patch.categoryId = categoryId || null;
      const res = await fetch(`/api/admin/sites/${initial.id}/`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Save failed");
      setSite((s) => ({ ...s, ...data.site, url: data.site.url }));
      setSlug(data.site.slug);
      toast.success("Changes saved — public site updated.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  async function uploadFiles(list: FileList | null) {
    if (!list || list.length === 0) return;
    setFileUploading(true);
    try {
      const form = new FormData();
      const all = Array.from(list);
      const zip = all.find((f) => /\.zip$/i.test(f.name));
      if (zip) form.set("zip", zip, zip.name);
      for (const f of all.filter((x) => x !== zip)) form.append("files", f, f.name);
      form.set("replaceAll", String(replaceMode));
      const res = await fetch(`/api/admin/sites/${initial.id}/files/`, { method: "POST", body: form });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Upload failed");
      toast.success(replaceMode ? "Website files replaced" : "Files added/updated");
      for (const w of data.warnings ?? []) toast.warning(w);
      await loadFiles();
      setSite((s) => ({ ...s, fileCount: data.fileCount ?? s.fileCount }));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setFileUploading(false);
      if (fileInput.current) fileInput.current.value = "";
    }
  }

  async function deleteFile(f: FileRow) {
    setPendingDeleteFile(null);
    try {
      const res = await fetch(`/api/admin/sites/${initial.id}/files/?path=${encodeURIComponent(f.path)}`, { method: "DELETE" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Delete failed");
      toast.success(`Deleted ${f.path}`);
      await loadFiles();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed");
    }
  }

  async function restore(v: VersionRow) {
    setRestoring(v.version);
    try {
      const res = await fetch(`/api/admin/sites/${initial.id}/versions/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ version: v.version }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Restore failed");
      toast.success(`Restored version ${v.version} (${data.restored} files)`);
      await loadFiles();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Restore failed");
    } finally {
      setRestoring(null);
    }
  }

  async function uploadThumbnail(file: File | null, remove = false) {
    try {
      const form = new FormData();
      if (remove) form.set("remove", "true");
      else if (file) form.set("thumbnail", file, file.name);
      else return;
      const res = await fetch(`/api/admin/sites/${initial.id}/thumbnail/`, { method: "POST", body: form });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Thumbnail update failed");
      setSite((s) => ({ ...s, hasThumbnail: data.hasThumbnail }));
      toast.success(remove ? "Thumbnail removed" : "Thumbnail updated");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Thumbnail update failed");
    }
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <a href="/admin/sites/" className="inline-flex items-center gap-1.5 text-sm text-white/40 hover:text-white transition-colors">
            <ArrowLeft className="h-4 w-4" /> All websites
          </a>
          <h1 className="mt-2 font-display text-2xl sm:text-3xl font-black truncate">
            <span className="mwt-gradient-text">{site.name}</span>
          </h1>
          <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-white/40">
            <button
              onClick={() => { navigator.clipboard?.writeText(site.url ?? `${location.origin}/sites/${site.slug}/`); toast.success("Public URL copied"); }}
              className="inline-flex items-center gap-1 hover:text-fuchsia-300"
            >
              <Copy className="h-3 w-3" /> /sites/{site.slug}/
            </button>
            <span>·</span>
            <span>{site.views} views</span>
            <span>·</span>
            <span>{site.fileCount} files</span>
          </div>
        </div>
        <div className="flex gap-2">
          <span className={`rounded-full px-3 py-1.5 text-xs font-bold uppercase ${published ? "bg-emerald-500/15 text-emerald-300" : "bg-amber-500/15 text-amber-300"}`}>
            {published ? "Published" : "Draft"}
          </span>
          <a href={`/sites/${site.slug}/`} target="_blank" rel="noopener noreferrer" className="mwt-glass inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold text-white/80 hover:text-white">
            <ExternalLink className="h-4 w-4" /> Preview
          </a>
        </div>
      </header>

      <div className="grid lg:grid-cols-5 gap-6">
        {/* ---- Settings column ---- */}
        <div className="lg:col-span-2 space-y-6">
          <section className="mwt-glass rounded-2xl p-6 space-y-4">
            <h2 className="font-display font-bold text-lg">Website Settings</h2>
            <LabeledInput label="Name" value={name} onChange={(v) => setName(v)} maxLength={120} />
            <LabeledInput
              label="URL slug"
              value={slug}
              onChange={(v) => { setSlugTouched(true); setSlug(v.toLowerCase()); }}
              prefix="/sites/"
              hint={slug !== initial.slug ? "Changing the slug changes the public URL!" : undefined}
            />
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-white/50">Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                maxLength={500}
                className={inputCls + " resize-none mt-2"}
              />
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-white/50">Category (optional)</label>
              <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} className={inputCls + " mt-2"}>
                <option value="" className="bg-[#161226]">No category (homepage)</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id} className="bg-[#161226]">{c.name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2.5 pt-1">
              <SwitchRow icon={<Globe className="h-4 w-4" />} label="Published" checked={published} onChange={setPublished} />
              <SwitchRow icon={<Star className="h-4 w-4" />} label="Featured" checked={featured} onChange={setFeatured} />
              <SwitchRow icon={<Route className="h-4 w-4" />} label="Client-side routing (SPA)" checked={spaMode} onChange={setSpaMode} />
              <SwitchRow icon={<ShieldCheck className="h-4 w-4" />} label="Security isolation" checked={site.isolated} onChange={(v) => updateIsolated(v)} />
            </div>
            <button onClick={save} disabled={saving} className="mwt-btn-primary w-full rounded-xl py-3 font-bold text-white inline-flex items-center justify-center gap-2 disabled:opacity-60">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save Changes
            </button>
          </section>

          {/* Thumbnail */}
          <section className="mwt-glass rounded-2xl p-6">
            <h2 className="font-display font-bold text-lg flex items-center gap-2">
              <ImageIcon className="h-5 w-5 text-fuchsia-300" /> Card Thumbnail
            </h2>
            <div className="mt-4 flex items-center gap-4">
              <div className="w-32 h-20 rounded-xl overflow-hidden bg-gradient-to-br from-fuchsia-500/40 to-purple-600/30 border border-white/10 flex items-center justify-center">
                {site.hasThumbnail ? (
                  <img src={`/api/admin/sites/${initial.id}/thumbnail?v=${site.updatedAt}`} alt="Thumbnail" className="h-full w-full object-cover" />
                ) : (
                  <span className="font-display font-black text-2xl text-white/70">{site.name.charAt(0).toUpperCase()}</span>
                )}
              </div>
              <div className="space-y-2">
                <input ref={thumbInput} type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="hidden"
                  onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadThumbnail(f); if (thumbInput.current) thumbInput.current.value = ""; }} />
                <button onClick={() => thumbInput.current?.click()} className="mwt-glass block rounded-lg px-4 py-2 text-xs font-semibold text-white/80 hover:text-white">
                  {site.hasThumbnail ? "Replace image" : "Upload image"}
                </button>
                {site.hasThumbnail && (
                  <button onClick={() => uploadThumbnail(null, true)} className="block text-xs text-red-300 hover:text-red-200">Remove thumbnail</button>
                )}
                <p className="text-[10px] text-white/30">PNG/JPG/WEBP · max 4 MB</p>
              </div>
            </div>
          </section>
        </div>

        {/* ---- Files column ---- */}
        <div className="lg:col-span-3 space-y-6" id="files">
          {/* Upload box */}
          <section className="mwt-glass rounded-2xl p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="font-display font-bold text-lg flex items-center gap-2">
                <FileCode2 className="h-5 w-5 text-emerald-300" /> Website Files
                <span className="text-xs font-normal text-white/40">({files?.length ?? "…"} files · entry: {site.entryFile})</span>
              </h2>
              <label className="flex items-center gap-2 text-xs text-white/50 cursor-pointer">
                <input type="checkbox" checked={replaceMode} onChange={(e) => setReplaceMode(e.target.checked)} className="accent-fuchsia-500 h-3.5 w-3.5" />
                Replace all files (vs. merge)
              </label>
            </div>
            <div
              onClick={() => fileInput.current?.click()}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === "Enter" && fileInput.current?.click()}
              className="mt-4 rounded-xl border-2 border-dashed border-white/15 hover:border-fuchsia-400/50 p-6 text-center cursor-pointer transition-all"
            >
              <input
                ref={fileInput}
                type="file"
                multiple
                className="hidden"
                onChange={(e) => uploadFiles(e.target.files)}
                accept=".zip,.html,.htm,.css,.js,.mjs,.json,.png,.jpg,.jpeg,.gif,.webp,.svg,.ico,.woff,.woff2,.ttf,.otf,.eot,.mp3,.mp4,.webm,.ogg,.wav,.txt,.xml,.webmanifest,.pdf,.avif,.map,.vtt"
              />
              {fileUploading ? (
                <span className="inline-flex items-center gap-2 text-sm text-white/60"><Loader2 className="h-4 w-4 animate-spin" /> Uploading…</span>
              ) : (
                <>
                  <UploadCloud className="mx-auto h-7 w-7 text-white/40" />
                  <p className="mt-2 text-sm text-white/60">
                    {replaceMode ? "Drop files/ZIP to REPLACE the whole website" : "Drop files/ZIP to add or update files"}
                  </p>
                  <p className="text-[11px] text-white/30">Current files are snapshotted automatically — restorable below</p>
                </>
              )}
            </div>

            {/* File list */}
            {files === null ? (
              <Loading label="Loading files…" />
            ) : (
              <div className="mt-4 max-h-80 overflow-y-auto mwt-scroll rounded-xl border border-white/8 border-white/10 divide-y divide-white/5">
                {files.length === 0 && <p className="p-4 text-sm text-white/40">No files.</p>}
                {files.map((f) => (
                  <div key={f.path} className="flex items-center gap-3 px-4 py-2.5 hover:bg-white/[0.03]">
                    <FileCode2 className="h-4 w-4 shrink-0 text-fuchsia-300/70" />
                    <a href={`/sites/${site.slug}/${f.path}`} target="_blank" rel="noopener noreferrer" className="min-w-0 flex-1 truncate text-xs text-white/70 hover:text-fuchsia-300" title={f.path}>
                      {f.path}{f.path === site.entryFile && <span className="ml-2 rounded bg-emerald-500/15 px-1.5 py-0.5 text-[9px] font-bold text-emerald-300">ENTRY</span>}
                    </a>
                    <span className="shrink-0 text-[10px] text-white/30">{f.sizeLabel}</span>
                    <button
                      onClick={() => setPendingDeleteFile(f)}
                      disabled={f.path === site.entryFile}
                      title={f.path === site.entryFile ? "Entry file cannot be deleted" : "Delete file"}
                      className="shrink-0 text-white/25 hover:text-red-300 disabled:opacity-20 disabled:cursor-not-allowed"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Versions */}
          <section className="mwt-glass rounded-2xl p-6">
            <h2 className="font-display font-bold text-lg flex items-center gap-2">
              <History className="h-5 w-5 text-amber-300" /> Version History
            </h2>
            <p className="mt-1 text-xs text-white/40">Every update snapshots the previous files. Restore anytime.</p>
            {versions === null ? (
              <Loading label="Loading versions…" />
            ) : versions.length === 0 ? (
              <p className="mt-4 rounded-xl border border-dashed border-white/10 p-6 text-center text-sm text-white/40">
                No snapshots yet — they are created automatically when you update website files.
              </p>
            ) : (
              <div className="mt-4 space-y-2.5">
                {versions.map((v) => (
                  <div key={v.id} className="flex items-center gap-3 rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-amber-400/15 text-xs font-bold text-amber-300">
                      v{v.version}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-white/80 truncate">{v.note || "Snapshot"}</p>
                      <p className="text-[11px] text-white/35">
                        {new Date(v.createdAt).toLocaleString()} · {v.fileCount} files · {v.sizeLabel}
                      </p>
                    </div>
                    <button
                      onClick={() => restore(v)}
                      disabled={restoring !== null}
                      className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-white/5 border border-white/10 px-3 py-1.5 text-xs font-semibold text-white/70 hover:text-white hover:border-amber-300/40 disabled:opacity-50"
                    >
                      {restoring === v.version ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="h-3.5 w-3.5" />}
                      Restore
                    </button>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>

      {/* Delete file confirm */}
      <AlertDialog open={!!pendingDeleteFile} onOpenChange={(o) => !o && setPendingDeleteFile(null)}>
        <AlertDialogContent className="bg-[#161226] border-white/10 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete file &quot;{pendingDeleteFile?.path}&quot;?</AlertDialogTitle>
            <AlertDialogDescription className="text-white/60">
              The website will no longer serve this file. Visitors opening it will see a 404 page.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/10 border-white/10 text-white hover:bg-white/20">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => pendingDeleteFile && deleteFile(pendingDeleteFile)} className="bg-red-600 hover:bg-red-500 text-white">Delete file</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );

  async function updateIsolated(v: boolean) {
    try {
      const res = await fetch(`/api/admin/sites/${initial.id}/`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isolated: v }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Update failed");
      setSite((s) => ({ ...s, isolated: v }));
      toast.success(v ? "Isolation enabled (recommended)" : "Isolation disabled — only for trusted sites");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Update failed");
    }
  }
}

const inputCls = "w-full rounded-xl bg-white/5 border border-white/10 px-4 py-2.5 text-sm text-white placeholder:text-white/30 outline-none focus:border-fuchsia-400/60 focus:ring-2 focus:ring-fuchsia-500/20 transition-all";

function LabeledInput({ label, value, onChange, maxLength, prefix, hint }: {
  label: string; value: string; onChange: (v: string) => void; maxLength?: number; prefix?: string; hint?: string;
}) {
  return (
    <div>
      <label className="text-xs font-semibold uppercase tracking-wider text-white/50">{label}</label>
      {hint && <p className="mt-0.5 text-[11px] text-amber-300/80">{hint}</p>}
      <div className="relative mt-2">
        {prefix && <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs text-white/30">{prefix}</span>}
        <input
          value={value}
          maxLength={maxLength}
          onChange={(e) => onChange(e.target.value)}
          className={inputCls + (prefix ? " pl-16" : "")}
        />
      </div>
    </div>
  );
}

function SwitchRow({ icon, label, checked, onChange }: { icon: React.ReactNode; label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button type="button" onClick={() => onChange(!checked)} className="w-full flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-2.5 text-left hover:border-fuchsia-400/30 transition-all">
      <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${checked ? "mwt-btn-primary text-white" : "bg-white/5 text-white/40"}`}>{icon}</span>
      <span className="flex-1 text-sm font-medium text-white/85">{label}</span>
      <span className={`h-5 w-9 rounded-full p-0.5 transition-colors ${checked ? "bg-fuchsia-500" : "bg-white/15"}`}>
        <span className={`block h-4 w-4 rounded-full bg-white transition-transform ${checked ? "translate-x-4" : ""}`} />
      </span>
    </button>
  );
}
