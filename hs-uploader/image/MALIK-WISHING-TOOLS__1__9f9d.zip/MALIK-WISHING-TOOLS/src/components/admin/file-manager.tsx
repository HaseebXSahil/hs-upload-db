"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import {
  FolderOpen, UploadCloud, Trash2, Loader2, ExternalLink, Search, FileCode2,
  RefreshCw, Replace,
} from "lucide-react";
import { toast } from "sonner";
import { Loading } from "@/components/admin/dashboard-view";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface SiteLite { id: string; name: string; slug: string; fileCount: number; published: boolean }
interface FileRow { path: string; mime: string; size: number; sizeLabel: string; isHtml: boolean }

export function FileManagerView({ sites }: { sites: SiteLite[] }) {
  const [selected, setSelected] = useState<string>(sites[0]?.id ?? "");
  const [files, setFiles] = useState<FileRow[] | null>(null);
  const [entryFile, setEntryFile] = useState("index.html");
  const [query, setQuery] = useState("");
  const [pendingDelete, setPendingDelete] = useState<FileRow | null>(null);
  const [uploading, setUploading] = useState(false);
  const [replaceMode, setReplaceMode] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const site = sites.find((s) => s.id === selected) ?? null;

  const loadFiles = useCallback(async () => {
    if (!selected) return;
    setFiles(null);
    try {
      const res = await fetch(`/api/admin/sites/${selected}/files/`);
      if (!res.ok) throw new Error("Failed to load files");
      const data = await res.json();
      setFiles(data.files);
      setEntryFile(data.entryFile);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Error");
      setFiles([]);
    }
  }, [selected]);

  useEffect(() => { loadFiles(); }, [loadFiles]);

  async function upload(list: FileList | null) {
    if (!list || list.length === 0 || !site) return;
    setUploading(true);
    try {
      const form = new FormData();
      const all = Array.from(list);
      const zip = all.find((f) => /\.zip$/i.test(f.name));
      if (zip) form.set("zip", zip, zip.name);
      for (const f of all.filter((x) => x !== zip)) form.append("files", f, f.name);
      form.set("replaceAll", String(replaceMode));
      const res = await fetch(`/api/admin/sites/${site.id}/files/`, { method: "POST", body: form });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Upload failed");
      toast.success(replaceMode ? "Files replaced" : "Files uploaded");
      for (const w of data.warnings ?? []) toast.warning(w);
      await loadFiles();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setUploading(false);
      if (fileInput.current) fileInput.current.value = "";
    }
  }

  async function doDelete() {
    if (!pendingDelete || !site) return;
    const f = pendingDelete;
    setPendingDelete(null);
    try {
      const res = await fetch(`/api/admin/sites/${site.id}/files/?path=${encodeURIComponent(f.path)}`, { method: "DELETE" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Delete failed");
      toast.success(`Deleted ${f.path}`);
      await loadFiles();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed");
    }
  }

  if (sites.length === 0) {
    return (
      <div className="mwt-glass rounded-2xl p-12 text-center max-w-xl mx-auto">
        <FolderOpen className="mx-auto h-12 w-12 text-white/20" />
        <p className="mt-4 text-sm text-white/50">No websites yet — upload a website first, then manage its files here.</p>
      </div>
    );
  }

  const filtered = (files ?? []).filter((f) => f.path.toLowerCase().includes(query.trim().toLowerCase()));

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-black"><span className="mwt-gradient-text">File Manager</span></h1>
          <p className="mt-1 text-sm text-white/45">Browse, upload, replace and delete files of any hosted website.</p>
        </div>
        <button onClick={loadFiles} className="mwt-glass inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold text-white/70 hover:text-white">
          <RefreshCw className="h-4 w-4" /> Refresh
        </button>
      </header>

      {/* Site selector */}
      <div className="flex flex-wrap gap-2">
        {sites.map((s) => (
          <button
            key={s.id}
            onClick={() => setSelected(s.id)}
            className={`rounded-xl px-4 py-2 text-sm font-semibold transition-all ${selected === s.id ? "mwt-btn-primary text-white" : "mwt-glass text-white/60 hover:text-white"}`}
          >
            {s.name}
            <span className={`ml-2 text-[10px] ${selected === s.id ? "text-white/70" : "text-white/30"}`}>{s.fileCount}</span>
          </button>
        ))}
      </div>

      {site && (
        <>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search files by path…"
                className="w-full mwt-glass rounded-xl pl-11 pr-4 py-2.5 text-sm text-white placeholder:text-white/30 outline-none focus:border-fuchsia-400/60"
              />
            </div>
            <label className="flex items-center gap-2 text-xs text-white/50 px-2">
              <input type="checkbox" checked={replaceMode} onChange={(e) => setReplaceMode(e.target.checked)} className="accent-fuchsia-500 h-3.5 w-3.5" />
              Replace-all mode
            </label>
            <button
              onClick={() => fileInput.current?.click()}
              disabled={uploading}
              className="mwt-btn-primary inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-bold text-white disabled:opacity-60"
            >
              {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <UploadCloud className="h-4 w-4" />}
              {replaceMode ? "Replace Files" : "Upload Files"}
            </button>
            <input ref={fileInput} type="file" multiple className="hidden" onChange={(e) => upload(e.target.files)} />
          </div>

          {files === null ? (
            <Loading label="Loading files…" />
          ) : (
            <div className="mwt-glass rounded-2xl overflow-hidden">
              <div className="max-h-[480px] overflow-y-auto mwt-scroll divide-y divide-white/5">
                {filtered.length === 0 && (
                  <p className="p-8 text-center text-sm text-white/40">{files.length === 0 ? "This website has no files yet — upload some above." : "No files match your search."}</p>
                )}
                {filtered.map((f) => (
                  <div key={f.path} className="flex items-center gap-3 px-5 py-3 hover:bg-white/[0.03]">
                    <FileCode2 className="h-4 w-4 shrink-0 text-fuchsia-300/70" />
                    <a
                      href={`/sites/${site.slug}/${f.path}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="min-w-0 flex-1 truncate text-sm text-white/75 hover:text-fuchsia-300"
                      title={f.path}
                    >
                      {f.path}
                      {f.path === entryFile && <span className="ml-2 rounded bg-emerald-500/15 px-1.5 py-0.5 text-[9px] font-bold text-emerald-300">ENTRY</span>}
                    </a>
                    <span className="hidden sm:block text-[10px] text-white/25 w-36 truncate text-right">{f.mime.split(";")[0]}</span>
                    <span className="shrink-0 text-[11px] text-white/40 w-16 text-right">{f.sizeLabel}</span>
                    <a href={`/sites/${site.slug}/${f.path}`} target="_blank" rel="noopener noreferrer" className="shrink-0 text-white/25 hover:text-fuchsia-300" title="Open">
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                    <button
                      onClick={() => setPendingDelete(f)}
                      disabled={f.path === entryFile}
                      title={f.path === entryFile ? "Entry file cannot be deleted" : "Delete file"}
                      className="shrink-0 text-white/25 hover:text-red-300 disabled:opacity-20 disabled:cursor-not-allowed"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      <AlertDialog open={!!pendingDelete} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent className="bg-[#161226] border-white/10 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete file &quot;{pendingDelete?.path}&quot;?</AlertDialogTitle>
            <AlertDialogDescription className="text-white/60">The website will no longer serve this file.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/10 border-white/10 text-white hover:bg-white/20">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={doDelete} className="bg-red-600 hover:bg-red-500 text-white">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
