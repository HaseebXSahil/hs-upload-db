"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Globe2, Eye, FolderTree, HardDrive, PlusCircle, CheckCircle2, PauseCircle,
  Clock, Star, TrendingUp, Upload, Loader2, ArrowRight,
} from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

interface Stats {
  totalSites: number;
  publishedSites: number;
  unpublishedSites: number;
  featuredSites: number;
  totalCategories: number;
  totalVisits: number;
  visits7d: number;
  storageLabel: string;
  fileCount: number;
  lastLoginAt: string | null;
}
interface RecentUpload {
  id: string; name: string; slug: string; published: boolean; createdAt: string; fileCount: number; sizeLabel: string;
}
interface TopSite { id: string; name: string; slug: string; views: number }

export function DashboardView() {
  const [data, setData] = useState<{ stats: Stats; recentUploads: RecentUpload[]; topSites: TopSite[]; visitSeries: { date: string; count: number }[] } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/admin/stats/")
      .then(async (r) => {
        if (!r.ok) throw new Error("Failed to load statistics");
        setData(await r.json());
      })
      .catch((e) => setError(e.message));
  }, []);

  if (error) return <ErrorBox message={error} />;
  if (!data) return <Loading label="Loading dashboard…" />;

  const { stats, recentUploads, topSites, visitSeries } = data;
  const chart = visitSeries.map((d) => ({ ...d, day: new Date(d.date + "T00:00:00").toLocaleDateString("en", { month: "short", day: "numeric" }) }));

  return (
    <div className="space-y-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-black">
            <span className="mwt-gradient-text">Dashboard</span>
          </h1>
          <p className="mt-1 text-sm text-white/45">
            Platform overview — everything at a glance.
            {stats.lastLoginAt ? ` Last login: ${new Date(stats.lastLoginAt).toLocaleString()}` : ""}
          </p>
        </div>
        <Link
          href="/admin/sites/new/"
          className="mwt-btn-primary inline-flex items-center gap-2 rounded-xl px-5 py-3 text-sm font-bold text-white"
        >
          <PlusCircle className="h-[18px] w-[18px]" /> Add New Website
        </Link>
      </header>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard icon={<Globe2 className="h-5 w-5" />} label="Total Websites" value={stats.totalSites} tint="from-fuchsia-500/20 to-purple-500/5 text-fuchsia-300" />
        <StatCard icon={<CheckCircle2 className="h-5 w-5" />} label="Published" value={stats.publishedSites} tint="from-emerald-500/20 to-emerald-500/5 text-emerald-300" />
        <StatCard icon={<PauseCircle className="h-5 w-5" />} label="Unpublished" value={stats.unpublishedSites} tint="from-amber-500/20 to-amber-500/5 text-amber-300" />
        <StatCard icon={<Eye className="h-5 w-5" />} label="Total Visitors" value={stats.totalVisits} tint="from-sky-500/20 to-sky-500/5 text-sky-300" />
        <StatCard icon={<FolderTree className="h-5 w-5" />} label="Categories" value={stats.totalCategories} tint="from-violet-500/20 to-violet-500/5 text-violet-300" />
        <StatCard icon={<HardDrive className="h-5 w-5" />} label="Storage Used" value={stats.storageLabel} tint="from-rose-500/20 to-rose-500/5 text-rose-300" />
      </div>

      {/* Chart + top sites */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 mwt-glass rounded-2xl p-5">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold text-lg flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-fuchsia-300" /> Visits — last 14 days
            </h2>
            <span className="text-xs text-white/40">{stats.visits7d} in last 7 days</span>
          </div>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chart} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="visitGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#d946ef" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#a855f7" stopOpacity={0.03} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
                <XAxis dataKey="day" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
                <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ background: "#161226", border: "1px solid rgba(217,70,239,0.3)", borderRadius: 12, color: "#fff" }}
                  labelStyle={{ color: "rgba(255,255,255,0.6)" }}
                />
                <Area type="monotone" dataKey="count" stroke="#d946ef" strokeWidth={2.5} fill="url(#visitGrad)" name="Visits" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="mwt-glass rounded-2xl p-5">
          <h2 className="font-display font-bold text-lg flex items-center gap-2">
            <Star className="h-5 w-5 text-amber-300" /> Most Opened Sites
          </h2>
          <div className="mt-4 space-y-3">
            {topSites.length === 0 && <p className="text-sm text-white/40">No published sites yet.</p>}
            {topSites.map((s, i) => (
              <div key={s.id} className="flex items-center gap-3">
                <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-xs font-bold ${i === 0 ? "mwt-btn-gold" : "bg-white/5 text-white/60"}`}>
                  {i + 1}
                </span>
                <span className="flex-1 truncate text-sm text-white/80">{s.name}</span>
                <span className="text-xs font-semibold text-fuchsia-300">{s.views}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent uploads */}
      <div className="mwt-glass rounded-2xl p-5">
        <div className="flex items-center justify-between">
          <h2 className="font-display font-bold text-lg flex items-center gap-2">
            <Upload className="h-5 w-5 text-emerald-300" /> Recent Uploads
          </h2>
          <Link href="/admin/sites/" className="text-sm text-fuchsia-300 hover:text-fuchsia-200 inline-flex items-center gap-1">
            Manage all <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        {recentUploads.length === 0 ? (
          <div className="mt-6 rounded-xl border border-dashed border-white/10 p-8 text-center">
            <p className="text-sm text-white/45">No websites uploaded yet.</p>
            <Link href="/admin/sites/new/" className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-fuchsia-300 hover:text-fuchsia-200">
              <PlusCircle className="h-4 w-4" /> Upload your first website
            </Link>
          </div>
        ) : (
          <div className="mt-4 grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
            {recentUploads.map((r) => (
              <Link key={r.id} href={`/admin/sites/${r.id}/`} className="mwt-card p-4 block">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-semibold text-white/90 truncate">{r.name}</span>
                  <span className={`shrink-0 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${r.published ? "bg-emerald-500/15 text-emerald-300" : "bg-amber-500/15 text-amber-300"}`}>
                    {r.published ? "Live" : "Draft"}
                  </span>
                </div>
                <p className="mt-1.5 text-xs text-white/40 flex items-center gap-2">
                  <Clock className="h-3 w-3" /> {new Date(r.createdAt).toLocaleString()} · {r.fileCount} files · {r.sizeLabel}
                </p>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, tint }: { icon: React.ReactNode; label: string; value: string | number; tint: string }) {
  return (
    <div className={`rounded-2xl border border-white/10 bg-gradient-to-br ${tint} p-4`}>
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-white/50">{label}</span>
        <span className="opacity-80">{icon}</span>
      </div>
      <div className="mt-2 font-display text-2xl font-black text-white">{value}</div>
    </div>
  );
}

export function Loading({ label }: { label: string }) {
  return (
    <div className="flex items-center justify-center py-24 text-white/50">
      <Loader2 className="mr-3 h-6 w-6 animate-spin text-fuchsia-400" /> {label}
    </div>
  );
}

export function ErrorBox({ message }: { message: string }) {
  return (
    <div className="rounded-2xl border border-red-400/30 bg-red-500/10 px-6 py-8 text-center">
      <p className="text-red-300 font-semibold">Something went wrong</p>
      <p className="mt-1 text-sm text-red-200/70">{message}</p>
    </div>
  );
}
