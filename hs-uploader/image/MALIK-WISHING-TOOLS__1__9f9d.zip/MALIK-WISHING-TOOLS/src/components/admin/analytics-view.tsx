"use client";

import { useEffect, useState } from "react";
import { Eye, Users, CalendarRange, BarChart3 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from "recharts";
import { Loading, ErrorBox } from "@/components/admin/dashboard-view";

interface Analytics {
  totals: { allTime: number; range: number; uniqueVisitors: number };
  series: { date: string; count: number }[];
  perSite: { id: string; name: string; slug: string; views: number; published: boolean; viewsInRange: number }[];
}

const RANGES = [
  { label: "7 days", value: 7 },
  { label: "14 days", value: 14 },
  { label: "30 days", value: 30 },
  { label: "90 days", value: 90 },
];

export function AnalyticsView() {
  const [data, setData] = useState<Analytics | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [days, setDays] = useState(14);

  useEffect(() => {
    let alive = true;
    fetch(`/api/admin/analytics/?days=${days}`)
      .then(async (r) => {
        if (!r.ok) throw new Error("Failed to load analytics");
        const d = await r.json();
        if (alive) setData(d);
      })
      .catch((e) => {
        if (alive) setError(e.message);
      });
    return () => {
      alive = false;
    };
  }, [days]);

  if (error) return <ErrorBox message={error} />;
  if (!data) return <Loading label="Loading analytics…" />;

  const chart = data.series.map((d) => ({
    ...d,
    day: new Date(d.date + "T00:00:00").toLocaleDateString("en", { month: "short", day: "numeric" }),
  }));
  const max = Math.max(1, ...chart.map((c) => c.count));

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-black"><span className="mwt-gradient-text">Visitor Analytics</span></h1>
          <p className="mt-1 text-sm text-white/45">Privacy-friendly — visitors are counted with hashed fingerprints, never raw IPs.</p>
        </div>
        <div className="flex gap-2">
          {RANGES.map((r) => (
            <button
              key={r.value}
              onClick={() => setDays(r.value)}
              className={`rounded-xl px-3.5 py-2 text-xs font-semibold transition-all ${days === r.value ? "mwt-btn-primary text-white" : "mwt-glass text-white/60 hover:text-white"}`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </header>

      <div className="grid grid-cols-3 gap-4">
        <StatBox icon={<Eye className="h-5 w-5" />} label={`Visits (last ${days}d)`} value={data.totals.range} />
        <StatBox icon={<Users className="h-5 w-5" />} label="Unique visitors" value={data.totals.uniqueVisitors} />
        <StatBox icon={<CalendarRange className="h-5 w-5" />} label="All-time visits" value={data.totals.allTime} />
      </div>

      <section className="mwt-glass rounded-2xl p-5">
        <h2 className="font-display font-bold text-lg flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-fuchsia-300" /> Visits per day
        </h2>
        <div className="mt-4 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chart} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
              <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
              <XAxis dataKey="day" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
              <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip
                cursor={{ fill: "rgba(217,70,239,0.08)" }}
                contentStyle={{ background: "#161226", border: "1px solid rgba(217,70,239,0.3)", borderRadius: 12, color: "#fff" }}
                labelStyle={{ color: "rgba(255,255,255,0.6)" }}
              />
              <Bar dataKey="count" name="Visits" radius={[6, 6, 0, 0]}>
                {chart.map((c, i) => (
                  <Cell key={i} fill={c.count === max ? "#f5c76a" : "#d946ef"} fillOpacity={0.35 + 0.65 * (c.count / max)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="mwt-glass rounded-2xl p-5">
        <h2 className="font-display font-bold text-lg">Traffic by website</h2>
        <div className="mt-4 space-y-2">
          {data.perSite.length === 0 && <p className="text-sm text-white/40">No published websites yet.</p>}
          {data.perSite.map((s) => (
            <div key={s.id} className="flex items-center gap-3">
              <span className="w-40 sm:w-56 truncate text-sm text-white/80">{s.name}</span>
              <div className="flex-1 h-6 rounded-lg bg-white/5 overflow-hidden">
                <div
                  className="h-full rounded-lg bg-gradient-to-r from-fuchsia-500 to-purple-500 transition-all"
                  style={{ width: `${Math.max(3, Math.min(100, (s.views / Math.max(1, data.perSite[0].views)) * 100))}%` }}
                />
              </div>
              <span className="w-14 text-right text-xs font-bold text-fuchsia-300">{s.views}</span>
              <span className="hidden sm:block w-24 text-right text-[10px] text-white/30">{s.viewsInRange} in range</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function StatBox({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-fuchsia-500/15 to-purple-500/5 p-4">
      <div className="flex items-center justify-between text-white/60">
        <span className="text-[11px] font-semibold uppercase tracking-wider">{label}</span>
        {icon}
      </div>
      <div className="mt-2 font-display text-2xl font-black text-white">{value.toLocaleString()}</div>
    </div>
  );
}
