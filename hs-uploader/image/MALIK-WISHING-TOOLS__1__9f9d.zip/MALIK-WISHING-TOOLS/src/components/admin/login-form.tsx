"use client";

import { useState, FormEvent } from "react";
import { motion } from "framer-motion";
import { Sparkles, Lock, User, ShieldCheck, ArrowLeft, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

export function LoginForm() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/login/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data.error || "Login failed.");
        return;
      }
      toast.success("Welcome back, Administrator!");
      router.replace("/admin/");
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mwt-bg-base min-h-screen flex items-center justify-center px-4 py-10 relative overflow-hidden">
      <div aria-hidden className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="mwt-orb h-80 w-80 bg-fuchsia-500/25 top-[-5rem] left-[10%]" />
        <div className="mwt-orb h-96 w-96 bg-purple-500/20 bottom-[-6rem] right-[5%]" style={{ animationDelay: "-7s" }} />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 28, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl mwt-btn-primary text-white shadow-2xl">
            <ShieldCheck className="h-8 w-8" />
          </span>
          <h1 className="mt-5 font-display text-3xl font-black mwt-gradient-text mwt-glow">Admin Panel</h1>
          <p className="mt-2 text-sm text-white/50">MALIK WISHING TOOLS — Administrator access only</p>
        </div>

        <form onSubmit={onSubmit} className="mwt-glass rounded-3xl p-7 sm:p-8 space-y-5">
          <div>
            <label htmlFor="username" className="text-xs font-semibold uppercase tracking-wider text-white/50">
              Username
            </label>
            <div className="relative mt-2">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 h-[18px] w-[18px] text-white/35" />
              <input
                id="username"
                type="text"
                autoComplete="username"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter admin username"
                className="w-full rounded-xl bg-white/5 border border-white/10 pl-11 pr-4 py-3 text-white placeholder:text-white/30 outline-none focus:border-fuchsia-400/60 focus:ring-2 focus:ring-fuchsia-500/20 transition-all"
              />
            </div>
          </div>

          <div>
            <label htmlFor="password" className="text-xs font-semibold uppercase tracking-wider text-white/50">
              Password
            </label>
            <div className="relative mt-2">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-[18px] w-[18px] text-white/35" />
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter admin password"
                className="w-full rounded-xl bg-white/5 border border-white/10 pl-11 pr-4 py-3 text-white placeholder:text-white/30 outline-none focus:border-fuchsia-400/60 focus:ring-2 focus:ring-fuchsia-500/20 transition-all"
              />
            </div>
          </div>

          {error && (
            <motion.p
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-xl bg-red-500/10 border border-red-400/30 px-4 py-3 text-sm text-red-300"
              role="alert"
            >
              {error}
            </motion.p>
          )}

          <button
            type="submit"
            disabled={busy}
            className="mwt-btn-primary w-full rounded-xl py-3.5 font-bold text-white flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <Lock className="h-[18px] w-[18px]" />}
            {busy ? "Signing in…" : "Sign In Securely"}
          </button>

          <p className="text-center text-[11px] text-white/30 leading-relaxed">
            Protected area. All login attempts are rate-limited and monitored.
            <br />
            Passwords are stored as scrypt hashes — never in plain text.
          </p>
        </form>

        <div className="mt-6 text-center">
          <a href="/" className="inline-flex items-center gap-2 text-sm text-white/40 hover:text-white transition-colors">
            <ArrowLeft className="h-4 w-4" /> Back to public website
          </a>
        </div>
        <div className="mt-8 text-center">
          <span className="font-signature text-2xl mwt-gradient-text">Malik Mushahid</span>
        </div>
      </motion.div>
    </div>
  );
}
