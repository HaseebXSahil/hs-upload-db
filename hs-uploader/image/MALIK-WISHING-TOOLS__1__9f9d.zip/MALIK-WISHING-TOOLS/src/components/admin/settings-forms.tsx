"use client";

import { useEffect, useState, FormEvent } from "react";
import {
  MessageCircle, Send, Loader2, Save, Phone, Link2, AtSign, ToggleLeft,
  Eye, ExternalLink,
} from "lucide-react";
import { toast } from "sonner";
import { Loading, ErrorBox } from "@/components/admin/dashboard-view";

interface Settings {
  whatsappEnabled: boolean;
  whatsappPhone: string;
  whatsappLink: string;
  telegramEnabled: boolean;
  telegramUsername: string;
  telegramLink: string;
}
interface ContactLinks { whatsapp?: string; telegram?: string }

export function ContactSettings() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [links, setLinks] = useState<ContactLinks>({});
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/admin/settings/")
      .then(async (r) => {
        if (!r.ok) throw new Error("Failed to load settings");
        const d = await r.json();
        setSettings(d.settings);
        setLinks(d.contactLinks);
      })
      .catch((e) => setError(e.message));
  }, []);

  if (error) return <ErrorBox message={error} />;
  if (!settings) return <Loading label="Loading contact settings…" />;

  const update = (patch: Partial<Settings>) => setSettings({ ...settings, ...patch });

  async function save(e: FormEvent) {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings/", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          whatsappEnabled: settings.whatsappEnabled,
          whatsappPhone: settings.whatsappPhone,
          whatsappLink: settings.whatsappLink,
          telegramEnabled: settings.telegramEnabled,
          telegramUsername: settings.telegramUsername,
          telegramLink: settings.telegramLink,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Save failed");
      setSettings(data.settings);
      setLinks(data.contactLinks);
      toast.success("Contact settings saved — public site updated instantly.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={save} className="max-w-3xl space-y-6">
      <header>
        <h1 className="font-display text-3xl font-black"><span className="mwt-gradient-text">Contact Settings</span></h1>
        <p className="mt-1 text-sm text-white/45">These buttons appear on the public homepage and update live when saved.</p>
      </header>

      {/* WhatsApp */}
      <section className="mwt-glass rounded-2xl p-6 space-y-5">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-display font-bold text-lg flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#25D366] text-white"><MessageCircle className="h-5 w-5" /></span>
            WhatsApp Contact
          </h2>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={settings.whatsappEnabled}
              onChange={(e) => update({ whatsappEnabled: e.target.checked })}
              className="h-4 w-4 accent-fuchsia-500"
            />
            <span className="text-sm font-semibold text-white/70">{settings.whatsappEnabled ? "Enabled" : "Disabled"}</span>
          </label>
        </div>

        <div className={settings.whatsappEnabled ? "space-y-4" : "space-y-4 opacity-50 pointer-events-none"}>
          <Field
            label="WhatsApp phone number (with country code)"
            icon={<Phone className="h-4 w-4" />}
            value={settings.whatsappPhone}
            onChange={(v) => update({ whatsappPhone: v })}
            placeholder="e.g. 923001234567"
            hint="Generates https://wa.me/<number> automatically."
          />
          <Field
            label="OR custom WhatsApp link (optional, overrides number)"
            icon={<Link2 className="h-4 w-4" />}
            value={settings.whatsappLink}
            onChange={(v) => update({ whatsappLink: v })}
            placeholder="https://wa.me/923001234567 or https://chat.whatsapp.com/…"
          />
          {links.whatsapp && (
            <PreviewLink href={links.whatsapp} label="WhatsApp button will open" />
          )}
        </div>
      </section>

      {/* Telegram */}
      <section className="mwt-glass rounded-2xl p-6 space-y-5">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-display font-bold text-lg flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#229ED9] text-white"><Send className="h-5 w-5" /></span>
            Telegram Contact
          </h2>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={settings.telegramEnabled}
              onChange={(e) => update({ telegramEnabled: e.target.checked })}
              className="h-4 w-4 accent-fuchsia-500"
            />
            <span className="text-sm font-semibold text-white/70">{settings.telegramEnabled ? "Enabled" : "Disabled"}</span>
          </label>
        </div>

        <div className={settings.telegramEnabled ? "space-y-4" : "space-y-4 opacity-50 pointer-events-none"}>
          <Field
            label="Telegram username (without @)"
            icon={<AtSign className="h-4 w-4" />}
            value={settings.telegramUsername}
            onChange={(v) => update({ telegramUsername: v })}
            placeholder="e.g. malikwishingtools"
            hint="Generates https://t.me/<username> automatically."
          />
          <Field
            label="OR custom Telegram link (optional, overrides username)"
            icon={<Link2 className="h-4 w-4" />}
            value={settings.telegramLink}
            onChange={(v) => update({ telegramLink: v })}
            placeholder="https://t.me/malikwishingtools or channel invite link"
          />
          {links.telegram && (
            <PreviewLink href={links.telegram} label="Telegram button will open" />
          )}
        </div>
      </section>

      <button type="submit" disabled={saving} className="mwt-btn-primary inline-flex items-center gap-2 rounded-xl px-8 py-3.5 font-bold text-white disabled:opacity-60">
        {saving ? <Loader2 className="h-5 w-5 animate-spin" /> : <Save className="h-5 w-5" />} Save Contact Settings
      </button>
    </form>
  );
}

export function Field({
  label, icon, value, onChange, placeholder, hint, type = "text", maxLength,
}: {
  label: string; icon?: React.ReactNode; value: string; onChange: (v: string) => void;
  placeholder?: string; hint?: string; type?: string; maxLength?: number;
}) {
  return (
    <div>
      <label className="text-xs font-semibold uppercase tracking-wider text-white/50">{label}</label>
      <div className="relative mt-2">
        {icon && <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30">{icon}</span>}
        <input
          type={type}
          value={value}
          maxLength={maxLength}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className={`w-full rounded-xl bg-white/5 border border-white/10 px-4 py-3 text-sm text-white placeholder:text-white/30 outline-none focus:border-fuchsia-400/60 focus:ring-2 focus:ring-fuchsia-500/20 transition-all ${icon ? "pl-11" : ""}`}
        />
      </div>
      {hint && <p className="mt-1 text-[11px] text-white/30">{hint}</p>}
    </div>
  );
}

export function PreviewLink({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex max-w-full items-center gap-2 rounded-lg bg-emerald-500/10 border border-emerald-400/25 px-3 py-2 text-xs text-emerald-200 hover:bg-emerald-500/20"
    >
      <Eye className="h-3.5 w-3.5 shrink-0" />
      <span className="shrink-0">{label}:</span>
      <span className="truncate">{href}</span>
      <ExternalLink className="h-3 w-3 shrink-0" />
    </a>
  );
}
