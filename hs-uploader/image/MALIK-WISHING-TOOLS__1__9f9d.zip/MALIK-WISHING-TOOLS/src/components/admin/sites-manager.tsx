"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import {
  Globe2, PlusCircle, Search, ExternalLink, Eye, EyeOff, Star, Trash2, Pencil,
  Loader2, RefreshCw, FolderOpen, Copy,
} from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Loading, ErrorBox } from "@/components/admin/dashboard-view";

interface SiteRow {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  published: boolean;
  featured: boolean;
  views: number;
  fileCount: number;
  sizeLabel: string;
  hasThumbnail: boolean;
  thumbnailUrl: string | null;
  url: string;
  updatedAt: string;
  category: { id: string; name: string } | null;
}

export function SitesManager() {
  const [sites, setSites] = useState<SiteRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | "published" | "unpublished">("all");
  const [confirmDelete, setConfirmDelete] = useState<SiteRow | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/sites/");
      if (!res.ok) throw new Error("Failed to load websites");
      const data = await res.json();
      setSites(data.sites);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function togglePublish(site: SiteRow) {
    setBusyId(site.id);
    try {
      const res = await fetch(`/api/admin/sites/${site.id}/`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ published: !site.published }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Update failed");
      toast.success(data.site.published ? `"${site.name}" is now published` : `"${site.name}" unpublished`);
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Update failed");
    } finally {
      setBusyId(null);
    }
  }

  async function toggleFeatured(site: SiteRow) {
    setBusyId(site.id);
    try {
      const res = await fetch(`/api/admin/sites/${site.id}/`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ featured: !site.featured }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Update failed");
      toast.success(data.site.featured ? "Marked as featured" : "Removed from featured");
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Update failed");
    } finally {
      setBusyId(null);
    }
  }

  async function doDelete() {
    if (!confirmDelete) return;
    const site = confirmDelete;
    setBusyId(site.id);
    setConfirmDelete(null);
    try {
      const res = await fetch(`/api/admin/sites/${site.id}/`, { method: "DELETE" });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Delete failed");
      }
      toast.success(`"${site.name}" deleted`);
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed");
    } finally {
      setBusyId(null);
    }
  }

  if (error) return <ErrorBox message={error} />;
  if (!sites) return <Loading label="Loading websites…" />;

  const filtered = sites.filter((s) => {
    if (filter === "published" && !s.published) return false;
    if (filter === "unpublished" && s.published) return false;
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return s.name.toLowerCase().includes(q) || s.slug.includes(q) || (s.category?.name ?? "").toLowerCase().includes(q);
  });

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-black"><span className="mwt-gradient-text">Manage Websites</span></h1>
          <p className="mt-1 text-sm text-white/45">{sites.length} website(s) hosted · {sites.filter((s) => s.published).length} published</p>
        </div>
        <div className="flex gap-3">
          <button onClick={load} className="mwt-glass inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold text-white/70 hover:text-white">
            <RefreshCw className="h-4 w-4" /> Refresh
          </button>
          <Link href="/admin/sites/new/" className="mwt-btn-primary inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-bold text-white">
            <PlusCircle className="h-4 w-4" /> Add New
          </Link>
        </div>
      </header>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name, slug or category…"
            className="w-full mwt-glass rounded-xl pl-11 pr-4 py-2.5 text-sm text-white placeholder:text-white/30 outline-none focus:border-fuchsia-400/60"
          />
        </div>
        <div className="flex gap-2">
          {(["all", "published", "unpublished"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-xl px-4 py-2.5 text-sm font-semibold capitalize transition-all ${filter === f ? "mwt-btn-primary text-white" : "mwt-glass text-white/60 hover:text-white"}`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <div className="mwt-glass rounded-2xl p-12 text-center">
          <Globe2 className="mx-auto h-12 w-12 text-white/20" />
          <p className="mt-4 text-white/50 text-sm">
            {sites.length === 0 ? "No websites yet — upload your first one!" : "No websites match your filters."}
          </p>
        </div>
      ) : (
        <div className="grid gap-4 xl:grid-cols-2">
          {filtered.map((site) => (
            <div key={site.id} className="mwt-card p-4 flex gap-4">
              {/* Thumbnail */}
              <div className="shrink-0 w-28 h-20 rounded-xl overflow-hidden bg-gradient-to-br from-fuchsia-500/40 to-purple-600/30 border border-white/10 relative">
                {site.hasThumbnail ? (
                  <img src={`/api/admin/sites/${site.id}/thumbnail`} alt={site.name} className="h-full w-full object-cover" />
                ) : (
                  <div className="h-full w-full flex items-center justify-center font-display font-black text-2xl text-white/80">
                    {site.name.charAt(0).toUpperCase()}
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <h3 className="font-semibold text-white/90 truncate">{site.name}</h3>
                    <button
                      onClick={() => { navigator.clipboard?.writeText(site.url); toast.success("Public URL copied"); }}
                      className="mt-0.5 flex items-center gap-1 text-[11px] text-white/35 hover:text-fuchsia-300 max-w-full truncate"
                      title="Copy public URL"
                    >
                      <Copy className="h-3 w-3 shrink-0" /> /sites/{site.slug}/
                    </button>
                  </div>
                  <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${site.published ? "bg-emerald-500/15 text-emerald-300" : "bg-amber-500/15 text-amber-300"}`}>
                    {site.published ? "Live" : "Draft"}
                  </span>
                </div>
                <p className="mt-1 text-xs text-white/40 line-clamp-1">{site.description || "No description"}</p>
                <p className="mt-1 text-[11px] text-white/30">
                  {site.category ? site.category.name : "Uncategorized"} · {site.fileCount} files · {site.sizeLabel} · {site.views} views
                </p>

                {/* Actions */}
                <div className="mt-3 flex flex-wrap items-center gap-1.5">
                  <ActionButton onClick={() => togglePublish(site)} busy={busyId === site.id} title={site.published ? "Unpublish" : "Publish"}>
                    {site.published ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                    {site.published ? "Unpublish" : "Publish"}
                  </ActionButton>
                  <ActionButton onClick={() => toggleFeatured(site)} busy={busyId === site.id} title="Toggle featured" active={site.featured}>
                    <Star className={`h-3.5 w-3.5 ${site.featured ? "fill-amber-300" : ""}`} /> {site.featured ? "Featured" : "Feature"}
                  </ActionButton>
                  <Link href={`/admin/sites/${site.id}/`} className="inline-flex items-center gap-1.5 rounded-lg bg-white/5 border border-white/10 px-2.5 py-1.5 text-xs font-semibold text-white/70 hover:text-white hover:border-fuchsia-400/40">
                    <Pencil className="h-3.5 w-3.5" /> Edit
                  </Link>
                  <Link href={`/admin/sites/${site.id}/#files`} className="inline-flex items-center gap-1.5 rounded-lg bg-white/5 border border-white/10 px-2.5 py-1.5 text-xs font-semibold text-white/70 hover:text-white hover:border-fuchsia-400/40">
                    <FolderOpen className="h-3.5 w-3.5" /> Files
                  </Link>
                  <a href={site.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 rounded-lg bg-white/5 border border-white/10 px-2.5 py-1.5 text-xs font-semibold text-white/70 hover:text-white hover:border-fuchsia-400/40">
                    <ExternalLink className="h-3.5 w-3.5" /> Open
                  </a>
                  <ActionButton onClick={() => setConfirmDelete(site)} busy={false} title="Delete website" danger>
                    <Trash2 className="h-3.5 w-3.5" /> Delete
                  </ActionButton>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <AlertDialog open={!!confirmDelete} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <AlertDialogContent className="bg-[#161226] border-white/10 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete &quot;{confirmDelete?.name}&quot;?</AlertDialogTitle>
            <AlertDialogDescription className="text-white/60">
              This permanently removes the website, all its files, version history and visit statistics.
              The public URL will stop working. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/10 border-white/10 text-white hover:bg-white/20">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={doDelete} className="bg-red-600 hover:bg-red-500 text-white">Delete permanently</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function ActionButton({
  onClick, busy, title, children, danger = false, active = false,
}: {
  onClick: () => void; busy: boolean; title: string; children: React.ReactNode; danger?: boolean; active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={busy}
      title={title}
      className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border transition-all disabled:opacity-50 ${
        danger
          ? "bg-red-500/10 border-red-400/25 text-red-300 hover:bg-red-500/20"
          : active
            ? "bg-amber-400/15 border-amber-300/40 text-amber-300"
            : "bg-white/5 border-white/10 text-white/70 hover:text-white hover:border-fuchsia-400/40"
      }`}
    >
      {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : children}
    </button>
  );
}
