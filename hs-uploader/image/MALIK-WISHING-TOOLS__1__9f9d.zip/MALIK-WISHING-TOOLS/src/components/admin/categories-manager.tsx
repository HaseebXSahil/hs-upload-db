"use client";

import { useEffect, useState, useCallback } from "react";
import { FolderTree, Plus, Trash2, Pencil, Loader2, Check, X, Info } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Loading, ErrorBox } from "@/components/admin/dashboard-view";

interface Category { id: string; name: string; slug: string; description: string | null; _count: { sites: number } }

export function CategoriesManager() {
  const [categories, setCategories] = useState<Category[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [newName, setNewName] = useState("");
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<Category | null>(null);
  const [editName, setEditName] = useState("");
  const [confirmDelete, setConfirmDelete] = useState<Category | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/categories/");
      if (!res.ok) throw new Error("Failed to load categories");
      setCategories((await res.json()).categories);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function addCategory() {
    if (!newName.trim()) return void toast.error("Enter a category name.");
    setAdding(true);
    try {
      const res = await fetch("/api/admin/categories/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName.trim() }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Create failed");
      toast.success(`Category "${data.category.name}" created`);
      setNewName("");
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Create failed");
    } finally {
      setAdding(false);
    }
  }

  async function renameCategory() {
    if (!editing) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/admin/categories/${editing.id}/`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: editName.trim() }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Rename failed");
      toast.success("Category renamed");
      setEditing(null);
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Rename failed");
    } finally {
      setBusy(false);
    }
  }

  async function doDelete() {
    if (!confirmDelete) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/admin/categories/${confirmDelete.id}/`, { method: "DELETE" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Delete failed");
      toast.success(`Category deleted — ${data.detachedSites} website(s) became uncategorized`);
      setConfirmDelete(null);
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed");
    } finally {
      setBusy(false);
    }
  }

  if (error) return <ErrorBox message={error} />;

  return (
    <div className="space-y-6 max-w-3xl">
      <header>
        <h1 className="font-display text-3xl font-black"><span className="mwt-gradient-text">Categories</span></h1>
        <p className="mt-1 text-sm text-white/45">Optional organization — websites never require a category.</p>
      </header>

      <div className="mwt-glass rounded-2xl p-4 flex items-start gap-3 text-xs text-sky-200/80 border border-sky-400/20">
        <Info className="h-4 w-4 shrink-0 mt-0.5" />
        <p>Deleting a category never deletes websites — they simply appear as &quot;Uncategorized&quot; directly on the homepage. You can move websites between categories any time from Manage Websites.</p>
      </div>

      {/* Add */}
      <div className="flex gap-3">
        <div className="relative flex-1">
          <FolderTree className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35" />
          <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addCategory()}
            placeholder="New category name — e.g. Birthday Wishes, Eid Cards…"
            maxLength={60}
            className="w-full mwt-glass rounded-xl pl-11 pr-4 py-3 text-sm text-white placeholder:text-white/30 outline-none focus:border-fuchsia-400/60"
          />
        </div>
        <button onClick={addCategory} disabled={adding} className="mwt-btn-primary inline-flex items-center gap-2 rounded-xl px-5 py-3 text-sm font-bold text-white disabled:opacity-60">
          {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Add
        </button>
      </div>

      {/* List */}
      {categories === null ? (
        <Loading label="Loading categories…" />
      ) : categories.length === 0 ? (
        <div className="mwt-glass rounded-2xl p-12 text-center">
          <FolderTree className="mx-auto h-12 w-12 text-white/20" />
          <p className="mt-4 text-sm text-white/50">No categories yet. Websites will appear directly on the homepage.</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {categories.map((c) => (
            <div key={c.id} className="mwt-card p-4 flex items-center gap-4">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl mwt-btn-primary text-white">
                <FolderTree className="h-5 w-5" />
              </span>
              {editing?.id === c.id ? (
                <>
                  <input
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && renameCategory()}
                    maxLength={60}
                    autoFocus
                    className="flex-1 rounded-lg bg-white/5 border border-fuchsia-400/40 px-3 py-2 text-sm text-white outline-none"
                  />
                  <button onClick={renameCategory} disabled={busy} className="rounded-lg bg-emerald-500/15 border border-emerald-400/30 p-2 text-emerald-300 hover:bg-emerald-500/25 disabled:opacity-50">
                    <Check className="h-4 w-4" />
                  </button>
                  <button onClick={() => setEditing(null)} className="rounded-lg bg-white/5 border border-white/10 p-2 text-white/50 hover:text-white">
                    <X className="h-4 w-4" />
                  </button>
                </>
              ) : (
                <>
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold text-white/90">{c.name}</p>
                    <p className="text-xs text-white/35">/{c.slug} · {c._count.sites} website(s)</p>
                  </div>
                  <button
                    onClick={() => { setEditing(c); setEditName(c.name); }}
                    className="rounded-lg bg-white/5 border border-white/10 p-2 text-white/60 hover:text-white hover:border-fuchsia-400/40"
                    title="Rename"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setConfirmDelete(c)}
                    className="rounded-lg bg-red-500/10 border border-red-400/25 p-2 text-red-300 hover:bg-red-500/20"
                    title="Delete category"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </>
              )}
            </div>
          ))}
        </div>
      )}

      <AlertDialog open={!!confirmDelete} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <AlertDialogContent className="bg-[#161226] border-white/10 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete category &quot;{confirmDelete?.name}&quot;?</AlertDialogTitle>
            <AlertDialogDescription className="text-white/60">
              {confirmDelete?._count.sites ?? 0} website(s) will become uncategorized but stay published and untouched.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/10 border-white/10 text-white hover:bg-white/20">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={doDelete} disabled={busy} className="bg-red-600 hover:bg-red-500 text-white">Delete category</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
