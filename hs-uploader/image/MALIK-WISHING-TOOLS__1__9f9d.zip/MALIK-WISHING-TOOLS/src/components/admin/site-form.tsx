"use client";

import { useState, useRef, FormEvent, ChangeEvent } from "react";
import { useRouter } from "next/navigation";
import {
  UploadCloud, FileArchive, FileCode2, Image as ImageIcon, Loader2, Info,
  CheckCircle2, Globe, Star, Route, ShieldCheck, Eye, Wand2,
} from "lucide-react";
import { toast } from "sonner";

interface Category { id: string; name: string }

export function SiteForm({ categories }: { categories: Category[] }) {
  const router = useRouter();
  const zipInput = useRef<HTMLInputElement>(null);
  const htmlInput = useRef<HTMLInputElement>(null);
  const thumbInput = useRef<HTMLInputElement>(null);

  const [mode, setMode] = useState<"zip" | "html">("zip");
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [description, setDescription] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [publishNow, setPublishNow] = useState(true);
  const [featured, setFeatured] = useState(false);
  const [spaMode, setSpaMode] = useState(false);
  const [zipFile, setZipFile] = useState<File | null>(null);
  const [htmlFiles, setHtmlFiles] = useState<File[]>([]);
  const [thumbnail, setThumbnail] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ url: string; warnings: string[] } | null>(null);
  const [dragOver, setDragOver] = useState(false);

  function autoSlugFromName(v: string) {
    if (slug) return; // don't overwrite manual slug
    const s = v.toLowerCase().trim().replace(/[^a-z0-9\s-]/g, "").replace(/[\s_]+/g, "-").replace(/-+/g, "-");
    setSlugState(s);
  }
  const setSlugState = (v: string) => setSlug(v.slice(0, 60));

  function onZipChange(e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    setZipFile(f && f.size > 0 ? f : null);
    if (f && !name) {
      const base = f.name.replace(/\.zip$/i, "").replace(/[-_]+/g, " ");
      setName(base.replace(/\b\w/g, (c) => c.toUpperCase()));
      autoSlugFromName(base);
    }
  }

  function onHtmlChange(e: ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    setHtmlFiles(files);
    if (files.length > 0 && !name) {
      const indexHtml = files.find((f) => /(^|\/)index\.html?$/i.test(f.name));
      const base = (indexHtml ? indexHtml.name.replace(/(^|\/)index\.html?$/i, "").replace(/(^\/|\/$)/g, "") : files[0].name.replace(/\.html?$/i, "")).replace(/[-_]+/g, " ").trim();
      if (base) {
        setName(base.replace(/\b\w/g, (c) => c.toUpperCase()));
        autoSlugFromName(base);
      }
    }
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    if (!name.trim()) return void toast.error("Please enter a website name.");
    if (mode === "zip" && !zipFile) return void toast.error("Please choose a ZIP file.");
    if (mode === "html" && htmlFiles.length === 0) return void toast.error("Please choose at least one HTML file.");

    setBusy(true);
    try {
      const form = new FormData();
      form.set("name", name.trim());
      form.set("slug", slug.trim());
      form.set("description", description.trim());
      form.set("categoryId", categoryId);
      form.set("published", String(publishNow));
      form.set("featured", String(featured));
      form.set("spaMode", String(spaMode));
      form.set("mode", mode);
      if (mode === "zip" && zipFile) form.set("zip", zipFile, zipFile.name);
      if (mode === "html") for (const f of htmlFiles) form.append("files", f, f.name);
      if (thumbnail) form.set("thumbnail", thumbnail, thumbnail.name);

      const res = await fetch("/api/admin/sites/", { method: "POST", body: form });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast.error(data.error || "Upload failed.");
        return;
      }
      setResult({ url: data.url, warnings: data.warnings ?? [] });
      toast.success(`Website ${publishNow ? "published" : "saved"} successfully!`);
      for (const w of data.warnings ?? []) toast.warning(w);
      router.refresh();
    } catch {
      toast.error("Network error during upload. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  if (result) {
    return (
      <div className="max-w-2xl mx-auto text-center mwt-glass rounded-3xl p-10">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500/15 text-emerald-300">
          <CheckCircle2 className="h-8 w-8" />
        </span>
        <h1 className="mt-5 font-display text-3xl font-black mwt-gradient-text">Website Published!</h1>
        <p className="mt-2 text-sm text-white/50">
          {`"${name}"`} is now {publishNow ? "live on the public homepage" : "saved as a draft"}.
        </p>
        <div className="mt-6 rounded-xl bg-black/30 border border-white/10 px-4 py-3 text-sm text-fuchsia-200 break-all">
          {result.url}
        </div>
        {result.warnings.length > 0 && (
          <div className="mt-4 text-left rounded-xl bg-amber-500/10 border border-amber-400/25 p-4 text-xs text-amber-200 space-y-1">
            {result.warnings.map((w, i) => <p key={i}>• {w}</p>)}
          </div>
        )}
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <a href={result.url} target="_blank" rel="noopener noreferrer" className="mwt-btn-primary inline-flex items-center gap-2 rounded-xl px-6 py-3 font-bold text-white">
            <Eye className="h-4 w-4" /> Open Website
          </a>
          <button onClick={() => { setResult(null); setName(""); setSlug(""); setDescription(""); setZipFile(null); setHtmlFiles([]); setThumbnail(null); }} className="mwt-glass rounded-xl px-6 py-3 font-semibold text-white/80 hover:text-white">
            Upload Another
          </button>
          <a href="/admin/" className="mwt-glass rounded-xl px-6 py-3 font-semibold text-white/80 hover:text-white">Go to Dashboard</a>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="max-w-4xl space-y-6">
      <header>
        <h1 className="font-display text-3xl font-black"><span className="mwt-gradient-text">Add New Website</span></h1>
        <p className="mt-1 text-sm text-white/45">Upload a complete ZIP project or individual HTML files — it gets published automatically.</p>
      </header>

      {/* Mode selector */}
      <div className="grid grid-cols-2 gap-3">
        <ModeTab active={mode === "zip"} onClick={() => setMode("zip")} icon={<FileArchive className="h-5 w-5" />} title="ZIP Website Project" subtitle="Full project with CSS, JS, images & fonts" />
        <ModeTab active={mode === "html"} onClick={() => setMode("html")} icon={<FileCode2 className="h-5 w-5" />} title="HTML Files" subtitle="One or more HTML files + assets" />
      </div>

      {/* Dropzone */}
      {mode === "zip" ? (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            const f = e.dataTransfer.files?.[0];
            if (f) {
              const dt = new DataTransfer();
              dt.items.add(f);
              if (zipInput.current) {
                zipInput.current.files = dt.files;
                onZipChange({ target: { files: dt.files } } as ChangeEvent<HTMLInputElement>);
              }
            }
          }}
          onClick={() => zipInput.current?.click()}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === "Enter" && zipInput.current?.click()}
          className={`mwt-glass rounded-2xl border-2 border-dashed p-10 text-center cursor-pointer transition-all ${
            dragOver ? "border-fuchsia-400 bg-fuchsia-500/10" : "border-white/15 hover:border-fuchsia-400/50"
          }`}
        >
          <input ref={zipInput} type="file" accept=".zip,application/zip" className="hidden" onChange={onZipChange} />
          <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl mwt-btn-primary text-white">
            {zipFile ? <FileArchive className="h-7 w-7" /> : <UploadCloud className="h-7 w-7" />}
          </span>
          {zipFile ? (
            <>
              <p className="mt-4 font-semibold text-white">{zipFile.name}</p>
              <p className="mt-1 text-xs text-white/40">{(zipFile.size / 1024 / 1024).toFixed(2)} MB — click to choose a different file</p>
            </>
          ) : (
            <>
              <p className="mt-4 font-semibold text-white/85">Drop your website ZIP here, or click to browse</p>
              <p className="mt-1 text-xs text-white/40">Max 60 MB · auto-extracts · entry point detected automatically</p>
            </>
          )}
        </div>
      ) : (
        <div
          onClick={() => htmlInput.current?.click()}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === "Enter" && htmlInput.current?.click()}
          className="mwt-glass rounded-2xl border-2 border-dashed border-white/15 hover:border-fuchsia-400/50 p-10 text-center cursor-pointer transition-all"
        >
          <input ref={htmlInput} type="file" multiple accept=".html,.htm,.css,.js,.mjs,.json,.png,.jpg,.jpeg,.gif,.webp,.svg,.ico,.woff,.woff2,.ttf,.otf,.eot,.mp3,.mp4,.webm,.ogg,.wav,.txt,.xml,.webmanifest,.pdf,.avif,.map,.vtt" className="hidden" onChange={onHtmlChange} />
          <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl mwt-btn-primary text-white">
            {htmlFiles.length ? <FileCode2 className="h-7 w-7" /> : <UploadCloud className="h-7 w-7" />}
          </span>
          {htmlFiles.length ? (
            <>
              <p className="mt-4 font-semibold text-white">{htmlFiles.length} file(s) selected</p>
              <p className="mt-1 text-xs text-white/40 truncate max-w-md mx-auto">{htmlFiles.slice(0, 4).map((f) => f.name).join(", ")}{htmlFiles.length > 4 ? ` +${htmlFiles.length - 4} more` : ""}</p>
            </>
          ) : (
            <>
              <p className="mt-4 font-semibold text-white/85">Click to choose HTML files &amp; assets</p>
              <p className="mt-1 text-xs text-white/40">Include an index.html — multi-select supported (Ctrl/Cmd + click)</p>
            </>
          )}
        </div>
      )}

      {/* Details */}
      <div className="mwt-glass rounded-2xl p-6 space-y-5">
        <h2 className="font-display font-bold text-lg flex items-center gap-2"><Wand2 className="h-5 w-5 text-fuchsia-300" /> Website Details</h2>

        <div className="grid md:grid-cols-2 gap-5">
          <Field label="Website Name *" hint="Shown on the public card">
            <input value={name} onChange={(e) => { setName(e.target.value); autoSlugFromName(e.target.value); }} required maxLength={120} placeholder="e.g. Happy Birthday Wishes" className={inputCls} />
          </Field>
          <Field label="URL Slug (optional)" hint={`Public URL: /sites/${slug || "your-website"}/`}>
            <div className="relative">
              <Route className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
              <input value={slug} onChange={(e) => setSlugState(e.target.value.toLowerCase())} placeholder="auto-generated from name" className={`${inputCls} pl-10`} />
            </div>
          </Field>
        </div>

        <Field label="Short Description (optional)" hint="Displayed under the name on the card">
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} maxLength={500} rows={2} placeholder="e.g. A magical birthday card with music, balloons and cake!" className={`${inputCls} resize-none`} />
        </Field>

        <Field label="Category (optional)" hint="Websites without a category appear directly on the homepage">
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => setCategoryId("")} className={`rounded-full px-4 py-2 text-sm font-semibold transition-all ${categoryId === "" ? "mwt-btn-primary text-white" : "bg-white/5 border border-white/10 text-white/60 hover:text-white"}`}>
              No Category
            </button>
            {categories.map((c) => (
              <button key={c.id} type="button" onClick={() => setCategoryId(categoryId === c.id ? "" : c.id)} className={`rounded-full px-4 py-2 text-sm font-semibold transition-all ${categoryId === c.id ? "mwt-btn-primary text-white" : "bg-white/5 border border-white/10 text-white/60 hover:text-white"}`}>
                {c.name}
              </button>
            ))}
          </div>
        </Field>

        <Field label="Thumbnail (optional)" hint="Custom card image — a stylish auto-design is generated if empty">
          <div className="flex items-center gap-3">
            <input ref={thumbInput} type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="hidden" onChange={(e) => setThumbnail(e.target.files?.[0] ?? null)} />
            <button type="button" onClick={() => thumbInput.current?.click()} className="mwt-glass inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold text-white/80 hover:text-white">
              <ImageIcon className="h-4 w-4" /> {thumbnail ? thumbnail.name.slice(0, 28) : "Choose image…"}
            </button>
            {thumbnail && (
              <button type="button" onClick={() => { setThumbnail(null); if (thumbInput.current) thumbInput.current.value = ""; }} className="text-xs text-red-300 hover:text-red-200">
                Remove
              </button>
            )}
          </div>
        </Field>

        <div className="grid sm:grid-cols-2 gap-4 pt-1">
          <Toggle checked={publishNow} onChange={setPublishNow} icon={<Globe className="h-4 w-4" />} title="Publish immediately" subtitle="Visible on the public homepage right away" />
          <Toggle checked={featured} onChange={setFeatured} icon={<Star className="h-4 w-4" />} title="Mark as featured" subtitle="Shows in the Featured section" />
          <Toggle checked={spaMode} onChange={setSpaMode} icon={<Route className="h-4 w-4" />} title="Client-side routing (SPA)" subtitle="Unknown URLs fall back to index.html" />
          <Toggle checked onChange={() => {}} icon={<ShieldCheck className="h-4 w-4" />} title="Security isolation" subtitle="Always on — uploaded code runs sandboxed" disabled />
        </div>
      </div>

      <div className="flex items-start gap-3 rounded-2xl bg-sky-500/10 border border-sky-400/20 p-4 text-xs text-sky-200/80">
        <Info className="h-4 w-4 shrink-0 mt-0.5" />
        <p>
          Security: ZIPs are scanned for path traversal and dangerous file types (server scripts, executables).
          Uploaded websites run in an isolated sandboxed origin and can never access this admin panel.
          Max 800 files / 80 MB uncompressed.
        </p>
      </div>

      <div className="flex flex-wrap gap-3 pb-4">
        <button type="submit" disabled={busy} className="mwt-btn-primary inline-flex items-center gap-2 rounded-xl px-8 py-3.5 font-bold text-white disabled:opacity-60">
          {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <UploadCloud className="h-5 w-5" />}
          {busy ? "Uploading & publishing…" : publishNow ? "Upload & Publish" : "Upload & Save Draft"}
        </button>
        <button type="button" onClick={() => router.push("/admin/sites/")} className="mwt-glass rounded-xl px-6 py-3.5 font-semibold text-white/70 hover:text-white">
          Cancel
        </button>
      </div>
    </form>
  );
}

const inputCls = "w-full rounded-xl bg-white/5 border border-white/10 px-4 py-3 text-sm text-white placeholder:text-white/30 outline-none focus:border-fuchsia-400/60 focus:ring-2 focus:ring-fuchsia-500/20 transition-all";

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs font-semibold uppercase tracking-wider text-white/50">{label}</label>
      {hint && <p className="mt-0.5 text-[11px] text-white/30">{hint}</p>}
      <div className="mt-2">{children}</div>
    </div>
  );
}

function ModeTab({ active, onClick, icon, title, subtitle }: { active: boolean; onClick: () => void; icon: React.ReactNode; title: string; subtitle: string }) {
  return (
    <button type="button" onClick={onClick} className={`rounded-2xl p-5 text-left border transition-all ${active ? "mwt-btn-primary text-white border-transparent" : "mwt-glass text-white/60 hover:border-fuchsia-400/40"}`}>
      <span className="flex items-center gap-2 font-display font-bold">
        {icon} {title}
      </span>
      <span className={`mt-1 block text-xs ${active ? "text-white/80" : "text-white/40"}`}>{subtitle}</span>
    </button>
  );
}

function Toggle({ checked, onChange, icon, title, subtitle, disabled = false }: { checked: boolean; onChange: (v: boolean) => void; icon: React.ReactNode; title: string; subtitle: string; disabled?: boolean }) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => !disabled && onChange(!checked)}
      className={`flex items-start gap-3 rounded-xl border p-4 text-left transition-all ${checked ? "border-fuchsia-400/40 bg-fuchsia-500/10" : "border-white/10 bg-white/[0.03]"} ${disabled ? "opacity-70 cursor-not-allowed" : "hover:border-fuchsia-400/40"}`}
    >
      <span className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${checked ? "mwt-btn-primary text-white" : "bg-white/5 text-white/50"}`}>{icon}</span>
      <span className="min-w-0">
        <span className="block text-sm font-semibold text-white/90">{title}</span>
        <span className="mt-0.5 block text-[11px] text-white/40">{subtitle}</span>
      </span>
      <span className={`ml-auto mt-1 h-5 w-9 shrink-0 rounded-full p-0.5 transition-colors ${checked ? "bg-fuchsia-500" : "bg-white/15"}`}>
        <span className={`block h-4 w-4 rounded-full bg-white transition-transform ${checked ? "translate-x-4" : ""}`} />
      </span>
    </button>
  );
}
