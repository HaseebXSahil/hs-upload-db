"use client";

import { useState, useEffect, useMemo, useCallback } from "react";
import { motion } from "framer-motion";
import { useTheme } from "next-themes";
import {
  Search, Sparkles, Star, Eye, ExternalLink, Moon, Sun, Gift, Heart, PartyPopper,
  MessageCircle, Send, Globe, LayoutGrid, Layers, Crown, ChevronDown, Zap,
} from "lucide-react";

// ---------------- Types ----------------

export interface PublicSite {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  featured: boolean;
  views: number;
  hasThumbnail: boolean;
  updatedAt: string;
  sizeLabel: string;
  category: { id: string; name: string; slug: string } | null;
}

interface Props {
  sites: PublicSite[];
  categories: { id: string; name: string; slug: string }[];
  settings: {
    siteTitle: string;
    tagline: string;
    heroSubtitle: string;
    creatorName: string;
    creditLine: string;
    footerNote: string;
  };
  contacts: { whatsapp?: string; telegram?: string };
  stats: { totalSites: number; totalCategories: number; totalViews: number; totalSizeLabel: string };
}

const WORDS = ["Birthday", "Anniversary", "Proposal", "Friendship", "Eid Mubarak", "Congrats", "Love", "Good Luck"];

// ---------------- Root ----------------

export function HomeClient(props: Props) {
  return <Inner {...props} />;
}

function Inner({ sites, categories, settings, contacts, stats }: Props) {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const { theme, setTheme } = useTheme();

  // Track homepage visit (once per session)
  useEffect(() => {
    if (sessionStorage.getItem("mwt_tracked") !== "1") {
      sessionStorage.setItem("mwt_tracked", "1");
      fetch("/api/track/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: "/" }),
      }).catch(() => {});
    }
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return sites.filter((s) => {
      if (activeCategory && s.category?.id !== activeCategory) return false;
      if (!q) return true;
      return (
        s.name.toLowerCase().includes(q) ||
        (s.description ?? "").toLowerCase().includes(q) ||
        (s.category?.name ?? "").toLowerCase().includes(q)
      );
    });
  }, [sites, query, activeCategory]);

  const featured = filtered.filter((s) => s.featured);
  const regular = filtered.filter((s) => !s.featured);

  const toggleTheme = useCallback(() => {
    setTheme(theme === "dark" ? "light" : "dark");
  }, [theme, setTheme]);

  return (
    <div className="mwt-bg-base min-h-screen flex flex-col text-[#eceaf6]">
      {/* light theme text color override */}
      <AnimatedBackground />

      {/* ---------- Navbar ---------- */}
      <header className="sticky top-0 z-40 mwt-glass border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
          <a href="#top" className="flex items-center gap-2.5 min-w-0 group">
            <span className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl mwt-btn-primary text-white">
              <Sparkles className="h-5 w-5" />
            </span>
            <span className="font-display font-extrabold text-lg sm:text-xl tracking-tight truncate mwt-gradient-text">
              {settings.siteTitle}
            </span>
          </a>
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-white/70">
            <a href="#featured" className="hover:text-white transition-colors">Featured</a>
            <a href="#tools" className="hover:text-white transition-colors">All Tools</a>
            <a href="#about" className="hover:text-white transition-colors">About</a>
            <a href="#contact" className="hover:text-white transition-colors">Contact</a>
          </nav>
          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              aria-label="Toggle dark / light theme"
              className="h-10 w-10 rounded-full mwt-glass flex items-center justify-center text-white/80 hover:text-white hover:border-fuchsia-400/40 transition-all"
            >
              <Sun className="h-5 w-5 hidden dark:block" />
              <Moon className="h-5 w-5 dark:hidden" />
            </button>
            <a
              href="#tools"
              className="hidden sm:inline-flex mwt-btn-primary items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold text-white"
            >
              <Zap className="h-4 w-4" /> Explore Tools
            </a>
          </div>
        </div>
      </header>

      <main id="top" className="flex-1">
        {/* ---------- HERO ---------- */}
        <section className="relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-16 pb-14 sm:pt-24 sm:pb-20 text-center relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 rounded-full mwt-glass px-4 py-1.5 text-xs sm:text-sm font-medium text-amber-200/90 border border-amber-300/20"
            >
              <Sparkles className="h-3.5 w-3.5 text-amber-300" />
              Premium Wishing Websites &amp; Digital Celebration Tools
              <Sparkles className="h-3.5 w-3.5 text-amber-300" />
            </motion.div>

            {/* Brand title — staggered animated gradient words */}
            <h1 className="mt-6 font-display font-black tracking-tight leading-[1.02]">
              <span className="sr-only">{settings.siteTitle}</span>
              <span aria-hidden className="block">
                {settings.siteTitle.split(" ").map((word, i) => (
                  <motion.span
                    key={`${word}-${i}`}
                    initial={{ opacity: 0, y: 40, rotateX: -50 }}
                    animate={{ opacity: 1, y: 0, rotateX: 0 }}
                    transition={{ delay: 0.15 + i * 0.18, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
                    className="inline-block mwt-gradient-text mwt-glow mwt-shine px-[0.08em] text-[11vw] sm:text-6xl md:text-7xl lg:text-[5.2rem]"
                  >
                    {word}
                  </motion.span>
                ))}
              </span>
            </h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7, duration: 0.7 }}
              className="mt-6 max-w-2xl mx-auto text-base sm:text-lg text-white/60 dark:text-white/60 light:text-slate-600 leading-relaxed"
            >
              {settings.heroSubtitle}
            </motion.p>

            {/* Creator credit */}
            <motion.div
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.95, duration: 0.8 }}
              className="mt-7 inline-flex flex-col items-center"
            >
              <span className="text-[11px] sm:text-xs uppercase tracking-[0.35em] text-white/45 light:text-slate-500 font-medium">
                {settings.creditLine}
              </span>
              <span className="font-signature text-4xl sm:text-5xl mt-1 mwt-gradient-text mwt-glow">
                {settings.creatorName}
              </span>
              <span className="mt-1 h-px w-40 bg-gradient-to-r from-transparent via-fuchsia-400/70 to-transparent" />
            </motion.div>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.15, duration: 0.7 }}
              className="mt-9 flex flex-wrap items-center justify-center gap-4"
            >
              <a
                href="#tools"
                className="mwt-btn-primary inline-flex items-center gap-2 rounded-full px-7 py-3.5 font-semibold text-white"
              >
                <PartyPopper className="h-5 w-5" /> Explore All Tools
              </a>
              {contacts.whatsapp && (
                <a
                  href={contacts.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mwt-glass inline-flex items-center gap-2 rounded-full px-7 py-3.5 font-semibold text-emerald-300 border-emerald-400/25 hover:border-emerald-300/60 transition-all hover:-translate-y-0.5"
                >
                  <MessageCircle className="h-5 w-5" /> WhatsApp
                </a>
              )}
            </motion.div>

            {/* Stats strip */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.3, duration: 0.7 }}
              className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-3xl mx-auto"
            >
              <StatChip icon={<Gift className="h-4 w-4" />} label="Wishing Tools" value={String(stats.totalSites)} />
              <StatChip icon={<Layers className="h-4 w-4" />} label="Categories" value={String(stats.totalCategories)} />
              <StatChip icon={<Eye className="h-4 w-4" />} label="Total Opens" value={formatNumber(stats.totalViews)} />
              <StatChip icon={<Globe className="h-4 w-4" />} label="Hosted Content" value={stats.totalSizeLabel} />
            </motion.div>
          </div>

          {/* Marquee ribbon */}
          <div className="relative border-y border-white/5 bg-white/[0.02] py-3 overflow-hidden light:bg-purple-50/60">
            <div className="flex w-max mwt-marquee gap-10 whitespace-nowrap">
              {[...WORDS, ...WORDS, ...WORDS, ...WORDS].map((w, i) => (
                <span key={i} className="flex items-center gap-3 text-sm font-semibold uppercase tracking-[0.25em] text-white/35 light:text-purple-900/50">
                  {w} <Heart className="h-3.5 w-3.5 text-fuchsia-400/70" />
                </span>
              ))}
            </div>
          </div>
        </section>

        {/* ---------- FEATURED ---------- */}
        {featured.length > 0 && (
          <section id="featured" className="relative max-w-7xl mx-auto px-4 sm:px-6 pt-16 sm:pt-20 scroll-mt-20">
            <SectionHeading
              eyebrow={<><Crown className="h-4 w-4" /> Handpicked</>}
              title="Featured Websites"
              subtitle="Our most loved wishing experiences — open one and make someone's day."
            />
            <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {featured.slice(0, 6).map((site, i) => (
                <SiteCard key={site.id} site={site} index={i} highlight />
              ))}
            </div>
          </section>
        )}

        {/* ---------- ALL TOOLS + SEARCH ---------- */}
        <section id="tools" className="relative max-w-7xl mx-auto px-4 sm:px-6 pt-16 sm:pt-20 scroll-mt-20">
          <SectionHeading
            eyebrow={<><LayoutGrid className="h-4 w-4" /> Collection</>}
            title="All Wishing Tools"
            subtitle="Search by name or filter by category — every tool opens instantly."
          />

          <div className="mt-8 flex flex-col lg:flex-row lg:items-center gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-white/40" />
              <input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search wishing websites… e.g. birthday, proposal"
                aria-label="Search wishing websites"
                className="w-full mwt-glass rounded-2xl pl-12 pr-4 py-3.5 text-sm sm:text-base text-white placeholder:text-white/35 outline-none focus:border-fuchsia-400/60 focus:ring-2 focus:ring-fuchsia-500/20 transition-all light:text-slate-800"
              />
            </div>
            {/* Category chips */}
            <div className="flex gap-2 overflow-x-auto mwt-scroll pb-1 -mx-1 px-1">
              <CategoryChip active={activeCategory === null} onClick={() => setActiveCategory(null)} label="All" />
              {categories.map((c) => (
                <CategoryChip
                  key={c.id}
                  active={activeCategory === c.id}
                  onClick={() => setActiveCategory(activeCategory === c.id ? null : c.id)}
                  label={c.name}
                />
              ))}
            </div>
          </div>

          {/* Grid */}
          {filtered.length === 0 ? (
            <EmptyState query={query} />
          ) : (
            <div className="mt-8">
              {regular.length > 0 || featured.length > 0 ? (
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {[...featured, ...regular].map((site, i) => (
                    <SiteCard key={site.id} site={site} index={i} />
                  ))}
                </div>
              ) : (
                <EmptyState query={query} />
              )}
            </div>
          )}
        </section>

        {/* ---------- ABOUT ---------- */}
        <section id="about" className="relative max-w-7xl mx-auto px-4 sm:px-6 pt-20 sm:pt-24 scroll-mt-20">
          <div className="mwt-glass rounded-3xl p-8 sm:p-12 relative overflow-hidden">
            {/* GPU-safe gradient glow orbs (no filter:blur — mobile rendering fix) */}
            <div
              aria-hidden
              className="mwt-orb h-64 w-64 -top-20 -right-20 opacity-60"
              style={{ "--orb-color": "rgba(217, 70, 239, 0.28)" } as React.CSSProperties}
            />
            <div
              aria-hidden
              className="mwt-orb h-64 w-64 -bottom-20 -left-20 opacity-60"
              style={{ "--orb-color": "rgba(245, 199, 106, 0.22)", animationDelay: "-8s" } as React.CSSProperties}
            />
            <div className="relative grid lg:grid-cols-2 gap-10 items-center">
              <div>
                <SectionHeading
                  align="left"
                  eyebrow={<><Sparkles className="h-4 w-4" /> Welcome</>}
                  title="Every wish deserves a beautiful home"
                  subtitle=""
                />
                <p className="mt-4 text-white/60 light:text-slate-600 leading-relaxed">
                  {settings.siteTitle} is a curated collection of interactive wishing
                  websites — open a card, share the link, and light up someone&apos;s special
                  moment. Every tool runs instantly in your browser: no accounts, no
                  sign-ups, no friction. Just open, enjoy and share the joy.
                </p>
                <ul className="mt-6 space-y-3 text-sm text-white/70 light:text-slate-600">
                  {[
                    "Instant access — every website opens with one click",
                    "Works beautifully on mobile, tablet and desktop",
                    "Fresh designs added regularly by the administrator",
                    "Share any tool with a simple link",
                  ].map((line) => (
                    <li key={line} className="flex items-start gap-3">
                      <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full mwt-btn-primary text-white">
                        <Sparkles className="h-3 w-3" />
                      </span>
                      {line}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { icon: <Gift className="h-6 w-6" />, title: "Birthdays", text: "Musical cards & cake-blowing fun" },
                  { icon: <Heart className="h-6 w-6" />, title: "Anniversaries", text: "Timeless love-story celebrations" },
                  { icon: <PartyPopper className="h-6 w-6" />, title: "Proposals", text: "Say it with style & sparkles" },
                  { icon: <Star className="h-6 w-6" />, title: "Special Days", text: "Eid, congrats, luck & more" },
                ].map((f) => (
                  <div key={f.title} className="mwt-card p-5">
                    <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl mwt-btn-primary text-white">
                      {f.icon}
                    </span>
                    <h3 className="mt-3 font-display font-bold text-white light:text-slate-800">{f.title}</h3>
                    <p className="mt-1 text-xs text-white/50 light:text-slate-500 leading-relaxed">{f.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ---------- CONTACT ---------- */}
        <section id="contact" className="relative max-w-7xl mx-auto px-4 sm:px-6 pt-20 sm:pt-24 pb-20 scroll-mt-20">
          <div className="text-center max-w-2xl mx-auto">
            <SectionHeading
              eyebrow={<><Send className="h-4 w-4" /> Get in touch</>}
              title="Need a custom wishing website?"
              subtitle="The administrator creates bespoke wishing websites for birthdays, weddings, proposals and more. Reach out directly — replies are fast."
            />
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              {contacts.whatsapp && (
                <a
                  href={contacts.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mwt-btn-gold inline-flex items-center gap-3 rounded-full px-7 py-3.5 font-bold"
                >
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#25D366] text-white">
                    <MessageCircle className="h-4 w-4" />
                  </span>
                  Chat on WhatsApp
                </a>
              )}
              {contacts.telegram && (
                <a
                  href={contacts.telegram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mwt-glass inline-flex items-center gap-3 rounded-full px-7 py-3.5 font-bold text-sky-300 border-sky-400/30 hover:border-sky-300/60 transition-all hover:-translate-y-0.5"
                >
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#229ED9] text-white">
                    <Send className="h-4 w-4" />
                  </span>
                  Message on Telegram
                </a>
              )}
            </div>
          </div>
        </section>
      </main>

      {/* ---------- FOOTER ---------- */}
      <footer className="relative mt-auto border-t border-white/5 bg-black/20 light:bg-purple-100/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 pb-[calc(3rem+env(safe-area-inset-bottom))]">
          <div className="flex flex-col items-center text-center gap-4">
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl mwt-btn-primary text-white">
                <Sparkles className="h-4.5 w-4.5" />
              </span>
              <span className="font-display font-extrabold text-lg mwt-gradient-text">{settings.siteTitle}</span>
            </div>
            <p className="text-sm text-white/50 light:text-slate-500 max-w-md leading-relaxed">{settings.footerNote}</p>
            <div className="flex items-center gap-4 text-white/40 light:text-slate-500">
              {contacts.whatsapp && (
                <a href={contacts.whatsapp} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" className="hover:text-emerald-300 transition-colors">
                  <MessageCircle className="h-5 w-5" />
                </a>
              )}
              {contacts.telegram && (
                <a href={contacts.telegram} target="_blank" rel="noopener noreferrer" aria-label="Telegram" className="hover:text-sky-300 transition-colors">
                  <Send className="h-5 w-5" />
                </a>
              )}
            </div>
            {/* Creator credit — animated */}
            <div className="mt-2 flex flex-col items-center">
              <span className="text-[10px] uppercase tracking-[0.4em] text-white/35 light:text-slate-400">{settings.creditLine}</span>
              <span className="font-signature text-3xl mt-1 mwt-gradient-text mwt-glow">{settings.creatorName}</span>
            </div>
            <p className="text-[11px] text-white/25 light:text-slate-400">
              © {new Date().getFullYear()} {settings.siteTitle}. All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* ---------- Floating contact buttons ---------- */}
      <FloatingContacts contacts={contacts} />
    </div>
  );
}

// ---------------- Pieces ----------------

function AnimatedBackground() {
  return (
    <div aria-hidden className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      <div className="mwt-grid-overlay" />
      {/* GPU-safe orbs: pure radial-gradient glow (no filter:blur) — fixes the
          mobile noise/tearing artifact seen on some Android GPUs */}
      <div
        className="mwt-orb h-80 w-80 top-[-6rem] left-[8%]"
        style={{ "--orb-color": "rgba(217, 70, 239, 0.5)" } as React.CSSProperties}
      />
      <div
        className="mwt-orb h-96 w-96 top-[30%] right-[-8rem]"
        style={{ "--orb-color": "rgba(168, 85, 247, 0.45)", animationDelay: "-6s" } as React.CSSProperties}
      />
      <div
        className="mwt-orb h-72 w-72 bottom-[8%] left-[20%]"
        style={{ "--orb-color": "rgba(245, 199, 106, 0.35)", animationDelay: "-11s" } as React.CSSProperties}
      />
      <div
        className="mwt-orb h-64 w-64 bottom-[30%] right-[25%]"
        style={{ "--orb-color": "rgba(34, 211, 238, 0.32)", animationDelay: "-3s" } as React.CSSProperties}
      />
    </div>
  );
}

function StatChip({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="mwt-glass rounded-2xl px-4 py-4 flex items-center gap-3">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white/10 text-amber-300 light:bg-purple-100">{icon}</span>
      <div className="min-w-0 text-left">
        <div className="font-display font-extrabold text-lg leading-none text-white light:text-slate-800">{value}</div>
        <div className="text-[11px] text-white/45 light:text-slate-500 mt-1 truncate">{label}</div>
      </div>
    </div>
  );
}

function SectionHeading({
  eyebrow, title, subtitle, align = "center",
}: { eyebrow: React.ReactNode; title: string; subtitle?: string; align?: "center" | "left" }) {
  return (
    <Reveal className={align === "center" ? "text-center" : "text-left"}>
      <span className="inline-flex items-center gap-2 rounded-full border border-fuchsia-400/25 bg-fuchsia-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-fuchsia-300">
        {eyebrow}
      </span>
      <h2 className="mt-4 font-display text-3xl sm:text-4xl font-extrabold tracking-tight text-white light:text-slate-800">
        {title}
      </h2>
      {subtitle ? (
        <p className="mt-3 text-white/55 light:text-slate-500 max-w-2xl mx-auto leading-relaxed">{subtitle}</p>
      ) : null}
    </Reveal>
  );
}

function Reveal({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useCallback((node: HTMLElement | null) => {
    if (!node) return;
    const obs = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            e.target.classList.add("mwt-revealed");
            obs.disconnect();
          }
        }
      },
      { threshold: 0.12 }
    );
    obs.observe(node);
  }, []);
  return (
    <div ref={ref} className={`mwt-reveal ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

function CategoryChip({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition-all ${
        active
          ? "mwt-btn-primary text-white"
          : "mwt-glass text-white/65 light:text-slate-600 hover:text-white light:hover:text-purple-700 hover:border-fuchsia-400/40"
      }`}
    >
      {label}
    </button>
  );
}

const CARD_GRADIENTS = [
  "from-fuchsia-500 via-purple-500 to-indigo-500",
  "from-amber-400 via-orange-500 to-rose-500",
  "from-cyan-400 via-sky-500 to-blue-500",
  "from-emerald-400 via-teal-500 to-cyan-600",
  "from-rose-400 via-pink-500 to-fuchsia-600",
  "from-violet-400 via-purple-500 to-fuchsia-500",
];

function SiteCard({ site, index, highlight = false }: { site: PublicSite; index: number; highlight?: boolean }) {
  const gradient = CARD_GRADIENTS[index % CARD_GRADIENTS.length];
  const initial = site.name.trim().charAt(0).toUpperCase() || "W";
  return (
    <Reveal delay={Math.min(index * 60, 300)} className="h-full">
      <article className={`mwt-card h-full flex flex-col overflow-hidden ${highlight ? "ring-1 ring-amber-300/30" : ""}`}>
        {/* Thumbnail */}
        <a href={`/sites/${site.slug}/`} target="_blank" rel="noopener noreferrer" className="block relative" aria-label={`Open ${site.name}`}>
          <div className={`relative aspect-[16/9] overflow-hidden bg-gradient-to-br ${gradient}`}>
            {site.hasThumbnail ? (
              <img
                src={`/api/public/sites/${site.id}/thumbnail`}
                alt={`${site.name} thumbnail`}
                className="h-full w-full object-cover transition-transform duration-500 hover:scale-105"
                loading="lazy"
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="font-display font-black text-7xl text-white/90 drop-shadow-lg select-none">{initial}</span>
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.25),transparent_45%)]" />
                <Sparkles className="absolute top-4 right-5 h-6 w-6 text-white/60" />
                <Heart className="absolute bottom-4 left-5 h-5 w-5 text-white/50" />
              </div>
            )}
            {site.featured && (
              <span className="absolute top-3 left-3 inline-flex items-center gap-1 rounded-full bg-black/60 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-amber-300 border border-amber-300/40">
                <Star className="h-3 w-3 fill-amber-300" /> Featured
              </span>
            )}
          </div>
        </a>

        {/* Body */}
        <div className="flex flex-1 flex-col p-5">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-display font-bold text-lg leading-snug text-white light:text-slate-800 line-clamp-2">
              {site.name}
            </h3>
          </div>
          {site.category && (
            <span className="mt-2 inline-flex w-fit items-center gap-1.5 rounded-full bg-fuchsia-500/12 border border-fuchsia-400/25 px-2.5 py-0.5 text-[11px] font-semibold text-fuchsia-300">
              <Layers className="h-3 w-3" /> {site.category.name}
            </span>
          )}
          <p className="mt-2 text-sm text-white/50 light:text-slate-500 leading-relaxed line-clamp-2 flex-1">
            {site.description || "Open this beautifully crafted wishing experience and share the joy."}
          </p>
          <div className="mt-4 flex items-center justify-between gap-3">
            <span className="inline-flex items-center gap-1.5 text-xs text-white/40 light:text-slate-400">
              <Eye className="h-3.5 w-3.5" /> {formatNumber(site.views)} opens
            </span>
            <a
              href={`/sites/${site.slug}/`}
              target="_blank"
              rel="noopener noreferrer"
              className="mwt-btn-primary inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold text-white"
            >
              Open Website <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      </article>
    </Reveal>
  );
}

function EmptyState({ query }: { query: string }) {
  return (
    <div className="mt-12 mwt-glass rounded-3xl p-12 text-center">
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl mwt-btn-primary text-white">
        <Search className="h-7 w-7" />
      </div>
      <h3 className="mt-5 font-display text-xl font-bold text-white light:text-slate-800">No websites found</h3>
      <p className="mt-2 text-sm text-white/50 light:text-slate-500">
        {query ? `Nothing matches "${query}". Try a different keyword or clear the filters.` : "New wishing websites are added by the administrator — check back soon!"}
      </p>
    </div>
  );
}

function FloatingContacts({ contacts }: { contacts: { whatsapp?: string; telegram?: string } }) {
  if (!contacts.whatsapp && !contacts.telegram) return null;
  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-3">
      {contacts.telegram && (
        <a
          href={contacts.telegram}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Contact on Telegram"
          className="mwt-float-btn mwt-pulse-ring relative flex h-[52px] w-[52px] items-center justify-center rounded-full bg-[#229ED9] text-white shadow-xl shadow-sky-900/40 hover:scale-110 transition-transform"
          style={{ animationDelay: "-1.7s" }}
        >
          <Send className="h-6 w-6" />
        </a>
      )}
      {contacts.whatsapp && (
        <a
          href={contacts.whatsapp}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Contact on WhatsApp"
          className="mwt-float-btn mwt-pulse-ring relative flex h-[52px] w-[52px] items-center justify-center rounded-full bg-[#25D366] text-white shadow-xl shadow-emerald-900/40 hover:scale-110 transition-transform"
        >
          <MessageCircle className="h-6 w-6" />
        </a>
      )}
    </div>
  );
}

function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}
