import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Standalone output is used for local / VPS / Docker serving.
  // On Netlify the official Next.js runtime handles the server, so we let it
  // use its own packaging (NETLIFY=1 is set automatically by Netlify builds).
  output: process.env.NETLIFY ? undefined : "standalone",
  // Uploaded sites live under /sites/<slug>/ — trailing slashes are handled by
  // the site route itself so relative asset paths (./style.css) resolve correctly.
  skipTrailingSlashRedirect: true,
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
