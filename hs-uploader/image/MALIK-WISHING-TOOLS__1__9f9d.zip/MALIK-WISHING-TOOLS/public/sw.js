/* MALIK WISHING TOOLS - Service Worker */
const CACHE = "mwt-v1";
const OFFLINE_URL = "/offline.html";

// Static app shell assets worth caching (homepage brand assets only).
// Uploaded site content (/sites/...) and APIs are always fetched live so
// updates appear instantly.
const APP_SHELL = [
  "/",
  "/offline.html",
  "/manifest.webmanifest",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Only handle same-origin GET
  if (event.request.method !== "GET" || url.origin !== self.location.origin) return;

  // Never cache APIs, admin, or uploaded websites (always fresh)
  if (
    url.pathname.startsWith("/api/") ||
    url.pathname.startsWith("/admin") ||
    url.pathname.startsWith("/sites/") ||
    url.pathname.startsWith("/_next/")
  ) {
    if (event.request.mode === "navigate" && !url.pathname.startsWith("/api/")) {
      event.respondWith(fetch(event.request).catch(() => caches.match(OFFLINE_URL)));
    }
    return;
  }

  // Navigation -> network first, offline fallback
  if (event.request.mode === "navigate") {
    event.respondWith(
      fetch(event.request)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(event.request, copy)).catch(() => {});
          return res;
        })
        .catch(() => caches.match(event.request).then((r) => r || caches.match(OFFLINE_URL)))
    );
    return;
  }

  // Static assets -> cache first, then network
  event.respondWith(
    caches.match(event.request).then(
      (cached) =>
        cached ||
        fetch(event.request).then((res) => {
          if (res.ok && (url.pathname.startsWith("/icons/") || url.pathname === "/manifest.webmanifest")) {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(event.request, copy)).catch(() => {});
          }
          return res;
        })
    )
  );
});
