/* =======================================================
   FRIENDSHIP WEBSITE — SCRIPT.JS
   Nothing in this file needs editing to change names, dates
   or messages — all of that lives in index.html. This file
   just powers the animations and interactions.
======================================================= */

document.addEventListener('DOMContentLoaded', () => {
  initParticles();
  initScrollReveal();
  initScrollDots();
  initCounters();
  initGalleryLightbox();
  initFunCards();
});

/* -------------------------------------------------------
   Ambient floating hearts / particles
------------------------------------------------------- */
function initParticles(){
  const canvas = document.getElementById('particles');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  let particles = [];
  const symbols = ['♥', '✦', '♡'];

  function resize(){
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();

  function spawn(){
    const count = window.innerWidth < 640 ? 18 : 32;
    particles = Array.from({ length: count }, () => ({
      x: Math.random() * canvas.width,
      y: canvas.height + Math.random() * canvas.height,
      size: Math.random() * 10 + 8,
      speed: Math.random() * 0.4 + 0.15,
      drift: (Math.random() - 0.5) * 0.3,
      opacity: Math.random() * 0.25 + 0.06,
      symbol: symbols[Math.floor(Math.random() * symbols.length)]
    }));
  }
  spawn();

  if (reduceMotion){
    // Draw a single static, subtle frame and stop — respects reduced motion.
    ctx.font = '16px sans-serif';
    particles.forEach(p => {
      ctx.globalAlpha = p.opacity;
      ctx.fillStyle = '#F2789F';
      ctx.font = `${p.size}px sans-serif`;
      ctx.fillText(p.symbol, p.x, p.y);
    });
    return;
  }

  function animate(){
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(p => {
      p.y -= p.speed;
      p.x += p.drift;
      if (p.y < -20){
        p.y = canvas.height + 20;
        p.x = Math.random() * canvas.width;
      }
      ctx.globalAlpha = p.opacity;
      ctx.fillStyle = '#F2789F';
      ctx.font = `${p.size}px sans-serif`;
      ctx.fillText(p.symbol, p.x, p.y);
    });
    requestAnimationFrame(animate);
  }
  animate();
}

/* -------------------------------------------------------
   Scroll-reveal: fade/rise elements into view once
------------------------------------------------------- */
function initScrollReveal(){
  const items = document.querySelectorAll('[data-reveal]');
  if (!items.length) return;

  if (!('IntersectionObserver' in window)){
    items.forEach(el => el.classList.add('is-visible'));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting){
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -60px 0px' });

  items.forEach(el => observer.observe(el));
}

/* -------------------------------------------------------
   Scroll dots: highlight the section currently in view
------------------------------------------------------- */
function initScrollDots(){
  const dots = document.querySelectorAll('.scroll-dots .dot');
  const sections = Array.from(dots)
    .map(dot => document.getElementById(dot.dataset.target))
    .filter(Boolean);
  if (!dots.length || !sections.length) return;

  if (!('IntersectionObserver' in window)) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting){
        dots.forEach(d => d.classList.remove('active'));
        const activeDot = document.querySelector(`.dot[data-target="${entry.target.id}"]`);
        if (activeDot) activeDot.classList.add('active');
      }
    });
  }, { threshold: 0.5 });

  sections.forEach(sec => observer.observe(sec));

  dots.forEach(dot => {
    dot.addEventListener('click', () => {
      const target = document.getElementById(dot.dataset.target);
      if (target) target.scrollIntoView({ behavior: 'smooth' });
    });
    dot.style.cursor = 'pointer';
  });
}

/* -------------------------------------------------------
   Animated counters: years, days, memories
   Reads the friendship start date from #friendsSinceLabel's
   data-date attribute (edit that in index.html).
------------------------------------------------------- */
function initCounters(){
  const dateLabel = document.getElementById('friendsSinceLabel');
  const yearsEl = document.getElementById('countYears');
  const daysEl = document.getElementById('countDays');
  const memoriesEl = document.getElementById('countMemories');
  if (!dateLabel || !yearsEl || !daysEl || !memoriesEl) return;

  const startDate = new Date(dateLabel.dataset.date);
  const now = new Date();
  const msPerDay = 1000 * 60 * 60 * 24;
  const totalDays = Math.max(0, Math.floor((now - startDate) / msPerDay));
  const totalYears = Math.max(0, (totalDays / 365.25));

  yearsEl.dataset.target = totalYears.toFixed(1);
  daysEl.dataset.target = totalDays;

  const counterSection = document.getElementById('counter');
  if (!counterSection) return;

  let animated = false;
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !animated){
        animated = true;
        animateNumber(yearsEl, parseFloat(yearsEl.dataset.target), true);
        animateNumber(daysEl, parseInt(daysEl.dataset.target, 10));
        animateNumber(memoriesEl, parseInt(memoriesEl.dataset.target, 10));
        observer.disconnect();
      }
    });
  }, { threshold: 0.4 });
  observer.observe(counterSection);
}

function animateNumber(el, target, isDecimal){
  const duration = 1400;
  const start = performance.now();
  const from = 0;

  function tick(now){
    const progress = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
    const value = from + (target - from) * eased;
    el.textContent = isDecimal ? value.toFixed(1) : Math.round(value).toLocaleString();
    if (progress < 1){
      requestAnimationFrame(tick);
    } else {
      el.textContent = isDecimal ? target.toFixed(1) : target.toLocaleString();
    }
  }
  requestAnimationFrame(tick);
}

/* -------------------------------------------------------
   Gallery lightbox
------------------------------------------------------- */
function initGalleryLightbox(){
  const items = document.querySelectorAll('.gallery-item:not(.gallery-empty) img');
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightboxImg');
  const closeBtn = document.getElementById('lightboxClose');
  if (!lightbox || !lightboxImg || !closeBtn) return;

  function openLightbox(src, alt){
    lightboxImg.src = src;
    lightboxImg.alt = alt || '';
    lightbox.classList.add('is-open');
    lightbox.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }
  function closeLightbox(){
    lightbox.classList.remove('is-open');
    lightbox.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  // Delegate on the gallery grid so it also works for photos added later.
  document.querySelectorAll('.gallery-item img').forEach(img => {
    img.addEventListener('click', () => {
      if (img.parentElement.classList.contains('gallery-empty')) return;
      openLightbox(img.src, img.alt);
    });
  });

  closeBtn.addEventListener('click', closeLightbox);
  lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) closeLightbox();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeLightbox();
  });
}

/* -------------------------------------------------------
   Fun friendship flip cards
------------------------------------------------------- */
function initFunCards(){
  const cards = document.querySelectorAll('.fun-card');
  cards.forEach(card => {
    card.addEventListener('click', () => {
      card.classList.toggle('is-flipped');
    });
  });
}
