require("dotenv").config();

const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const Database = require("better-sqlite3");
const ffmpegPath = require("ffmpeg-static");
const { spawn } = require("child_process");
const { EdgeTTS } = require("node-edge-tts");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "dev-only-change-me";
const FREE_VIDEOS_PER_DAY = Number(process.env.FREE_VIDEOS_PER_DAY || 3);
const MAX_VIDEO_SECONDS = Number(process.env.MAX_VIDEO_SECONDS || 60);

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, "data");
const GENERATED_DIR = path.join(ROOT, "generated");
const TMP_DIR = path.join(ROOT, "tmp");

for (const dir of [DATA_DIR, GENERATED_DIR, TMP_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}

const db = new Database(path.join(DATA_DIR, "vidai.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS videos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  language TEXT NOT NULL,
  voice TEXT NOT NULL,
  quality TEXT NOT NULL,
  duration INTEGER NOT NULL,
  filename TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_videos_user_created
ON videos(user_id, created_at);
`);

app.use(express.json({ limit: "100kb" }));
app.use(cookieParser());
app.use(express.static(path.join(ROOT, "public")));

const VOICES = {
  en: {
    label: "English",
    female: { name: "en-US-AriaNeural", lang: "en-US" },
    male: { name: "en-US-GuyNeural", lang: "en-US" }
  },
  ur: {
    label: "Urdu",
    female: { name: "ur-PK-UzmaNeural", lang: "ur-PK" },
    male: { name: "ur-PK-AsadNeural", lang: "ur-PK" }
  },
  hi: {
    label: "Hindi",
    female: { name: "hi-IN-SwaraNeural", lang: "hi-IN" },
    male: { name: "hi-IN-MadhurNeural", lang: "hi-IN" }
  },
  ar: {
    label: "Arabic",
    female: { name: "ar-SA-ZariyahNeural", lang: "ar-SA" },
    male: { name: "ar-SA-HamedNeural", lang: "ar-SA" }
  },
  es: {
    label: "Spanish",
    female: { name: "es-ES-ElviraNeural", lang: "es-ES" },
    male: { name: "es-ES-AlvaroNeural", lang: "es-ES" }
  },
  fr: {
    label: "French",
    female: { name: "fr-FR-DeniseNeural", lang: "fr-FR" },
    male: { name: "fr-FR-HenriNeural", lang: "fr-FR" }
  },
  de: {
    label: "German",
    female: { name: "de-DE-KatjaNeural", lang: "de-DE" },
    male: { name: "de-DE-ConradNeural", lang: "de-DE" }
  },
  it: {
    label: "Italian",
    female: { name: "it-IT-ElsaNeural", lang: "it-IT" },
    male: { name: "it-IT-DiegoNeural", lang: "it-IT" }
  },
  pt: {
    label: "Portuguese",
    female: { name: "pt-BR-FranciscaNeural", lang: "pt-BR" },
    male: { name: "pt-BR-AntonioNeural", lang: "pt-BR" }
  },
  tr: {
    label: "Turkish",
    female: { name: "tr-TR-EmelNeural", lang: "tr-TR" },
    male: { name: "tr-TR-AhmetNeural", lang: "tr-TR" }
  },
  zh: {
    label: "Chinese",
    female: { name: "zh-CN-XiaoxiaoNeural", lang: "zh-CN" },
    male: { name: "zh-CN-YunxiNeural", lang: "zh-CN" }
  },
  ja: {
    label: "Japanese",
    female: { name: "ja-JP-NanamiNeural", lang: "ja-JP" },
    male: { name: "ja-JP-KeitaNeural", lang: "ja-JP" }
  },
  ko: {
    label: "Korean",
    female: { name: "ko-KR-SunHiNeural", lang: "ko-KR" },
    male: { name: "ko-KR-InJoonNeural", lang: "ko-KR" }
  },
  ru: {
    label: "Russian",
    female: { name: "ru-RU-SvetlanaNeural", lang: "ru-RU" },
    male: { name: "ru-RU-DmitryNeural", lang: "ru-RU" }
  },
  bn: {
    label: "Bengali",
    female: { name: "bn-IN-TanishaaNeural", lang: "bn-IN" },
    male: { name: "bn-IN-BashkarNeural", lang: "bn-IN" }
  },
  pa: {
    label: "Punjabi",
    female: { name: "pa-IN-VaaniNeural", lang: "pa-IN" },
    male: { name: "pa-IN-OjasNeural", lang: "pa-IN" }
  }
};

function signToken(user) {
  return jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
}

function setAuthCookie(res, token) {
  res.cookie("vidai_token", token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * 60 * 60 * 1000
  });
}

function authRequired(req, res, next) {
  const token = req.cookies.vidai_token;
  if (!token) return res.status(401).json({ error: "Login required." });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Session expired. Please login again." });
  }
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function getUsage(userId) {
  const row = db.prepare(`
    SELECT COUNT(*) AS count
    FROM videos
    WHERE user_id = ?
      AND substr(created_at, 1, 10) = ?
  `).get(userId, todayKey());

  return {
    used: Number(row.count),
    limit: FREE_VIDEOS_PER_DAY,
    remaining: Math.max(0, FREE_VIDEOS_PER_DAY - Number(row.count))
  };
}

function cleanText(text, max = 3500) {
  return String(text || "")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, " ")
    .trim()
    .slice(0, max);
}

function makeTitle(text) {
  const first = text.split(/\r?\n/).find(Boolean) || "My AI Video";
  return first.replace(/\s+/g, " ").slice(0, 80);
}

function escapeDrawtext(text) {
  return text
    .replace(/\\/g, "\\\\")
    .replace(/:/g, "\\:")
    .replace(/'/g, "\\'")
    .replace(/%/g, "\\%");
}

function run(command, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { windowsHide: true });
    let stderr = "";
    child.stderr.on("data", d => { stderr += d.toString(); });
    child.on("error", reject);
    child.on("close", code => {
      if (code === 0) resolve();
      else reject(new Error(`Command failed (${code}): ${stderr.slice(-4000)}`));
    });
  });
}

async function synthesize(text, voiceConfig, output) {
  const tts = new EdgeTTS({
    voice: voiceConfig.name,
    lang: voiceConfig.lang,
    outputFormat: "audio-24khz-96kbitrate-mono-mp3",
    rate: "+0%",
    volume: "+0%",
    pitch: "+0Hz",
    timeout: 30000
  });

  await tts.ttsPromise(text, output);
}

async function getAudioDuration(file) {
  return new Promise((resolve, reject) => {
    const child = spawn(ffmpegPath, [
      "-i", file,
      "-f", "null",
      "-"
    ], { windowsHide: true });

    let stderr = "";
    child.stderr.on("data", d => { stderr += d.toString(); });
    child.on("error", reject);
    child.on("close", () => {
      const match = stderr.match(/Duration:\s*(\d+):(\d+):([\d.]+)/);
      if (!match) return reject(new Error("Could not determine audio duration."));
      resolve(
        Number(match[1]) * 3600 +
        Number(match[2]) * 60 +
        Number(match[3])
      );
    });
  });
}

function findFont() {
  const candidates = [
    process.env.VIDAI_FONT,
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/dejavu/DejaVuSans.ttf",
    "/Library/Fonts/Arial.ttf",
    "C:\\Windows\\Fonts\\arial.ttf"
  ].filter(Boolean);

  return candidates.find(fs.existsSync) || null;
}

async function renderVideo({ text, title, audio, output, quality, duration }) {
  const size = quality === "1080p" ? "1920x1080" : "1280x720";
  const font = findFont();

  const safeTitle = escapeDrawtext(title);
  const safeText = escapeDrawtext(text.slice(0, 900));

  const filters = [
    "format=yuv420p"
  ];

  if (font) {
    filters.unshift(
      `drawtext=fontfile='${font.replace(/\\/g, "\\\\").replace(/'/g, "\\'")}':text='${safeTitle}':fontcolor=white:fontsize=58:x=(w-text_w)/2:y=90:box=1:boxcolor=black@0.45:boxborderw=22`,
      `drawtext=fontfile='${font.replace(/\\/g, "\\\\").replace(/'/g, "\\'")}':text='${safeText}':fontcolor=white:fontsize=34:x=100:y=(h-text_h)/2:box=1:boxcolor=black@0.55:boxborderw=30:line_spacing=12`
    );
  }

  await run(ffmpegPath, [
    "-y",
    "-f", "lavfi",
    "-i", `color=c=0x171b2e:s=${size}:r=30`,
    "-i", audio,
    "-t", String(Math.min(duration, MAX_VIDEO_SECONDS)),
    "-vf", filters.join(","),
    "-c:v", "libx264",
    "-preset", "veryfast",
    "-crf", quality === "1080p" ? "22" : "24",
    "-c:a", "aac",
    "-b:a", "128k",
    "-movflags", "+faststart",
    output
  ]);
}

app.get("/api/voices", (req, res) => {
  res.json(VOICES);
});

app.post("/api/auth/register", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: "Enter a valid email address." });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters." });
  }

  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare(
      "INSERT INTO users(email, password_hash) VALUES(?, ?)"
    ).run(email, hash);

    const user = { id: Number(result.lastInsertRowid), email };
    setAuthCookie(res, signToken(user));
    res.json({ user, usage: getUsage(user.id) });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) {
      return res.status(409).json({ error: "An account with that email already exists." });
    }
    res.status(500).json({ error: "Could not create account." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: "Invalid email or password." });
  }

  setAuthCookie(res, signToken(user));
  res.json({
    user: { id: user.id, email: user.email },
    usage: getUsage(user.id)
  });
});

app.post("/api/auth/logout", (req, res) => {
  res.clearCookie("vidai_token");
  res.json({ ok: true });
});

app.get("/api/auth/me", (req, res) => {
  const token = req.cookies.vidai_token;
  if (!token) return res.json({ user: null });

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    res.json({
      user: { id: payload.id, email: payload.email },
      usage: getUsage(payload.id)
    });
  } catch {
    res.json({ user: null });
  }
});

app.get("/api/videos", authRequired, (req, res) => {
  const videos = db.prepare(`
    SELECT id, title, language, voice, quality, duration, created_at
    FROM videos
    WHERE user_id = ?
    ORDER BY id DESC
    LIMIT 50
  `).all(req.user.id);

  res.json(videos);
});

app.get("/api/videos/:id/download", authRequired, (req, res) => {
  const video = db.prepare(
    "SELECT * FROM videos WHERE id = ? AND user_id = ?"
  ).get(Number(req.params.id), req.user.id);

  if (!video) return res.status(404).send("Video not found.");

  const file = path.join(GENERATED_DIR, video.filename);
  if (!fs.existsSync(file)) return res.status(404).send("Video file no longer exists.");

  res.download(file, video.filename);
});

app.post("/api/videos", authRequired, async (req, res) => {
  const usage = getUsage(req.user.id);
  if (usage.remaining <= 0) {
    return res.status(429).json({
      error: `Free daily limit reached (${FREE_VIDEOS_PER_DAY} videos). Try again tomorrow.`
    });
  }

  const text = cleanText(req.body.text);
  const language = String(req.body.language || "en");
  const gender = String(req.body.gender || "female");
  const quality = String(req.body.quality || "720p");

  if (!text) return res.status(400).json({ error: "Enter a script or video description." });
  if (!VOICES[language]) return res.status(400).json({ error: "Unsupported language." });
  if (!["female", "male"].includes(gender)) return res.status(400).json({ error: "Unsupported voice." });
  if (!["720p", "1080p"].includes(quality)) return res.status(400).json({ error: "Unsupported quality." });

  const id = crypto.randomUUID();
  const workDir = path.join(TMP_DIR, id);
  fs.mkdirSync(workDir, { recursive: true });

  const audio = path.join(workDir, "voice.mp3");
  const outputName = `${id}.mp4`;
  const output = path.join(GENERATED_DIR, outputName);

  try {
    const voiceConfig = VOICES[language][gender];
    await synthesize(text, voiceConfig, audio);

    let duration = await getAudioDuration(audio);
    if (!Number.isFinite(duration) || duration <= 0) throw new Error("Invalid generated audio.");

    if (duration > MAX_VIDEO_SECONDS) {
      return res.status(400).json({
        error: `Your script is too long. Free videos are limited to ${MAX_VIDEO_SECONDS} seconds.`
      });
    }

    duration = Math.ceil(duration);

    const title = makeTitle(text);

    await renderVideo({
      text,
      title,
      audio,
      output,
      quality,
      duration
    });

    const insert = db.prepare(`
      INSERT INTO videos(user_id, title, language, voice, quality, duration, filename)
      VALUES(?, ?, ?, ?, ?, ?, ?)
    `).run(
      req.user.id,
      title,
      language,
      voiceConfig.name,
      quality,
      duration,
      outputName
    );

    res.json({
      id: Number(insert.lastInsertRowid),
      title,
      language,
      quality,
      duration,
      downloadUrl: `/api/videos/${Number(insert.lastInsertRowid)}/download`,
      usage: getUsage(req.user.id)
    });
  } catch (error) {
    console.error(error);
    if (fs.existsSync(output)) fs.unlinkSync(output);
    res.status(500).json({
      error: "Video generation failed. Check the server console for details."
    });
  } finally {
    fs.rmSync(workDir, { recursive: true, force: true });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(ROOT, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`VidAI running at http://localhost:${PORT}`);
  console.log(`Free videos/day: ${FREE_VIDEOS_PER_DAY}`);
  console.log(`Max duration: ${MAX_VIDEO_SECONDS}s`);
});
