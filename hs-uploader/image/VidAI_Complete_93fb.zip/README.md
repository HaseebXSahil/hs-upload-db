# VidAI Complete

A self-hosted starter for a multilingual narrated-video website.

## Included

- Node.js + Express backend
- SQLite user database
- Password hashing with bcrypt
- JWT login stored in an HttpOnly cookie
- 3 free videos per day by default
- Maximum video duration limit
- Multilingual Microsoft Edge online TTS through `node-edge-tts`
- FFmpeg rendering through `ffmpeg-static`
- 720p / 1080p output
- MP4 download
- Responsive frontend
- Video history for the logged-in user

## Important

This version creates narrated text videos: a generated background, title/script text, subtitles-style text, and multilingual narration. It is not a text-to-video diffusion model that invents photorealistic scenes.

The TTS service is online, so the server needs internet access while generating narration. The `ffmpeg-static` package supplies a platform-specific FFmpeg binary during npm installation.

## Run

1. Install Node.js 20+.
2. Extract this project.
3. Copy `.env.example` to `.env`.
4. Run:

```bash
npm install
npm start
```

5. Open `http://localhost:3000`.

## Production notes

- Put the app behind HTTPS.
- Use a strong JWT_SECRET.
- Use a reverse proxy such as Nginx.
- Move generated videos to object storage for larger deployments.
- Add a job queue (BullMQ/Redis) for many simultaneous users.
- Add email verification/password reset before public launch.
- Review the terms and licensing of any third-party TTS service you use.
- `ffmpeg-static` downloads a platform-specific FFmpeg binary during installation; keep dependencies updated.

## Free limits

Change these in `.env`:

```env
FREE_VIDEOS_PER_DAY=3
MAX_VIDEO_SECONDS=60
```

The daily count resets automatically based on the server date.

## API

- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/voices`
- `GET /api/videos`
- `POST /api/videos`
- `GET /api/videos/:id/download`
