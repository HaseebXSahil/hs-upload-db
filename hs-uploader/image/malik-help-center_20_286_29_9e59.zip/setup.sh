#!/bin/bash
# ============================================================
# Malik Help Center — One-Command Setup & Start Script
# ============================================================
# Usage:
#   chmod +x setup.sh
#   ./setup.sh
# ============================================================

set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

echo "🚀 Malik Help Center — Setup & Start"
echo "===================================="
echo ""

# ---------- 1. Check prerequisites ----------
echo "📦 Step 1: Checking prerequisites..."
if ! command -v node &> /dev/null; then
  echo "❌ Node.js is not installed. Please install Node.js 18+ first."
  exit 1
fi
if command -v bun &> /dev/null; then
  PKG_MGR="bun"
  echo "   ✅ Node.js: $(node --version) | Bun: $(bun --version)"
else
  PKG_MGR="npm"
  echo "   ✅ Node.js: $(node --version) | Using npm"
fi
echo ""

# ---------- 2. Create directories ----------
echo "📁 Step 2: Creating directories..."
mkdir -p db
mkdir -p public/uploads/avatars
mkdir -p public/uploads/media
# Create empty database file (db.ts will also do this as a safety net)
touch db/custom.db
echo "   ✅ Directories ready"
echo ""

# ---------- 3. Generate .env file ----------
echo "⚙️  Step 3: Generating .env file..."
# Note: db.ts auto-computes DATABASE_URL, so we don't set it here
# (avoids path issues across different operating systems)
cat > .env << 'EOF'
# ============================================================
# Malik Help Center — Configuration
# ============================================================

# ---- Admin Login ----
ADMIN_USERNAME=malik__mushahid
ADMIN_PASSWORD=khan@1373

# ---- Session Security ----
SESSION_SECRET=0ab42ae392830885859e67fc80b776189332f6b712766aa55ed05b618c4eacd6695f7603c8dfca183b9bf02cf03f156f

# ---- Public URL ----
PUBLIC_BASE_URL=http://localhost:3000
EOF
echo "   ✅ .env generated"
echo ""

# ---------- 4. Install main project dependencies ----------
echo "📥 Step 4: Installing main project dependencies..."
if [ "$PKG_MGR" = "bun" ]; then
  bun install
else
  npm install
fi
echo "   ✅ Dependencies installed"
echo ""

# ---------- 5. Create default avatar ----------
echo "🎨 Step 5: Creating default avatar..."
if [ ! -f public/uploads/avatars/default.webp ]; then
  if command -v python3 &> /dev/null; then
    python3 -c "
try:
    from PIL import Image, ImageDraw
    img = Image.new('RGB', (256, 256), color=(29, 78, 216))
    d = ImageDraw.Draw(img)
    d.ellipse([96, 60, 160, 124], fill=(255, 255, 255))
    d.ellipse([70, 140, 186, 220], fill=(255, 255, 255))
    img.save('public/uploads/avatars/default.webp', 'WEBP', quality=85)
    print('   ✅ Default avatar created')
except Exception:
    print('   ⚠️  Could not create default avatar (PIL not available)')
" 2>/dev/null
  fi
fi
touch public/uploads/avatars/.gitkeep
touch public/uploads/media/.gitkeep
echo ""

# ---------- 6. Initialize database schema ----------
echo "🗄️  Step 6: Initializing database schema..."
# Set DATABASE_URL explicitly for prisma CLI (it needs it)
DB_PATH="$PROJECT_DIR/db/custom.db"
export DATABASE_URL="file:$DB_PATH"
echo "   Using DATABASE_URL=$DATABASE_URL"

if [ "$PKG_MGR" = "bun" ]; then
  bunx prisma db push --accept-data-loss
  bunx prisma generate
else
  npx prisma db push --accept-data-loss
  npx prisma generate
fi
echo "   ✅ Database schema initialized"
echo ""

# ---------- 7. Install chat-service dependencies ----------
echo "🔌 Step 7: Installing chat-service dependencies..."
cd mini-services/chat-service
if [ "$PKG_MGR" = "bun" ]; then
  bun install
else
  npm install
fi
# Make sure prisma client is available in chat-service
mkdir -p node_modules
if [ -d "$PROJECT_DIR/node_modules/@prisma" ]; then
  rm -rf node_modules/@prisma 2>/dev/null
  cp -r "$PROJECT_DIR/node_modules/@prisma" node_modules/@prisma
fi
if [ -d "$PROJECT_DIR/node_modules/.prisma" ]; then
  rm -rf node_modules/.prisma 2>/dev/null
  cp -r "$PROJECT_DIR/node_modules/.prisma" node_modules/.prisma
fi
cd "$PROJECT_DIR"
echo "   ✅ Chat-service dependencies installed"
echo ""

# ---------- 8. Start chat-service ----------
echo "▶️  Step 8: Starting chat-service (port 3003)..."
pkill -f "bun.*chat-service/index" 2>/dev/null || true
pkill -f "tsx.*chat-service/index" 2>/dev/null || true
sleep 1

if [ "$PKG_MGR" = "bun" ]; then
  setsid -f bun mini-services/chat-service/index.ts > "$PROJECT_DIR/chat-service.log" 2>&1 < /dev/null
else
  setsid -f npx tsx mini-services/chat-service/index.ts > "$PROJECT_DIR/chat-service.log" 2>&1 < /dev/null
fi
sleep 3

if ss -tlnp 2>/dev/null | grep -q ":3003" || netstat -tlnp 2>/dev/null | grep -q ":3003"; then
  echo "   ✅ Chat-service is listening on port 3003"
else
  echo "   ⚠️  Chat-service may not have started. Check chat-service.log"
  cat chat-service.log 2>/dev/null | tail -10
fi
echo ""

# ---------- 9. Start Next.js dev server ----------
echo "▶️  Step 9: Starting Next.js dev server (port 3000)..."
echo ""
echo "===================================="
echo "🎉 Malik Help Center is starting!"
echo ""
echo "   📱 Frontend:  http://localhost:3000"
echo "   🔌 WebSocket: ws://localhost:3003"
echo ""
echo "   👑 Admin Username:    malik__mushahid"
echo "   🔑 Admin Password:    khan@1373"
echo ""
echo "   📋 Full credentials in ADMIN_CREDENTIALS.txt"
echo ""
echo "   Logs:"
echo "     - Frontend:     tail -f dev.log"
echo "     - Chat-service: tail -f chat-service.log"
echo ""
echo "   To stop: pkill -f 'next dev'; pkill -f 'bun.*chat-service'"
echo "===================================="
echo ""

if [ "$PKG_MGR" = "bun" ]; then
  bun run dev
else
  npm run dev
fi
