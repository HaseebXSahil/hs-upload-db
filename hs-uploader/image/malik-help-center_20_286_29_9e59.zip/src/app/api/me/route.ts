import { NextRequest, NextResponse } from 'next/server'
import { getUserFromToken } from '@/lib/auth'

export const runtime = 'nodejs'

export async function GET(req: NextRequest) {
  const auth = req.headers.get('authorization') || ''
  const token = auth.replace(/^Bearer\s+/i, '')
  const user = await getUserFromToken(token)
  if (!user) return NextResponse.json({ ok: false }, { status: 401 })
  return NextResponse.json({
    ok: true,
    user: {
      id: user.id,
      username: user.username,
      displayName: user.displayName,
      avatarUrl: user.avatarUrl,
      isAdmin: user.isAdmin,
      isVerified: user.isVerified,
      isMuted: user.isMuted,
      isBanned: user.isBanned,
      muteReason: user.muteReason,
      mutedUntil: user.mutedUntil,
      createdAt: user.createdAt,
    },
  })
}
