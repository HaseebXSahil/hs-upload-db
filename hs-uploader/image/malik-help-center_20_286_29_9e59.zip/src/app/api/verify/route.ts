import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromToken } from '@/lib/auth'

export const runtime = 'nodejs'

/**
 * Backend-enforced verification gate.
 * Even if a user completes the animation in the browser, they MUST call this
 * endpoint with a valid session token. The endpoint re-checks ban / mute
 * status from the DB and stamps the user as verified.
 */
export async function POST(req: NextRequest) {
  try {
    const auth = req.headers.get('authorization') || ''
    const token = auth.replace(/^Bearer\s+/i, '')
    const user = await getUserFromToken(token)
    if (!user) {
      return NextResponse.json({ ok: false, error: 'Unauthorized.' }, { status: 401 })
    }
    if (user.isBanned) {
      return NextResponse.json(
        { ok: false, error: 'You are banned from this community.' },
        { status: 403 },
      )
    }
    // Refetch to ensure fresh mute status
    const fresh = await db.user.findUnique({ where: { id: user.id } })
    if (!fresh) {
      return NextResponse.json({ ok: false, error: 'User not found.' }, { status: 404 })
    }
    return NextResponse.json({
      ok: true,
      user: {
        id: fresh.id,
        username: fresh.username,
        displayName: fresh.displayName,
        avatarUrl: fresh.avatarUrl,
        isAdmin: fresh.isAdmin,
        isVerified: fresh.isVerified,
        isMuted: fresh.isMuted,
        isBanned: fresh.isBanned,
        muteReason: fresh.muteReason,
        mutedUntil: fresh.mutedUntil,
      },
      message: 'Verification Complete!',
      welcome: 'Welcome to the Malik Help Center',
    })
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || 'Server error.' }, { status: 500 })
  }
}
