import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromToken } from '@/lib/auth'
import fs from 'fs/promises'
import path from 'path'
import crypto from 'crypto'

export const runtime = 'nodejs'

const MAX_SIZE = 25 * 1024 * 1024 // 25MB hard cap

const IMAGE_MIMES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']
const VIDEO_MIMES = ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime']
const AUDIO_MIMES = ['audio/webm', 'audio/ogg', 'audio/mp3', 'audio/wav', 'audio/mpeg', 'audio/aac', 'audio/mp4']
const DOC_MIMES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'text/plain',
  'text/csv',
  'application/zip',
]

const ALL_ALLOWED = [...IMAGE_MIMES, ...VIDEO_MIMES, ...AUDIO_MIMES, ...DOC_MIMES]

function classifyMime(mime: string): 'image' | 'video' | 'audio' | 'document' | 'unknown' {
  if (IMAGE_MIMES.includes(mime)) return 'image'
  if (VIDEO_MIMES.includes(mime)) return 'video'
  if (AUDIO_MIMES.includes(mime)) return 'audio'
  if (DOC_MIMES.includes(mime)) return 'document'
  return 'unknown'
}

export async function POST(req: NextRequest) {
  try {
    const auth = req.headers.get('authorization') || ''
    const token = auth.replace(/^Bearer\s+/i, '')
    const user = await getUserFromToken(token)
    if (!user) return NextResponse.json({ ok: false, error: 'Unauthorized.' }, { status: 401 })
    if (user.isBanned) return NextResponse.json({ ok: false, error: 'Banned.' }, { status: 403 })
    if (user.isMuted) {
      return NextResponse.json(
        { ok: false, error: 'You are muted and cannot upload media.', muted: true },
        { status: 403 },
      )
    }

    const formData = await req.formData()
    const file = formData.get('file') as File | null
    if (!file || !(file instanceof File) || file.size === 0) {
      return NextResponse.json({ ok: false, error: 'No file provided.' }, { status: 400 })
    }
    if (file.size > MAX_SIZE) {
      return NextResponse.json(
        { ok: false, error: `File too large. Max ${MAX_SIZE / 1024 / 1024}MB.` },
        { status: 400 },
      )
    }
    if (!ALL_ALLOWED.includes(file.type)) {
      return NextResponse.json(
        { ok: false, error: `File type "${file.type}" is not allowed.` },
        { status: 400 },
      )
    }

    const category = classifyMime(file.type)
    if (category === 'unknown') {
      return NextResponse.json({ ok: false, error: 'Unsupported file type.' }, { status: 400 })
    }

    // Save file under /public/uploads/media
    const buf = Buffer.from(await file.arrayBuffer())
    const hash = crypto.createHash('sha256').update(buf).digest('hex').slice(0, 12)
    const ext = (file.name.split('.').pop() || '').toLowerCase()
    const safeExt = ext.replace(/[^a-z0-9]/g, '').slice(0, 6) || 'bin'
    const fileName = `${category}-${Date.now()}-${hash}.${safeExt}`
    const relPath = `/uploads/media/${fileName}`
    const absPath = path.join(process.cwd(), 'public', 'uploads', 'media', fileName)
    await fs.mkdir(path.dirname(absPath), { recursive: true })
    await fs.writeFile(absPath, buf)

    // Record media asset
    await db.mediaAsset.create({
      data: {
        url: relPath,
        fileName: file.name,
        mimeType: file.type,
        size: file.size,
        uploadedBy: user.id,
      },
    })

    return NextResponse.json({
      ok: true,
      url: relPath,
      type: category,
      fileName: file.name,
      fileSize: file.size,
      mimeType: file.type,
    })
  } catch (e: any) {
    console.error('Upload error:', e)
    return NextResponse.json({ ok: false, error: e?.message || 'Server error.' }, { status: 500 })
  }
}
