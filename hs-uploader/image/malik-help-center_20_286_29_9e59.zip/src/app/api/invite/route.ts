import { NextRequest, NextResponse } from 'next/server'
import { PUBLIC_BASE_URL } from '@/lib/auth'

export const runtime = 'nodejs'

export async function GET() {
  // The invitation link is just the website root — anyone landing here must
  // complete the username + profile picture + verification flow before entering.
  const inviteUrl = `${PUBLIC_BASE_URL}/`
  return NextResponse.json({
    ok: true,
    inviteUrl,
    message: 'Share this link to invite new members. Every new visitor must pick a unique username and complete verification.',
  })
}
