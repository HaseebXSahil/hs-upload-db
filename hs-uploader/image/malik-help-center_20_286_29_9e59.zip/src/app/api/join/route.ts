import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import {
  ADMIN_USERNAME,
  createSession,
  isReservedAdminUsername,
  isValidUsername,
  normalizeUsername,
  verifyAdminPassword,
} from '@/lib/auth'
import sharp from 'sharp'
import crypto from 'crypto'

export const runtime = 'nodejs'

const MAX_AVATAR_BYTES = 5 * 1024 * 1024
const ALLOWED_AVATAR_MIME = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']

/**
 * Login/Join flow:
 * - Admin: must use username `malik__mushahid` + correct password.
 * - Users: just enter a unique username (no password). If they've logged out,
 *   they can log back in with the same username and we'll preserve their
 *   existing avatar and account.
 *
 * Request format (multipart/form-data):
 * - username: string
 * - avatar: File (required on first login; optional on subsequent logins if account exists)
 * - password?: string (required only for admin)
 */
export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData()
    const usernameRaw = (formData.get('username') as string) || ''
    const avatarFile = formData.get('avatar') as File | null
    const password = (formData.get('password') as string) || ''

    // 1. Validate username
    const valid = isValidUsername(usernameRaw)
    if (!valid.ok) {
      return NextResponse.json({ ok: false, error: valid.reason }, { status: 400 })
    }

    const norm = normalizeUsername(usernameRaw)
    const isAdminAttempt = isReservedAdminUsername(usernameRaw)

    // 2. Admin authentication
    if (isAdminAttempt) {
      if (!password || !verifyAdminPassword(password)) {
        return NextResponse.json(
          {
            ok: false,
            error: 'Admin login requires the correct password.',
            requiresAdminPassword: true,
          },
          { status: 403 },
        )
      }
    }

    // 3. Check if account already exists (so users can re-login after logout)
    const existing = await db.user.findFirst({
      where: { usernameNorm: norm },
    })

    let avatarRelPath: string | null = null

    // 4. If no existing account, avatar is REQUIRED
    if (!existing) {
      if (!avatarFile || !(avatarFile instanceof File) || avatarFile.size === 0) {
        return NextResponse.json({ ok: false, error: 'Profile picture is required.' }, { status: 400 })
      }
      if (avatarFile.size > MAX_AVATAR_BYTES) {
        return NextResponse.json({ ok: false, error: 'Profile picture must be under 5MB.' }, { status: 400 })
      }
      if (!ALLOWED_AVATAR_MIME.includes(avatarFile.type)) {
        return NextResponse.json(
          { ok: false, error: 'Profile picture must be a JPG, PNG, WEBP, or GIF.' },
          { status: 400 },
        )
      }
    }

    // 5. Process avatar (if a new one was uploaded)
    if (avatarFile && avatarFile instanceof File && avatarFile.size > 0) {
      if (avatarFile.size > MAX_AVATAR_BYTES) {
        return NextResponse.json({ ok: false, error: 'Profile picture must be under 5MB.' }, { status: 400 })
      }
      if (!ALLOWED_AVATAR_MIME.includes(avatarFile.type)) {
        return NextResponse.json(
          { ok: false, error: 'Profile picture must be a JPG, PNG, WEBP, or GIF.' },
          { status: 400 },
        )
      }
      const buffer = Buffer.from(await avatarFile.arrayBuffer())
      const processed = await sharp(buffer).resize(256, 256, { fit: 'cover' }).webp({ quality: 85 }).toBuffer()
      const avatarFileName = `avatar-${norm}-${Date.now()}.webp`
      avatarRelPath = `/uploads/avatars/${avatarFileName}`
      const avatarAbsPath = `${process.cwd()}/public${avatarRelPath}`
      const fs = await import('fs/promises')
      await fs.mkdir(`${process.cwd()}/public/uploads/avatars`, { recursive: true })
      await fs.writeFile(avatarAbsPath, processed)
    }

    // 6. Create or update user
    let user
    if (existing) {
      // Re-login: update avatar if provided, refresh isAdmin/isVerified for admin
      user = await db.user.update({
        where: { id: existing.id },
        data: {
          // Update avatar if a new one was uploaded
          ...(avatarRelPath ? { avatarUrl: avatarRelPath } : {}),
          // Make sure admin flag is set if this is the admin logging back in
          ...(isAdminAttempt ? { isAdmin: true, isVerified: true } : {}),
          // Clear ban if admin logs in (safety)
          ...(isAdminAttempt ? { isBanned: false } : {}),
        },
      })
    } else {
      user = await db.user.create({
        data: {
          username: usernameRaw.trim(),
          usernameNorm: norm,
          displayName: usernameRaw.trim(),
          avatarUrl: avatarRelPath || '/uploads/avatars/default.webp',
          isAdmin: isAdminAttempt,
          isVerified: isAdminAttempt,
        },
      })
    }

    // 7. Create session
    const ip = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || undefined
    const userAgent = req.headers.get('user-agent') || undefined
    const token = await createSession({ userId: user.id, ip, userAgent })

    // 8. Audit log if admin login
    if (isAdminAttempt) {
      await db.moderation.create({
        data: {
          targetUserId: user.id,
          adminId: user.id,
          action: 'admin_login',
          reason: 'Administrator authenticated with password.',
          active: false,
        },
      })
    }

    return NextResponse.json({
      ok: true,
      token,
      user: {
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        avatarUrl: user.avatarUrl,
        isAdmin: user.isAdmin,
        isVerified: user.isVerified,
      },
    })
  } catch (e: any) {
    console.error('Join error:', e)
    return NextResponse.json({ ok: false, error: e?.message || 'Server error.' }, { status: 500 })
  }
}
