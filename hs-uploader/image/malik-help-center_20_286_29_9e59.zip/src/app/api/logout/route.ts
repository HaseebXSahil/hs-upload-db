import { NextRequest, NextResponse } from 'next/server'
import { getUserFromToken, revokeSession } from '@/lib/auth'

export const runtime = 'nodejs'

export async function POST(req: NextRequest) {
  const auth = req.headers.get('authorization') || ''
  const token = auth.replace(/^Bearer\s+/i, '')
  if (token) await revokeSession(token)
  return NextResponse.json({ ok: true })
}
