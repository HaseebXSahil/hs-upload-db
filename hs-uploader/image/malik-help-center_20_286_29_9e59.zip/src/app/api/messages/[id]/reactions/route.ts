import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromToken } from '@/lib/auth'

export const runtime = 'nodejs'

const ALLOWED_EMOJIS = ['👍', '❤️', '😂', '🎉', '🔥', '😮', '😢', '🙏', '👏', '💯']

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = req.headers.get('authorization') || ''
    const token = auth.replace(/^Bearer\s+/i, '')
    const user = await getUserFromToken(token)
    if (!user) return NextResponse.json({ ok: false, error: 'Unauthorized.' }, { status: 401 })
    if (user.isBanned) return NextResponse.json({ ok: false, error: 'Banned.' }, { status: 403 })

    const { id } = await params
    const body = await req.json()
    const emoji: string = body.emoji
    if (!ALLOWED_EMOJIS.includes(emoji)) {
      return NextResponse.json({ ok: false, error: 'Emoji not allowed.' }, { status: 400 })
    }

    const msg = await db.message.findUnique({ where: { id } })
    if (!msg || msg.deleted) return NextResponse.json({ ok: false, error: 'Not found.' }, { status: 404 })

    let reactions: Record<string, string[]> = {}
    try {
      reactions = JSON.parse(msg.reactions || '{}')
    } catch {}

    const list = new Set(reactions[emoji] || [])
    if (list.has(user.id)) {
      list.delete(user.id)
    } else {
      list.add(user.id)
    }
    if (list.size === 0) {
      delete reactions[emoji]
    } else {
      reactions[emoji] = Array.from(list)
    }

    const updated = await db.message.update({
      where: { id },
      data: { reactions: JSON.stringify(reactions) },
    })
    return NextResponse.json({ ok: true, reactions })
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || 'Server error.' }, { status: 500 })
  }
}
