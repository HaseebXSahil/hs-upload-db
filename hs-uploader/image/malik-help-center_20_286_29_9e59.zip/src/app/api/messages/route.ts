import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { detectLinks, getUserFromToken } from '@/lib/auth'

export const runtime = 'nodejs'

const MAX_TEXT = 4000
const PAGE_SIZE = 50

/**
 * GET /api/messages?cursor=<iso>&limit=<n>
 * Returns recent messages (most recent first), paginated.
 */
export async function GET(req: NextRequest) {
  const auth = req.headers.get('authorization') || ''
  const token = auth.replace(/^Bearer\s+/i, '')
  const user = await getUserFromToken(token)
  if (!user) return NextResponse.json({ ok: false, error: 'Unauthorized.' }, { status: 401 })
  if (user.isBanned) return NextResponse.json({ ok: false, error: 'Banned.' }, { status: 403 })

  const { searchParams } = new URL(req.url)
  const cursor = searchParams.get('cursor')
  const limit = Math.min(parseInt(searchParams.get('limit') || `${PAGE_SIZE}`, 10), 100)
  const search = searchParams.get('q') || ''

  const where: any = {
    deleted: false,
    ...(search ? { content: { contains: search } } : {}),
  }
  if (cursor) {
    where.createdAt = { lt: new Date(cursor) }
  }

  const messages = await db.message.findMany({
    where,
    include: {
      sender: {
        select: {
          id: true,
          username: true,
          displayName: true,
          avatarUrl: true,
          isAdmin: true,
          isVerified: true,
        },
      },
      replyTo: {
        include: {
          sender: {
            select: { id: true, username: true, displayName: true, avatarUrl: true },
          },
        },
      },
    },
    orderBy: { createdAt: 'desc' },
    take: limit + 1,
  })

  let nextCursor: string | null = null
  if (messages.length > limit) {
    messages.pop()
    nextCursor = messages[messages.length - 1].createdAt.toISOString()
  }

  // Reverse so oldest is first when rendered
  return NextResponse.json({
    ok: true,
    messages: messages.reverse(),
    nextCursor,
  })
}

/**
 * POST /api/messages
 * Body: { content, type?, caption?, fileName?, fileSize?, mimeType?, duration?, replyToId? }
 *
 * ENFORCES link detection and auto-mute on the BACKEND.
 */
export async function POST(req: NextRequest) {
  try {
    const auth = req.headers.get('authorization') || ''
    const token = auth.replace(/^Bearer\s+/i, '')
    const user = await getUserFromToken(token)
    if (!user) return NextResponse.json({ ok: false, error: 'Unauthorized.' }, { status: 401 })
    if (user.isBanned) {
      return NextResponse.json({ ok: false, error: 'You are banned from this community.' }, { status: 403 })
    }
    if (user.isMuted) {
      // Check if mute has expired
      const stillMuted = !user.mutedUntil || user.mutedUntil.getTime() > Date.now()
      if (stillMuted) {
        return NextResponse.json(
          {
            ok: false,
            error:
              user.muteReason ||
              'You are currently muted and cannot send messages or media.',
            muted: true,
          },
          { status: 403 },
        )
      } else {
        // Auto-unmute expired
        await db.user.update({
          where: { id: user.id },
          data: { isMuted: false, muteReason: null, mutedUntil: null, mutedAt: null },
        })
      }
    }

    const body = await req.json()
    const type: string = body.type || 'text'
    const content: string = (body.content || '').toString().trim()

    if (type === 'text' || type === 'system') {
      if (!content) return NextResponse.json({ ok: false, error: 'Empty message.' }, { status: 400 })
      if (content.length > MAX_TEXT) {
        return NextResponse.json({ ok: false, error: 'Message too long.' }, { status: 400 })
      }
      // === AUTO LINK DETECTION & AUTO-MUTE ===
      const links = detectLinks(content)
      if (links && links.length > 0) {
        // 1. Auto-mute the user (persistent)
        await db.user.update({
          where: { id: user.id },
          data: {
            isMuted: true,
            muteReason:
              'Auto-muted: message contained a link. Link sharing is not allowed.',
            mutedAt: new Date(),
            // mutedUntil: null — remains muted until admin unmutates
          },
        })
        // 2. Record moderation event
        await db.moderation.create({
          data: {
            targetUserId: user.id,
            action: 'auto_mute',
            reason: `Auto-muted for sending a link: ${links[0]}`,
            active: true,
            metadata: JSON.stringify({ links, messageText: content }),
          },
        })
        // 3. Reject the message — it never appears in chat
        return NextResponse.json(
          {
            ok: false,
            error:
              'Your message contains a link. Link sharing is not allowed in this community. You have been temporarily muted.',
            muted: true,
            autoMuted: true,
          },
          { status: 403 },
        )
      }
    } else {
      // For media messages — content is the media URL; require caption optional
      if (!content) {
        return NextResponse.json({ ok: false, error: 'Media URL required.' }, { status: 400 })
      }
      // Make sure media URL points to our own uploads path (prevent external link injection)
      if (!content.startsWith('/uploads/media/')) {
        return NextResponse.json({ ok: false, error: 'Invalid media URL.' }, { status: 400 })
      }
    }

    const replyToId = body.replyToId || null

    const message = await db.message.create({
      data: {
        senderId: user.id,
        type,
        content,
        caption: body.caption || null,
        fileName: body.fileName || null,
        fileSize: body.fileSize || null,
        mimeType: body.mimeType || null,
        duration: body.duration || null,
        replyToId,
      },
      include: {
        sender: {
          select: {
            id: true,
            username: true,
            displayName: true,
            avatarUrl: true,
            isAdmin: true,
            isVerified: true,
          },
        },
        replyTo: {
          include: {
            sender: {
              select: { id: true, username: true, displayName: true, avatarUrl: true },
            },
          },
        },
      },
    })

    return NextResponse.json({ ok: true, message })
  } catch (e: any) {
    console.error('Message POST error:', e)
    return NextResponse.json({ ok: false, error: e?.message || 'Server error.' }, { status: 500 })
  }
}

/**
 * PATCH /api/messages — edit own message
 * Body: { id, content }
 */
export async function PATCH(req: NextRequest) {
  try {
    const auth = req.headers.get('authorization') || ''
    const token = auth.replace(/^Bearer\s+/i, '')
    const user = await getUserFromToken(token)
    if (!user) return NextResponse.json({ ok: false, error: 'Unauthorized.' }, { status: 401 })
    if (user.isBanned || user.isMuted) {
      return NextResponse.json({ ok: false, error: 'Cannot edit while muted or banned.' }, { status: 403 })
    }
    const body = await req.json()
    const { id, content } = body
    if (!id || !content) return NextResponse.json({ ok: false, error: 'Missing fields.' }, { status: 400 })
    const msg = await db.message.findUnique({ where: { id } })
    if (!msg || msg.deleted) return NextResponse.json({ ok: false, error: 'Not found.' }, { status: 404 })
    if (msg.senderId !== user.id) return NextResponse.json({ ok: false, error: 'Not your message.' }, { status: 403 })

    // Re-check links on edit too
    const links = detectLinks(content)
    if (links && links.length > 0) {
      await db.user.update({
        where: { id: user.id },
        data: {
          isMuted: true,
          muteReason: 'Auto-muted: edited message contained a link.',
          mutedAt: new Date(),
        },
      })
      await db.moderation.create({
        data: {
          targetUserId: user.id,
          action: 'auto_mute',
          reason: `Auto-muted for editing a link into message: ${links[0]}`,
          active: true,
        },
      })
      return NextResponse.json(
        {
          ok: false,
          error:
            'Your edited message contains a link. Link sharing is not allowed in this community. You have been temporarily muted.',
          muted: true,
        },
        { status: 403 },
      )
    }

    const updated = await db.message.update({
      where: { id },
      data: { content: content.toString().slice(0, MAX_TEXT), edited: true, editedAt: new Date() },
      include: {
        sender: {
          select: { id: true, username: true, displayName: true, avatarUrl: true, isAdmin: true, isVerified: true },
        },
      },
    })
    return NextResponse.json({ ok: true, message: updated })
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || 'Server error.' }, { status: 500 })
  }
}

/**
 * DELETE /api/messages?id=<id>
 * Sender can delete own message; admin can delete any.
 */
export async function DELETE(req: NextRequest) {
  try {
    const auth = req.headers.get('authorization') || ''
    const token = auth.replace(/^Bearer\s+/i, '')
    const user = await getUserFromToken(token)
    if (!user) return NextResponse.json({ ok: false, error: 'Unauthorized.' }, { status: 401 })

    const { searchParams } = new URL(req.url)
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ ok: false, error: 'Missing id.' }, { status: 400 })

    const msg = await db.message.findUnique({ where: { id } })
    if (!msg) return NextResponse.json({ ok: false, error: 'Not found.' }, { status: 404 })

    if (msg.senderId !== user.id && !user.isAdmin) {
      return NextResponse.json({ ok: false, error: 'Forbidden.' }, { status: 403 })
    }

    const updated = await db.message.update({
      where: { id },
      data: { deleted: true, deletedAt: new Date(), deletedBy: user.id },
    })
    return NextResponse.json({ ok: true, message: updated })
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || 'Server error.' }, { status: 500 })
  }
}
