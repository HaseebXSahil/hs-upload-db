import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromToken } from '@/lib/auth'

export const runtime = 'nodejs'

async function requireAdmin(req: NextRequest) {
  const auth = req.headers.get('authorization') || ''
  const token = auth.replace(/^Bearer\s+/i, '')
  const user = await getUserFromToken(token)
  if (!user || !user.isAdmin) return null
  return user
}

/**
 * GET /api/admin/reports?status=pending
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ ok: false, error: 'Admin only.' }, { status: 403 })

  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status') || 'pending'

  const reports = await db.report.findMany({
    where: status === 'all' ? {} : { status },
    orderBy: { createdAt: 'desc' },
    take: 200,
    include: {
      message: {
        include: {
          sender: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
        },
      },
      reporter: { select: { id: true, username: true, displayName: true } },
      targetUser: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
    },
  })
  return NextResponse.json({ ok: true, reports })
}

/**
 * PATCH /api/admin/reports
 * Body: { id, status: 'dismissed'|'actioned', deleteMessage?: boolean }
 */
export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ ok: false, error: 'Admin only.' }, { status: 403 })

  const body = await req.json()
  const { id, status, deleteMessage } = body
  if (!id || !['dismissed', 'actioned'].includes(status)) {
    return NextResponse.json({ ok: false, error: 'Invalid payload.' }, { status: 400 })
  }
  const report = await db.report.findUnique({ where: { id } })
  if (!report) return NextResponse.json({ ok: false, error: 'Not found.' }, { status: 404 })

  await db.report.update({
    where: { id },
    data: { status, reviewedBy: admin.id, reviewedAt: new Date() },
  })
  if (deleteMessage && report.messageId) {
    await db.message.update({
      where: { id: report.messageId },
      data: { deleted: true, deletedAt: new Date(), deletedBy: admin.id },
    })
  }
  return NextResponse.json({ ok: true })
}
