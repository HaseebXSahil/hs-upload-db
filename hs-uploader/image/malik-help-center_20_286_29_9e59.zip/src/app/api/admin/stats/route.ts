import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromToken } from '@/lib/auth'

export const runtime = 'nodejs'

async function requireAdmin(req: NextRequest) {
  const auth = req.headers.get('authorization') || ''
  const token = auth.replace(/^Bearer\s+/i, '')
  const user = await getUserFromToken(token)
  if (!user || !user.isAdmin) return null
  return user
}

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ ok: false, error: 'Admin only.' }, { status: 403 })

  const since = new Date(Date.now() - 5 * 60 * 1000) // online = seen in last 5 min
  const [totalMembers, onlineMembers, totalMessages, reportedMessages, mutedMembers, bannedMembers, recentActions] =
    await Promise.all([
      db.user.count(),
      db.user.count({ where: { lastSeenAt: { gte: since }, isBanned: false } }),
      db.message.count({ where: { deleted: false } }),
      db.report.count({ where: { status: 'pending' } }),
      db.user.count({ where: { isMuted: true } }),
      db.user.count({ where: { isBanned: true } }),
      db.moderation.findMany({
        orderBy: { createdAt: 'desc' },
        take: 20,
        include: {
          targetUser: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
        },
      }),
    ])

  return NextResponse.json({
    ok: true,
    stats: {
      totalMembers,
      onlineMembers,
      totalMessages,
      reportedMessages,
      mutedMembers,
      bannedMembers,
    },
    recentActions,
  })
}
