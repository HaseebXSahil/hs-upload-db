import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromToken } from '@/lib/auth'

export const runtime = 'nodejs'

async function requireAdmin(req: NextRequest) {
  const auth = req.headers.get('authorization') || ''
  const token = auth.replace(/^Bearer\s+/i, '')
  const user = await getUserFromToken(token)
  if (!user || !user.isAdmin) return null
  return user
}

/**
 * GET /api/admin/members?q=&page=&pageSize=
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ ok: false, error: 'Admin only.' }, { status: 403 })

  const { searchParams } = new URL(req.url)
  const q = searchParams.get('q') || ''
  const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10))
  const pageSize = Math.min(100, parseInt(searchParams.get('pageSize') || '50', 10))

  const where = q
    ? {
        OR: [
          { username: { contains: q } },
          { usernameNorm: { contains: q.toLowerCase() } },
          { displayName: { contains: q } },
        ],
      }
    : {}

  const [total, members] = await Promise.all([
    db.user.count({ where }),
    db.user.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
      select: {
        id: true,
        username: true,
        displayName: true,
        avatarUrl: true,
        isAdmin: true,
        isVerified: true,
        isMuted: true,
        isBanned: true,
        muteReason: true,
        mutedAt: true,
        mutedUntil: true,
        lastSeenAt: true,
        createdAt: true,
      },
    }),
  ])

  return NextResponse.json({ ok: true, members, total, page, pageSize })
}

/**
 * POST /api/admin/members
 * Body: { userId, action: 'mute'|'unmute'|'ban'|'unban'|'remove', reason }
 */
export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ ok: false, error: 'Admin only.' }, { status: 403 })

  const body = await req.json()
  const { userId, action, reason } = body
  if (!userId || !action) return NextResponse.json({ ok: false, error: 'Missing fields.' }, { status: 400 })

  const target = await db.user.findUnique({ where: { id: userId } })
  if (!target) return NextResponse.json({ ok: false, error: 'User not found.' }, { status: 404 })
  if (target.isAdmin) {
    return NextResponse.json({ ok: false, error: 'Cannot moderate an administrator.' }, { status: 403 })
  }

  const safeReason = (reason || '').toString().slice(0, 500)

  switch (action) {
    case 'mute': {
      await db.user.update({
        where: { id: userId },
        data: {
          isMuted: true,
          muteReason: safeReason || 'Muted by administrator.',
          mutedAt: new Date(),
          mutedUntil: null,
        },
      })
      await db.moderation.create({
        data: { targetUserId: userId, adminId: admin.id, action: 'mute', reason: safeReason, active: true },
      })
      return NextResponse.json({ ok: true })
    }
    case 'unmute': {
      await db.user.update({
        where: { id: userId },
        data: { isMuted: false, muteReason: null, mutedAt: null, mutedUntil: null },
      })
      await db.moderation.create({
        data: { targetUserId: userId, adminId: admin.id, action: 'unmute', reason: safeReason || 'Unmuted by admin.', active: false },
      })
      await db.moderation.updateMany({
        where: { targetUserId: userId, action: { in: ['mute', 'auto_mute'] }, active: true },
        data: { active: false },
      })
      return NextResponse.json({ ok: true })
    }
    case 'ban': {
      await db.user.update({ where: { id: userId }, data: { isBanned: true } })
      await db.session.updateMany({ where: { userId }, data: { revoked: true } })
      await db.moderation.create({
        data: { targetUserId: userId, adminId: admin.id, action: 'ban', reason: safeReason, active: true },
      })
      return NextResponse.json({ ok: true })
    }
    case 'unban': {
      await db.user.update({ where: { id: userId }, data: { isBanned: false } })
      await db.moderation.create({
        data: { targetUserId: userId, adminId: admin.id, action: 'unban', reason: safeReason, active: false },
      })
      return NextResponse.json({ ok: true })
    }
    case 'remove': {
      await db.user.update({ where: { id: userId }, data: { isBanned: true } })
      await db.session.updateMany({ where: { userId }, data: { revoked: true } })
      await db.moderation.create({
        data: { targetUserId: userId, adminId: admin.id, action: 'remove', reason: safeReason, active: true },
      })
      return NextResponse.json({ ok: true })
    }
    default:
      return NextResponse.json({ ok: false, error: 'Unknown action.' }, { status: 400 })
  }
}
