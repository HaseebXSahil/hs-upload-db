import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromToken } from '@/lib/auth'

export const runtime = 'nodejs'

async function requireAdmin(req: NextRequest) {
  const auth = req.headers.get('authorization') || ''
  const token = auth.replace(/^Bearer\s+/i, '')
  const user = await getUserFromToken(token)
  if (!user || !user.isAdmin) return null
  return user
}

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ ok: false, error: 'Admin only.' }, { status: 403 })

  const actions = await db.moderation.findMany({
    orderBy: { createdAt: 'desc' },
    take: 200,
    include: {
      targetUser: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
      admin: { select: { id: true, username: true, displayName: true } },
    },
  })
  return NextResponse.json({ ok: true, actions })
}
