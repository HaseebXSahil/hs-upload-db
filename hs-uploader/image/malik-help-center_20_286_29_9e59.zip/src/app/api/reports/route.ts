import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserFromToken } from '@/lib/auth'

export const runtime = 'nodejs'

const REASONS = [
  'spam',
  'harassment',
  'threats_bullying',
  'hate_abuse',
  'explicit_content',
  'illegal_content',
  'malicious_file',
  'impersonation',
  'disruptive_behavior',
  'other',
]

export async function POST(req: NextRequest) {
  try {
    const auth = req.headers.get('authorization') || ''
    const token = auth.replace(/^Bearer\s+/i, '')
    const user = await getUserFromToken(token)
    if (!user) return NextResponse.json({ ok: false, error: 'Unauthorized.' }, { status: 401 })

    const body = await req.json()
    const { messageId, reason, details } = body
    if (!messageId || !reason) {
      return NextResponse.json({ ok: false, error: 'Missing fields.' }, { status: 400 })
    }
    if (!REASONS.includes(reason)) {
      return NextResponse.json({ ok: false, error: 'Invalid reason.' }, { status: 400 })
    }
    const msg = await db.message.findUnique({ where: { id: messageId } })
    if (!msg) return NextResponse.json({ ok: false, error: 'Message not found.' }, { status: 404 })

    // Prevent spam reporting the same message
    const existing = await db.report.findFirst({
      where: { messageId, reporterId: user.id },
    })
    if (existing) {
      return NextResponse.json({ ok: false, error: 'You have already reported this message.' }, { status: 409 })
    }

    const report = await db.report.create({
      data: {
        messageId,
        reporterId: user.id,
        targetUserId: msg.senderId,
        reason: `${reason}${details ? ': ' + String(details).slice(0, 500) : ''}`,
        status: 'pending',
      },
    })
    return NextResponse.json({ ok: true, report })
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || 'Server error.' }, { status: 500 })
  }
}
