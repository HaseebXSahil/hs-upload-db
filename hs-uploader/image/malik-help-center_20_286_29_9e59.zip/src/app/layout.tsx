import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Malik Help Center — Premium Community Chat",
  description:
    "Malik Help Center — a premium, secure, real-time community chat with voice, video, image & document sharing. Verified admin, anti-spam protection, and admin moderation.",
  keywords: [
    "Malik Help Center",
    "community chat",
    "real-time chat",
    "voice messages",
    "group chat",
  ],
  authors: [{ name: "Malik Help Center" }],
  openGraph: {
    title: "Malik Help Center",
    description: "Premium real-time community chat with admin verification & moderation.",
    siteName: "Malik Help Center",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Malik Help Center",
    description: "Premium real-time community chat.",
  },
};

export const viewport: Viewport = {
  themeColor: "#060a1c",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased text-foreground min-h-screen`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
