'use client'

import { useEffect, useState } from 'react'
import { WelcomeScreen } from '@/components/WelcomeScreen'
import { ChatInterface } from '@/components/ChatInterface'
import { api, getToken } from '@/lib/api-client'
import { Loader2 } from 'lucide-react'

type Stage = 'loading' | 'welcome' | 'chat'

export default function Home() {
  const [stage, setStage] = useState<Stage>('loading')

  useEffect(() => {
    ;(async () => {
      const token = getToken()
      if (!token) {
        setStage('welcome')
        return
      }
      try {
        const d = await api<{ user: any }>('/api/me')
        if (d?.user && !d.user.isBanned) {
          setStage('chat')
        } else {
          setStage('welcome')
        }
      } catch {
        setStage('welcome')
      }
    })()
  }, [])

  if (stage === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-blue-200">
          <Loader2 className="animate-spin" size={32} />
          <div className="text-sm">Loading Malik Help Center…</div>
        </div>
      </div>
    )
  }

  if (stage === 'welcome') {
    return <WelcomeScreen onAuthenticated={() => setStage('chat')} />
  }

  return <ChatInterface onLogout={() => setStage('welcome')} />
}
