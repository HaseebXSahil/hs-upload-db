/**
 * Lightweight client-side helpers for calling the MHC API.
 */

export function getToken(): string | null {
  if (typeof window === 'undefined') return null
  return localStorage.getItem('mhc_token')
}

export function setToken(token: string | null) {
  if (typeof window === 'undefined') return
  if (token) localStorage.setItem('mhc_token', token)
  else localStorage.removeItem('mhc_token')
}

export async function api<T = any>(
  path: string,
  opts: RequestInit = {},
): Promise<T> {
  const token = getToken()
  const headers: Record<string, string> = {
    ...(opts.headers as Record<string, string> | undefined),
  }
  if (token) headers['Authorization'] = `Bearer ${token}`
  if (opts.body && !(opts.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json'
  }
  const res = await fetch(path, { ...opts, headers })
  let data: any = null
  try {
    data = await res.json()
  } catch {
    /* ignore */
  }
  if (!res.ok) {
    const msg = data?.error || `Request failed (${res.status})`
    const err = new Error(msg) as any
    err.status = res.status
    err.data = data
    throw err
  }
  return data as T
}
