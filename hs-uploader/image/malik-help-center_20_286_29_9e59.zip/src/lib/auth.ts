import { db } from './db'
import crypto from 'crypto'

export const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'malik__mushahid'
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'khan@1373'
export const SESSION_SECRET = process.env.SESSION_SECRET || 'malik-help-center-default-secret'
export const PUBLIC_BASE_URL = process.env.PUBLIC_BASE_URL || 'http://localhost:3000'

export const SESSION_COOKIE = 'mhc_session'
export const SESSION_TTL_DAYS = 30

/**
 * Normalize a username for de-duplication.
 */
export function normalizeUsername(raw: string): string {
  if (!raw) return ''
  return raw
    .normalize('NFKC')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '_')
    .replace(/[^a-z0-9_]/g, '')
}

export function isValidUsername(raw: string): { ok: boolean; reason?: string } {
  const norm = normalizeUsername(raw)
  if (!norm) return { ok: false, reason: 'Username is required.' }
  if (norm.length < 3) return { ok: false, reason: 'Username must be at least 3 characters.' }
  if (norm.length > 24) return { ok: false, reason: 'Username must be at most 24 characters.' }
  if (!/^[a-z0-9_]+$/.test(norm)) return { ok: false, reason: 'Only letters, numbers and underscore are allowed.' }
  return { ok: true }
}

export function isReservedAdminUsername(raw: string): boolean {
  return normalizeUsername(raw) === normalizeUsername(ADMIN_USERNAME)
}

/**
 * Constant-time password comparison.
 */
export function verifyAdminPassword(password: string): boolean {
  if (!password) return false
  const a = Buffer.from(password, 'utf8')
  const b = Buffer.from(ADMIN_PASSWORD, 'utf8')
  if (a.length !== b.length) return false
  return crypto.timingSafeEqual(a, b)
}

export function createSessionToken(): string {
  return crypto.randomBytes(32).toString('hex')
}

export function hashToken(token: string): string {
  return crypto.createHmac('sha256', SESSION_SECRET).update(token).digest('hex')
}

export async function createSession(opts: {
  userId: string
  ip?: string
  userAgent?: string
}): Promise<string> {
  const token = createSessionToken()
  const expiresAt = new Date(Date.now() + SESSION_TTL_DAYS * 24 * 60 * 60 * 1000)
  await db.session.create({
    data: {
      token: hashToken(token),
      userId: opts.userId,
      ip: opts.ip,
      userAgent: opts.userAgent,
      expiresAt,
    },
  })
  return token
}

export async function getUserFromToken(token?: string | null) {
  if (!token) return null
  const session = await db.session.findUnique({
    where: { token: hashToken(token) },
    include: { user: true },
  })
  if (!session) return null
  if (session.revoked) return null
  if (session.expiresAt.getTime() < Date.now()) return null
  // touch lastSeenAt
  await db.user.update({
    where: { id: session.userId },
    data: { lastSeenAt: new Date() },
  }).catch(() => {})
  return session.user
}

export async function revokeSession(token: string) {
  try {
    await db.session.update({
      where: { token: hashToken(token) },
      data: { revoked: true },
    })
  } catch {}
}

/**
 * Auto link detection — comprehensive.
 */
export function detectLinks(text: string): string[] | null {
  if (!text) return null
  const TLDS = new Set([
    'com','net','org','io','co','ai','app','dev','xyz','me','info','biz','tv','cc','ws',
    'us','uk','ca','au','de','fr','jp','ru','br','in','pk','ie','nz','za','mx','it','es',
    'nl','se','no','fi','dk','ch','at','be','pl','gr','pt','cz','kr','cn','tw','hk','sg',
    'my','ph','th','vn','id','sa','ae','eg','ng','ke','tr','il','ir','ar','cl','pe','ve',
    'ec','uy','py','bo','cr','gt','do','sv','hn','ni','pa','ag','aw','bs','bb','bm','bq',
    'cw','dm','gd','gp','mq','kn','lc','mf','ms','sx','tc','vc','vg','vi','ly','sh','to',
    'gg','pr','is','sk','hu','ro','bg','hr','si','lt','lv','ee','ua','by','md','ge','am',
  ])
  const isTld = (s: string) => TLDS.has(s.toLowerCase())

  const matches: string[] = []

  const proto = /(?:h\s*t\s*t\s*p\s*s?\s*:\s*\/\s*\/\s*|ftp\s*:\s*\/\s*\/\s*)[^\s<>"']+/gi
  const pm = text.match(proto)
  if (pm) matches.push(...pm)

  const www = /\bwww\.[a-z0-9-]+(?:\.[a-z0-9-]+)+[^\s<>"']*/gi
  const wm = text.match(www)
  if (wm) matches.push(...wm)

  const bare = /\b([a-z0-9-]+)\.([a-z]{2,})(?:\.[a-z]{2,})?(?:\/[^\s<>"']*)?/gi
  let bm
  while ((bm = bare.exec(text)) !== null) {
    const tld = bm[2].toLowerCase()
    if (isTld(tld)) matches.push(bm[0])
  }

  const email = /\b[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}\b/gi
  const em = text.match(email)
  if (em) matches.push(...em)

  const short = /\b(?:bit\.ly|t\.co|tinyurl\.com|goo\.gl|ow\.ly|is\.gd|buff\.ly|rebrand\.ly|cutt\.ly)\b[^\s]*/gi
  const sm = text.match(short)
  if (sm) matches.push(...sm)

  const msg = /\b(?:t\.me|telegram\.me|discord\.gg|discord\.com\/invite|wa\.me|chat\.whatsapp\.com)\b[^\s]*/gi
  const mm = text.match(msg)
  if (mm) matches.push(...mm)

  const ip = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?::\d+)?(?:\/[^\s<>"']*)?/g
  const im = text.match(ip)
  if (im) matches.push(...im)

  const dot = /\b[a-z0-9-]+\s*(?:\(?dot\)?)\s*[a-z]{2,}\b/gi
  const dm = text.match(dot)
  if (dm) matches.push(...dm)

  return matches.length ? matches : null
}

export function formatBytes(bytes?: number | null): string {
  if (!bytes) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`
}

export function formatDuration(seconds?: number | null): string {
  if (!seconds || isNaN(seconds)) return '0:00'
  const m = Math.floor(seconds / 60)
  const s = Math.floor(seconds % 60)
  return `${m}:${s.toString().padStart(2, '0')}`
}
