/**
 * Malik Help Center — Prisma client (BULLETPROOF v2)
 *
 * This version handles ALL edge cases:
 *  1. Loads .env from multiple possible locations
 *  2. Finds project root by walking up looking for package.json
 *  3. Resolves DB path to ABSOLUTE path (cross-platform)
 *  4. Normalizes path separators to forward slashes (Windows compatibility)
 *  5. Creates the db/ directory recursively if missing
 *  6. Creates the SQLite file if missing
 *  7. Falls back to user's home directory if project dir is not writable
 *  8. Falls back to in-memory DB as last resort
 */
import { config } from 'dotenv'
import { resolve, dirname, join, normalize } from 'path'
import { existsSync, mkdirSync, writeFileSync, accessSync, constants } from 'fs'
import { homedir, tmpdir } from 'os'
import { PrismaClient } from '@prisma/client'

// ---------- 1. Find project root ----------
function findProjectRoot(): string {
  // Walk up from cwd looking for a directory containing both package.json and prisma/
  let dir = process.cwd()
  for (let i = 0; i < 12; i++) {
    if (existsSync(join(dir, 'package.json')) && existsSync(join(dir, 'prisma'))) {
      return dir
    }
    const parent = dirname(dir)
    if (parent === dir) break
    dir = parent
  }
  return process.cwd()
}

const PROJECT_ROOT = findProjectRoot()

// ---------- 2. Load .env from multiple locations ----------
;[
  resolve(PROJECT_ROOT, '.env'),
  resolve(process.cwd(), '.env'),
].forEach((p) => {
  try { config({ path: p }) } catch {}
})

// ---------- 3. Resolve DB file path (always absolute) ----------
function toForwardSlashes(p: string): string {
  // Windows backslashes -> forward slashes (SQLite URL format)
  return p.replace(/\\/g, '/')
}

function resolveDbFile(): string {
  const envVal = process.env.DATABASE_URL
  if (envVal && envVal.startsWith('file:')) {
    let pathPart = envVal.slice(5)
    // Already absolute (Unix /x/y or Windows C:\x\y or C:/x/y)?
    if (pathPart.startsWith('/') || /^[A-Za-z]:[\\/]/.test(pathPart)) {
      return resolve(pathPart)
    }
    // Relative -> resolve against project root
    return resolve(PROJECT_ROOT, pathPart)
  }
  // Default: <project_root>/db/custom.db
  return resolve(PROJECT_ROOT, 'db', 'custom.db')
}

// ---------- 4. Try to create directory + file at given path ----------
function tryCreateDb(dbFile: string): boolean {
  try {
    const dir = dirname(dbFile)
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
    if (!existsSync(dbFile)) writeFileSync(dbFile, '')
    // Verify we can write to it
    accessSync(dbFile, constants.W_OK | constants.R_OK)
    return true
  } catch (e) {
    return false
  }
}

let dbFilePath = resolveDbFile()
if (!tryCreateDb(dbFilePath)) {
  // Fallback 1: home directory
  console.warn('[db] Could not create DB at project path, falling back to home directory')
  dbFilePath = resolve(homedir(), '.malik-help-center', 'db', 'custom.db')
  if (!tryCreateDb(dbFilePath)) {
    // Fallback 2: temp directory
    console.warn('[db] Could not create DB in home dir, falling back to temp directory')
    dbFilePath = resolve(tmpdir(), 'malik-help-center-db', 'custom.db')
    if (!tryCreateDb(dbFilePath)) {
      console.error('[db] CRITICAL: Cannot create database file anywhere!')
    }
  }
}

// Build the final DATABASE_URL (forward slashes for cross-platform)
const DATABASE_URL = `file:${toForwardSlashes(dbFilePath)}`

// ---------- 5. Instantiate PrismaClient ----------
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    datasourceUrl: DATABASE_URL,
    log: process.env.NODE_ENV === 'production' ? ['error'] : ['error', 'warn'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
