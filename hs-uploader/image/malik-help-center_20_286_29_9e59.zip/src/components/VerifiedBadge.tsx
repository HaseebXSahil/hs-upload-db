import React from 'react'

/**
 * Genuine blue verification badge — canonical Twitter/X-style checkmark SVG.
 * Uses a scalloped star burst background with a centered checkmark.
 */
export function VerifiedBadge({ size = 16, className = '' }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 22 22"
      className={className}
      aria-label="Verified administrator"
      role="img"
      style={{
        filter: 'drop-shadow(0 0 3px rgba(29, 155, 240, 0.6))',
        flexShrink: 0,
      }}
    >
      <linearGradient id="mhc-verified-grad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#1d9bf0" />
        <stop offset="100%" stopColor="#0c7abf" />
      </linearGradient>
      <path
        fill="url(#mhc-verified-grad)"
        d="M20.396 11c-.018-.646-.215-1.275-.57-1.816-.354-.54-.852-.972-1.438-1.246.223-.607.26-1.264.106-1.895-.15-.632-.46-1.21-.895-1.66-.436-.45-.978-.737-1.567-.83-.588-.094-1.197-.04-1.756.156-.255-.6-.674-1.105-1.218-1.444-.544-.34-1.183-.497-1.83-.45-.647.047-1.255.294-1.74.71-.486.416-.826.974-.978 1.6-.6.05-1.166.31-1.61.745-.444.436-.744 1.008-.86 1.634-.117.626-.044 1.275.21 1.856-.56.27-1.025.7-1.34 1.235-.313.535-.46 1.15-.426 1.77.035.62.252 1.214.623 1.71.37.495.878.872 1.46 1.08-.223.607-.26 1.264-.106 1.895.15.632.46 1.21.895 1.66.436.45.978.737 1.567.83.588.094 1.197.04 1.756-.156.255.6.674 1.105 1.218 1.444.544.34 1.183.497 1.83.45.647-.047 1.255-.294 1.74-.71.486-.416.826-.974.978-1.6.6-.05 1.166-.31 1.61-.745.444-.436.744-1.008.86-1.634.117-.626.044-1.275-.21-1.856.56-.27 1.025-.7 1.34-1.235.313-.535.46-1.15.426-1.77z"
      />
      <path
        fill="#fff"
        d="M9.8 14.7L7 11.9l1.4-1.4 1.4 1.4 3.6-3.6 1.4 1.4z"
      />
    </svg>
  )
}
