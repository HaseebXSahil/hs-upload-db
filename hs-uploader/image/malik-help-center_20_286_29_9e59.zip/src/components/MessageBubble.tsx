'use client'

import React, { useState } from 'react'
import { VerifiedBadge } from './VerifiedBadge'
import { AudioPlayer } from './AudioPlayer'
import {
  Copy,
  Edit3,
  Trash2,
  Reply,
  MoreVertical,
  Flag,
  Download,
  FileText,
  Check,
  X,
} from 'lucide-react'

export type ChatMessage = {
  id: string
  senderId: string
  type: string
  content: string
  caption?: string | null
  fileName?: string | null
  fileSize?: number | null
  mimeType?: string | null
  duration?: number | null
  replyToId?: string | null
  replyTo?: any
  edited: boolean
  editedAt?: string | null
  deleted: boolean
  deletedBy?: string | null
  reactions: string
  createdAt: string
  sender: {
    id: string
    username: string
    displayName: string
    avatarUrl: string
    isAdmin: boolean
    isVerified: boolean
  }
}

const ALLOWED_REACTIONS = ['👍', '❤️', '😂', '🎉', '🔥', '😮', '😢', '🙏']

export function MessageBubble(props: {
  msg: ChatMessage
  isMe: boolean
  currentUserId: string
  onReply: (m: ChatMessage) => void
  onEdit: (m: ChatMessage, text: string) => void
  onDelete: (m: ChatMessage) => void
  onReact: (m: ChatMessage, emoji: string) => void
  onReport: (m: ChatMessage) => void
  onPreviewMedia: (m: ChatMessage) => void
}) {
  const { msg, isMe } = props
  const [menuOpen, setMenuOpen] = useState(false)
  const [editing, setEditing] = useState(false)
  const [editText, setEditText] = useState(msg.content)
  const [copied, setCopied] = useState(false)
  const [showReactions, setShowReactions] = useState(false)

  if (msg.deleted) {
    return (
      <div className={`flex ${isMe ? 'justify-end' : 'justify-start'} my-1`}>
        <div className="px-4 py-2 rounded-2xl bg-white/5 border border-white/5 text-blue-300/50 italic text-sm">
          🚫 This message was removed.
        </div>
      </div>
    )
  }

  const reactions: Record<string, string[]> = (() => {
    try { return JSON.parse(msg.reactions || '{}') } catch { return {} }
  })()

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(msg.content)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {}
    setMenuOpen(false)
  }

  const submitEdit = () => {
    if (!editText.trim()) return
    props.onEdit(msg, editText.trim())
    setEditing(false)
    setMenuOpen(false)
  }

  const time = new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })

  return (
    <div className={`group flex gap-2 sm:gap-3 my-1.5 mhc-msg-enter ${isMe ? 'flex-row-reverse' : 'flex-row'}`}>
      {/* Avatar */}
      { }
      <img
        src={msg.sender.avatarUrl}
        alt={msg.sender.displayName}
        className="w-9 h-9 rounded-full object-cover border border-blue-400/20 shrink-0 mt-0.5"
      />

      <div className={`max-w-[78%] sm:max-w-[68%] ${isMe ? 'items-end' : 'items-start'} flex flex-col`}>
        {/* Sender name */}
        <div className={`flex items-center gap-1.5 text-xs mb-1 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}>
          <span className="font-semibold text-blue-100">
            {msg.sender.displayName}
          </span>
          {msg.sender.isAdmin && msg.sender.isVerified && <VerifiedBadge size={14} />}
          <span className="text-blue-300/50">·</span>
          <span className="text-blue-300/50 tabular-nums">{time}</span>
          {msg.edited && <span className="text-blue-300/40 text-[10px] italic">edited</span>}
        </div>

        {/* Reply preview */}
        {msg.replyTo && !msg.replyTo.deleted && (
          <div className={`mb-1 px-2.5 py-1 rounded-lg bg-white/5 border-l-2 border-blue-400/50 text-xs ${isMe ? 'self-end' : 'self-start'}`}>
            <div className="font-semibold text-blue-300">{msg.replyTo.sender?.displayName}</div>
            <div className="text-blue-200/70 truncate max-w-[200px]">
              {msg.replyTo.type === 'text' ? msg.replyTo.content : `[${msg.replyTo.type}]`}
            </div>
          </div>
        )}

        {/* Bubble */}
        <div
          className={`relative rounded-2xl px-3.5 py-2.5 shadow ${
            isMe
              ? 'bg-gradient-to-br from-blue-600/80 to-blue-700/70 text-white rounded-tr-md'
              : 'mhc-glass text-blue-50 rounded-tl-md'
          }`}
        >
          {editing && msg.type === 'text' ? (
            <div className="space-y-2 min-w-[200px]">
              <textarea
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                rows={2}
                className="w-full bg-black/30 border border-white/20 rounded-lg px-2 py-1.5 text-sm text-white focus:outline-none"
                autoFocus
              />
              <div className="flex gap-2 justify-end">
                <button
                  onClick={() => { setEditing(false); setEditText(msg.content) }}
                  className="p-1.5 rounded bg-white/10 hover:bg-white/20"
                >
                  <X size={14} />
                </button>
                <button
                  onClick={submitEdit}
                  className="p-1.5 rounded bg-emerald-500/80 hover:bg-emerald-500"
                >
                  <Check size={14} />
                </button>
              </div>
            </div>
          ) : (
            <MessageContent msg={msg} onPreviewMedia={props.onPreviewMedia} />
          )}

          {/* Hover actions */}
          <div
            className={`absolute -top-2 ${isMe ? 'left-0' : 'right-0'} flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity`}
          >
            <button
              type="button"
              onClick={() => setShowReactions((s) => !s)}
              className="p-1 rounded-full bg-blue-900/80 border border-blue-400/30 text-blue-200 hover:bg-blue-800"
              title="Add reaction"
            >
              <span className="text-xs">😊</span>
            </button>
            <button
              type="button"
              onClick={() => setMenuOpen((o) => !o)}
              className="p-1 rounded-full bg-blue-900/80 border border-blue-400/30 text-blue-200 hover:bg-blue-800"
              title="More"
            >
              <MoreVertical size={12} />
            </button>
          </div>

          {/* Reactions popup */}
          {showReactions && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowReactions(false)} />
              <div className={`absolute -top-9 ${isMe ? 'left-2' : 'right-2'} flex gap-0.5 p-1 rounded-full mhc-glass-strong shadow-xl z-20`}>
                {ALLOWED_REACTIONS.map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={(e) => { e.stopPropagation(); props.onReact(msg, emoji); setShowReactions(false) }}
                    className="w-7 h-7 hover:bg-white/10 rounded-full flex items-center justify-center"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </>
          )}

          {/* Menu */}
          {menuOpen && (
            <>
              {/* click-away catcher */}
              <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
              <div
                className={`absolute z-20 top-2 ${isMe ? 'left-full ml-1' : 'right-full mr-1'} mhc-glass-strong rounded-xl p-1 shadow-2xl min-w-[160px]`}
              >
                <MenuItem icon={<Reply size={13} />} label="Reply" onClick={() => { props.onReply(msg); setMenuOpen(false) }} />
                {msg.type === 'text' && (
                  <MenuItem icon={copied ? <Check size={13} /> : <Copy size={13} />} label={copied ? 'Copied' : 'Copy'} onClick={copy} />
                )}
                {isMe && msg.type === 'text' && (
                  <MenuItem icon={<Edit3 size={13} />} label="Edit" onClick={() => { setEditing(true); setMenuOpen(false) }} />
                )}
                {isMe && (
                  <MenuItem icon={<Trash2 size={13} />} label="Delete" onClick={() => { props.onDelete(msg); setMenuOpen(false) }} danger />
                )}
                {!isMe && (
                  <MenuItem icon={<Flag size={13} />} label="Report" onClick={() => { props.onReport(msg); setMenuOpen(false) }} danger />
                )}
              </div>
            </>
          )}
        </div>

        {/* Reactions display */}
        {Object.keys(reactions).length > 0 && (
          <div className={`flex gap-1 flex-wrap mt-1 ${isMe ? 'justify-end' : 'justify-start'}`}>
            {Object.entries(reactions).map(([emoji, uids]) => (
              <button
                key={emoji}
                onClick={() => props.onReact(msg, emoji)}
                className={`text-xs px-1.5 py-0.5 rounded-full border ${
                  uids.includes(props.currentUserId)
                    ? 'bg-blue-500/30 border-blue-400/50'
                    : 'bg-white/5 border-white/10'
                }`}
              >
                {emoji} {uids.length}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function MenuItem({ icon, label, onClick, danger }: any) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs hover:bg-white/10 ${
        danger ? 'text-red-300' : 'text-blue-100'
      }`}
    >
      {icon} <span>{label}</span>
    </button>
  )
}

function MessageContent({ msg, onPreviewMedia }: { msg: ChatMessage; onPreviewMedia: (m: ChatMessage) => void }) {
  if (msg.type === 'text' || msg.type === 'system') {
    return <div className="text-sm whitespace-pre-wrap break-words">{msg.content}</div>
  }
  if (msg.type === 'image') {
    return (
      <div className="space-y-1">
        <button onClick={() => onPreviewMedia(msg)} className="block">
          { }
          <img
            src={msg.content}
            alt={msg.caption || msg.fileName || 'image'}
            className="rounded-xl max-w-full max-h-80 object-cover border border-white/10"
          />
        </button>
        {msg.caption && <div className="text-xs text-blue-100">{msg.caption}</div>}
        <a href={msg.content} download className="inline-flex items-center gap-1 text-[11px] text-blue-300 hover:text-blue-200">
          <Download size={11} /> Download
        </a>
      </div>
    )
  }
  if (msg.type === 'video') {
    return (
      <div className="space-y-1">
        <video src={msg.content} controls className="rounded-xl max-w-full max-h-80 border border-white/10" preload="metadata" />
        {msg.caption && <div className="text-xs text-blue-100">{msg.caption}</div>}
        <a href={msg.content} download className="inline-flex items-center gap-1 text-[11px] text-blue-300 hover:text-blue-200">
          <Download size={11} /> Download
        </a>
      </div>
    )
  }
  if (msg.type === 'audio') {
    return (
      <div className="space-y-1">
        <AudioPlayer src={msg.content} duration={msg.duration} senderName={msg.sender.displayName} />
        {msg.caption && <div className="text-xs text-blue-100">{msg.caption}</div>}
      </div>
    )
  }
  if (msg.type === 'document') {
    return (
      <a
        href={msg.content}
        download={msg.fileName || undefined}
        className="flex items-center gap-3 p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 min-w-[220px]"
      >
        <div className="w-10 h-10 rounded-lg mhc-gradient-btn flex items-center justify-center text-white shrink-0">
          <FileText size={18} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium text-blue-50 truncate">{msg.fileName || 'Document'}</div>
          <div className="text-[11px] text-blue-300/70">
            {msg.mimeType} · {formatBytes(msg.fileSize)}
          </div>
        </div>
        <Download size={16} className="text-blue-300 shrink-0" />
      </a>
    )
  }
  return <div className="text-sm">{msg.content}</div>
}

function formatBytes(bytes?: number | null): string {
  if (!bytes) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`
}
