'use client'

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Shield, Ban, AlertTriangle, Gavel } from 'lucide-react'

const RULES = [
  { icon: '🚫', title: 'No Spam', body: 'Repetitive, irrelevant, or unsolicited messages are prohibited. This includes chain messages and unsolicited promotion.' },
  { icon: '👊', title: 'No Harassment', body: 'Personal attacks, targeted insults, and persistent unwanted contact will not be tolerated.' },
  { icon: '⚠️', title: 'No Threats or Bullying', body: 'Threats of violence, intimidation, or bullying of any kind lead to immediate removal.' },
  { icon: '⚖️', title: 'No Hate or Abuse', body: 'Hate speech, slurs, or abusive content targeting any group or individual is forbidden.' },
  { icon: '🔞', title: 'No Explicit Adult Content', body: 'Adult, pornographic, or otherwise explicit content is strictly prohibited.' },
  { icon: '🚔', title: 'No Illegal Content', body: 'Content that violates applicable laws — including copyrighted material shared without permission — is not allowed.' },
  { icon: '🦠', title: 'No Malicious Files', body: 'Uploading malware, phishing links, or any file designed to harm other members is forbidden.' },
  { icon: '🎭', title: 'No Impersonation', body: 'Pretending to be another person, especially the admin or a verified member, is forbidden.' },
  { icon: '🔁', title: 'No Repeated Disruption', body: 'Repeated disruptive behavior — including circumventing restrictions — will result in a ban.' },
  { icon: '🔗', title: 'No Link Sharing', body: 'Sending URLs (http, https, www, bare domains, telegram/discord invites, etc.) is automatically blocked and the sender is auto-muted until an admin reviews.' },
]

export function GuidelinesDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="mhc-glass-strong border-blue-400/30 text-blue-50 max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-blue-100 text-xl">
            <Shield className="text-emerald-400" /> Community Guidelines
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3 max-h-[70vh] overflow-y-auto mhc-no-scrollbar pr-1">
          <p className="text-sm text-blue-200/80">
            Malik Help Center is a premium community. To keep it safe and welcoming, all members must follow these rules.
          </p>
          {RULES.map((r) => (
            <div key={r.title} className="flex gap-3 p-3 rounded-xl bg-white/5 border border-white/10">
              <div className="text-2xl">{r.icon}</div>
              <div>
                <div className="font-semibold text-blue-100">{r.title}</div>
                <div className="text-sm text-blue-200/70">{r.body}</div>
              </div>
            </div>
          ))}
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30">
            <div className="flex items-center gap-2 font-semibold text-red-200">
              <Gavel size={16} /> Enforcement
            </div>
            <p className="text-sm text-red-200/80 mt-1">
              Violations are enforced on the backend. Restrictions persist across sessions and devices. Only the authorized administrator can lift restrictions.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
