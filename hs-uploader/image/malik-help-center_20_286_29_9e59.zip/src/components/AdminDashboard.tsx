'use client'

import { useEffect, useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { api } from '@/lib/api-client'
import { VerifiedBadge } from './VerifiedBadge'
import {
  Search,
  ShieldBan,
  VolumeX,
  Volume2,
  Ban,
  UserX,
  Trash2,
  Flag,
  Loader2,
  Users,
  MessageSquare,
  AlertTriangle,
  Activity,
} from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

type Member = {
  id: string
  username: string
  displayName: string
  avatarUrl: string
  isAdmin: boolean
  isVerified: boolean
  isMuted: boolean
  isBanned: boolean
  muteReason: string | null
  mutedAt: string | null
  mutedUntil: string | null
  lastSeenAt: string
  createdAt: string
}

type Stats = {
  totalMembers: number
  onlineMembers: number
  totalMessages: number
  reportedMessages: number
  mutedMembers: number
  bannedMembers: number
}

type Report = {
  id: string
  reason: string
  status: string
  createdAt: string
  message: any
  reporter: any
  targetUser: any
}

type Action = {
  id: string
  action: string
  reason: string
  active: boolean
  createdAt: string
  targetUser: any
  admin?: any
}

export function AdminDashboard({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const [tab, setTab] = useState<'stats' | 'members' | 'reports' | 'history'>('stats')
  const [stats, setStats] = useState<Stats | null>(null)
  const [members, setMembers] = useState<Member[]>([])
  const [reports, setReports] = useState<Report[]>([])
  const [actions, setActions] = useState<Action[]>([])
  const [q, setQ] = useState('')
  const [loading, setLoading] = useState(false)
  const [busy, setBusy] = useState<string | null>(null)

  const refresh = async () => {
    setLoading(true)
    try {
      if (tab === 'stats') {
        const d = await api('/api/admin/stats')
        setStats(d.stats)
        setActions(d.recentActions || [])
      } else if (tab === 'members') {
        const d = await api(`/api/admin/members?q=${encodeURIComponent(q)}`)
        setMembers(d.members)
      } else if (tab === 'reports') {
        const d = await api('/api/admin/reports?status=pending')
        setReports(d.reports)
      } else if (tab === 'history') {
        const d = await api('/api/admin/history')
        setActions(d.actions)
      }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (open) refresh()
     
  }, [open, tab, q])

  const act = async (userId: string, action: string, reason = '') => {
    setBusy(userId + action)
    try {
      await api('/api/admin/members', {
        method: 'POST',
        body: JSON.stringify({ userId, action, reason }),
      })
      await refresh()
    } catch (e: any) {
      alert(e.message)
    } finally {
      setBusy(null)
    }
  }

  const review = async (reportId: string, status: 'dismissed' | 'actioned', deleteMessage?: boolean) => {
    setBusy(reportId + status)
    try {
      await api('/api/admin/reports', {
        method: 'PATCH',
        body: JSON.stringify({ id: reportId, status, deleteMessage }),
      })
      await refresh()
    } catch (e: any) {
      alert(e.message)
    } finally {
      setBusy(null)
    }
  }

  const deleteMessage = async (msgId: string) => {
    if (!confirm('Delete this message?')) return
    setBusy(msgId + 'del')
    try {
      await api(`/api/messages?id=${msgId}`, { method: 'DELETE' })
    } catch (e: any) {
      alert(e.message)
    } finally {
      setBusy(null)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="mhc-glass-strong border-blue-400/30 text-blue-50 max-w-5xl h-[88vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-blue-100">
            <ShieldBan className="text-emerald-400" /> Admin Moderation Dashboard
          </DialogTitle>
        </DialogHeader>

        {/* Tabs */}
        <div className="flex gap-1 p-1 rounded-xl bg-white/5 border border-white/10">
          {[
            { id: 'stats', label: 'Stats', icon: Activity },
            { id: 'members', label: 'Members', icon: Users },
            { id: 'reports', label: 'Reports', icon: Flag },
            { id: 'history', label: 'History', icon: AlertTriangle },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id as any)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-sm transition-colors ${
                tab === t.id ? 'mhc-gradient-btn text-white' : 'text-blue-200/70 hover:bg-white/5'
              }`}
            >
              <t.icon size={14} /> <span className="hidden sm:inline">{t.label}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto mhc-no-scrollbar pr-1">
          {loading ? (
            <div className="flex items-center justify-center h-32 text-blue-300">
              <Loader2 className="animate-spin" />
            </div>
          ) : tab === 'stats' ? (
            <StatsPanel stats={stats} actions={actions} />
          ) : tab === 'members' ? (
            <MembersPanel
              q={q}
              setQ={setQ}
              members={members}
              busy={busy}
              act={act}
            />
          ) : tab === 'reports' ? (
            <ReportsPanel reports={reports} busy={busy} review={review} deleteMessage={deleteMessage} />
          ) : (
            <HistoryPanel actions={actions} />
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}

function StatCard({ icon: Icon, label, value, color }: any) {
  return (
    <div className="mhc-glass rounded-2xl p-4 border border-blue-400/15">
      <div className="flex items-center justify-between">
        <div className="text-xs uppercase tracking-wider text-blue-300/70">{label}</div>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <div className="text-2xl font-bold text-blue-50 mt-2">{value}</div>
    </div>
  )
}

function StatsPanel({ stats, actions }: { stats: Stats | null; actions: Action[] }) {
  if (!stats) return null
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <StatCard icon={Users} label="Total Members" value={stats.totalMembers} color="text-blue-400" />
        <StatCard icon={Activity} label="Online Now" value={stats.onlineMembers} color="text-emerald-400" />
        <StatCard icon={MessageSquare} label="Total Messages" value={stats.totalMessages} color="text-blue-400" />
        <StatCard icon={Flag} label="Pending Reports" value={stats.reportedMessages} color="text-amber-400" />
        <StatCard icon={VolumeX} label="Muted Members" value={stats.mutedMembers} color="text-orange-400" />
        <StatCard icon={Ban} label="Banned Members" value={stats.bannedMembers} color="text-red-400" />
      </div>

      <div>
        <h3 className="text-sm font-semibold text-blue-200/80 mb-2">Recent Moderation Actions</h3>
        <div className="space-y-2">
          {actions.length === 0 ? (
            <div className="text-sm text-blue-300/60 italic p-4 text-center bg-white/5 rounded-xl">No actions yet.</div>
          ) : (
            actions.map((a) => <ActionRow key={a.id} a={a} />)
          )}
        </div>
      </div>
    </div>
  )
}

function ActionRow({ a }: { a: Action }) {
  const color =
    a.action === 'auto_mute' ? 'text-orange-300 bg-orange-500/15' :
    a.action === 'mute' ? 'text-orange-300 bg-orange-500/15' :
    a.action === 'unmute' ? 'text-emerald-300 bg-emerald-500/15' :
    a.action === 'ban' || a.action === 'remove' ? 'text-red-300 bg-red-500/15' :
    a.action === 'unban' ? 'text-emerald-300 bg-emerald-500/15' :
    'text-blue-300 bg-blue-500/15'
  return (
    <div className="flex items-center gap-3 p-2.5 rounded-xl bg-white/5 border border-white/10">
      <Badge className={`${color} border-0`}>{a.action}</Badge>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium text-blue-100 truncate">{a.targetUser?.displayName}</div>
        <div className="text-xs text-blue-300/70 truncate">{a.reason}</div>
      </div>
      <div className="text-xs text-blue-300/50">
        {formatDistanceToNow(new Date(a.createdAt), { addSuffix: true })}
      </div>
    </div>
  )
}

function MembersPanel({ q, setQ, members, busy, act }: any) {
  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300/70" size={16} />
        <Input
          placeholder="Search by username…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="pl-9 bg-white/5 border-blue-400/20 text-blue-100"
        />
      </div>
      <div className="space-y-2">
        {members.map((m: Member) => (
          <div key={m.id} className="flex items-center gap-3 p-2.5 rounded-xl bg-white/5 border border-white/10">
            { }
            <img src={m.avatarUrl} alt={m.displayName} className="w-9 h-9 rounded-full object-cover" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-medium text-blue-100 truncate">{m.displayName}</span>
                {m.isAdmin && m.isVerified && <VerifiedBadge size={12} />}
                {m.isMuted && <Badge className="bg-orange-500/20 text-orange-200 border-0">Muted</Badge>}
                {m.isBanned && <Badge className="bg-red-500/20 text-red-200 border-0">Banned</Badge>}
              </div>
              <div className="text-xs text-blue-300/60">
                @{m.username} · last seen {formatDistanceToNow(new Date(m.lastSeenAt), { addSuffix: true })}
              </div>
              {m.muteReason && <div className="text-[11px] text-orange-300/80 truncate">{m.muteReason}</div>}
            </div>
            {!m.isAdmin && (
              <div className="flex gap-1">
                {m.isMuted ? (
                  <Button size="sm" variant="ghost" disabled={busy === m.id + 'unmute'} onClick={() => act(m.id, 'unmute')} title="Unmute">
                    <Volume2 size={14} />
                  </Button>
                ) : (
                  <Button size="sm" variant="ghost" disabled={busy === m.id + 'mute'} onClick={() => act(m.id, 'mute', 'Muted by admin')} title="Mute">
                    <VolumeX size={14} />
                  </Button>
                )}
                {m.isBanned ? (
                  <Button size="sm" variant="ghost" disabled={busy === m.id + 'unban'} onClick={() => act(m.id, 'unban')} title="Unban">
                    Unban
                  </Button>
                ) : (
                  <Button size="sm" variant="ghost" disabled={busy === m.id + 'ban'} onClick={() => act(m.id, 'ban', 'Banned by admin')} title="Ban">
                    <Ban size={14} />
                  </Button>
                )}
                <Button size="sm" variant="ghost" disabled={busy === m.id + 'remove'} onClick={() => act(m.id, 'remove', 'Removed by admin')} title="Remove">
                  <UserX size={14} />
                </Button>
              </div>
            )}
          </div>
        ))}
        {members.length === 0 && <div className="text-center text-blue-300/60 py-8 text-sm">No members found.</div>}
      </div>
    </div>
  )
}

function ReportsPanel({ reports, busy, review, deleteMessage }: any) {
  if (reports.length === 0) return <div className="text-center text-blue-300/60 py-8 text-sm">No pending reports. 🎉</div>
  return (
    <div className="space-y-3">
      {reports.map((r: Report) => (
        <div key={r.id} className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-xs text-blue-300/70">
              Reported by <span className="text-blue-200">{r.reporter?.displayName}</span> · {formatDistanceToNow(new Date(r.createdAt), { addSuffix: true })}
            </div>
            <Badge className="bg-amber-500/20 text-amber-200 border-0">{r.reason.split(':')[0]}</Badge>
          </div>
          {r.message && !r.message.deleted && (
            <div className="p-2 rounded-lg bg-black/20 text-sm text-blue-100">
              <div className="text-xs text-blue-300/70 mb-1">{r.message.sender?.displayName}:</div>
              <div className="truncate">{r.message.type === 'text' ? r.message.content : `[${r.message.type}]`}</div>
            </div>
          )}
          <div className="text-xs text-blue-300/80">{r.reason}</div>
          <div className="flex gap-2 flex-wrap">
            <Button size="sm" variant="ghost" disabled={busy === r.id + 'dismissed'} onClick={() => review(r.id, 'dismissed')}>
              Dismiss
            </Button>
            <Button size="sm" variant="ghost" disabled={busy === r.id + 'actioned'} onClick={() => review(r.id, 'actioned', false)}>
              Mark Actioned
            </Button>
            <Button size="sm" variant="ghost" disabled={busy === r.id + 'actioned'} onClick={() => review(r.id, 'actioned', true)}>
              <Trash2 size={12} className="mr-1" /> Delete & Action
            </Button>
            {r.message && !r.message.deleted && (
              <Button size="sm" variant="ghost" disabled={busy === r.message.id + 'del'} onClick={() => deleteMessage(r.message.id)}>
                <Trash2 size={12} className="mr-1" /> Delete Message
              </Button>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}

function HistoryPanel({ actions }: { actions: Action[] }) {
  if (actions.length === 0) return <div className="text-center text-blue-300/60 py-8 text-sm">No moderation history yet.</div>
  return (
    <div className="space-y-2">
      {actions.map((a) => <ActionRow key={a.id} a={a} />)}
    </div>
  )
}
