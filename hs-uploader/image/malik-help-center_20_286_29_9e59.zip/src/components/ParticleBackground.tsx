'use client'

import { useMemo } from 'react'

export function ParticleBackground({ count = 28 }: { count?: number }) {
  const particles = useMemo(() => {
    return Array.from({ length: count }, (_, i) => {
      const size = Math.random() * 6 + 2
      const left = Math.random() * 100
      const duration = Math.random() * 18 + 12
      const delay = Math.random() * -duration
      const opacity = Math.random() * 0.5 + 0.2
      const hue = Math.random() > 0.5 ? 'rgba(96,165,250,1)' : 'rgba(52,211,153,1)'
      return { id: i, size, left, duration, delay, opacity, hue }
    })
  }, [count])
  return (
    <div className="mhc-particles" aria-hidden="true">
      {particles.map((p) => (
        <span
          key={p.id}
          className="mhc-particle"
          style={{
            left: `${p.left}%`,
            width: `${p.size}px`,
            height: `${p.size}px`,
            animationDuration: `${p.duration}s`,
            animationDelay: `${p.delay}s`,
            opacity: p.opacity,
            background: `radial-gradient(circle, ${p.hue} 0%, transparent 70%)`,
          }}
        />
      ))}
    </div>
  )
}
