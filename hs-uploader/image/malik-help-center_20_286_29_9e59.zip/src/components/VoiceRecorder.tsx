'use client'

import { useEffect, useRef, useState } from 'react'
import { Mic, Square, Send, Trash2, Loader2 } from 'lucide-react'
import { api } from '@/lib/api-client'

/**
 * Voice recorder with live waveform and preview.
 * On confirm: uploads the file and calls onSend with the resulting media info.
 */
export function VoiceRecorder({ onSend, disabled }: { onSend: (info: any) => void; disabled?: boolean }) {
  const [state, setState] = useState<'idle' | 'recording' | 'preview' | 'uploading'>('idle')
  const [seconds, setSeconds] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [levels, setLevels] = useState<number[]>(Array(40).fill(0.05))
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const streamRef = useRef<MediaStream | null>(null)
  const intervalRef = useRef<any>(null)
  const audioCtxRef = useRef<AudioContext | null>(null)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const rafRef = useRef<number | null>(null)

  function stopStream() {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop())
      streamRef.current = null
    }
  }

  useEffect(() => {
    return () => {
      stopStream()
      if (intervalRef.current) clearInterval(intervalRef.current)
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      if (previewUrl) URL.revokeObjectURL(previewUrl)
    }
  }, [])

  async function startRecording() {
    setError(null)
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      streamRef.current = stream
      const mr = new MediaRecorder(stream)
      chunksRef.current = []
      mr.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data)
      }
      mr.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mr.mimeType || 'audio/webm' })
        const url = URL.createObjectURL(blob)
        setPreviewUrl(url)
        setState('preview')
        stopStream()
      }
      mr.start()
      mediaRecorderRef.current = mr
      setState('recording')
      setSeconds(0)

      // Waveform analyser
      const ctx = new AudioContext()
      const src = ctx.createMediaStreamSource(stream)
      const analyser = ctx.createAnalyser()
      analyser.fftSize = 64
      src.connect(analyser)
      audioCtxRef.current = ctx
      analyserRef.current = analyser
      const data = new Uint8Array(analyser.frequencyBinCount)
      const tick = () => {
        analyser.getByteFrequencyData(data)
        const next: number[] = []
        for (let i = 0; i < 40; i++) {
          const idx = Math.floor((i / 40) * data.length)
          next.push(Math.max(0.05, (data[idx] || 0) / 255))
        }
        setLevels((prev) => [...prev.slice(1), ...next].slice(-40))
        rafRef.current = requestAnimationFrame(tick)
      }
      tick()

      intervalRef.current = setInterval(() => {
        setSeconds((s) => s + 1)
      }, 1000)
    } catch (e: any) {
      setError(
        e?.name === 'NotAllowedError'
          ? 'Microphone access denied. Please allow microphone permission in your browser settings.'
          : 'Could not start recording. ' + (e?.message || ''),
      )
      stopStream()
    }
  }

  function stopRecording() {
    if (intervalRef.current) clearInterval(intervalRef.current)
    if (rafRef.current) cancelAnimationFrame(rafRef.current)
    if (audioCtxRef.current) audioCtxRef.current.close().catch(() => {})
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop()
    }
  }

  function cancelPreview() {
    if (previewUrl) URL.revokeObjectURL(previewUrl)
    setPreviewUrl(null)
    setState('idle')
    setSeconds(0)
    setLevels(Array(40).fill(0.05))
  }

  async function confirmSend() {
    if (!previewUrl) return
    setState('uploading')
    try {
      const blob = await fetch(previewUrl).then((r) => r.blob())
      const fd = new FormData()
      const ext = blob.type.includes('webm') ? 'webm' : blob.type.includes('mp4') ? 'm4a' : 'webm'
      fd.append('file', blob, `voice-${Date.now()}.${ext}`)
      const res = await api<{ ok: boolean; url: string; duration?: number }>('/api/upload', {
        method: 'POST',
        body: fd,
      })
      onSend({
        url: res.url,
        type: 'audio',
        fileName: `Voice message`,
        fileSize: blob.size,
        mimeType: blob.type,
        duration: seconds,
      })
      cancelPreview()
    } catch (e: any) {
      setError(e?.message || 'Upload failed.')
      setState('preview')
    }
  }

  if (state === 'idle') {
    return (
      <div>
        <button
          type="button"
          onClick={startRecording}
          disabled={disabled}
          title="Record voice message"
          className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-blue-200 border border-blue-400/20 disabled:opacity-50 transition-colors"
        >
          <Mic size={18} />
        </button>
        {error && <p className="text-xs text-red-300 mt-2 max-w-[220px]">{error}</p>}
      </div>
    )
  }

  if (state === 'recording') {
    return (
      <div className="flex items-center gap-3 px-3 py-2 rounded-xl bg-red-500/15 border border-red-400/30">
        <span className="w-2.5 h-2.5 rounded-full bg-red-400 animate-pulse" />
        <div className="flex items-end gap-0.5 h-6 flex-1">
          {levels.map((lv, i) => (
            <div
              key={i}
              className="flex-1 rounded-full bg-gradient-to-t from-red-400 to-orange-300"
              style={{ height: `${Math.max(8, lv * 100)}%`, transition: 'height 0.08s' }}
            />
          ))}
        </div>
        <span className="text-xs text-red-200 tabular-nums">
          {Math.floor(seconds / 60)}:{(seconds % 60).toString().padStart(2, '0')}
        </span>
        <button
          type="button"
          onClick={stopRecording}
          title="Stop recording"
          className="p-2 rounded-lg bg-red-500 hover:bg-red-600 text-white"
        >
          <Square size={14} />
        </button>
      </div>
    )
  }

  if (state === 'preview') {
    return (
      <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-500/10 border border-emerald-400/30">
        <audio src={previewUrl || undefined} controls className="h-8 flex-1 min-w-0" style={{ maxWidth: '100%' }} />
        <button
          type="button"
          onClick={cancelPreview}
          title="Discard"
          className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-red-300"
        >
          <Trash2 size={16} />
        </button>
        <button
          type="button"
          onClick={confirmSend}
          title="Send voice message"
          className="p-2 rounded-lg mhc-gradient-btn text-white"
        >
          <Send size={16} />
        </button>
      </div>
    )
  }

  // uploading
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 border border-blue-400/20 text-blue-200 text-sm">
      <Loader2 className="animate-spin" size={16} /> Uploading voice…
    </div>
  )
}
