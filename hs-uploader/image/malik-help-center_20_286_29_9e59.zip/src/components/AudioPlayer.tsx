'use client'

import { useEffect, useRef, useState } from 'react'
import { Play, Pause, Download } from 'lucide-react'

function formatDuration(seconds?: number | null): string {
  if (!seconds || isNaN(seconds)) return '0:00'
  const m = Math.floor(seconds / 60)
  const s = Math.floor(seconds % 60)
  return `${m}:${s.toString().padStart(2, '0')}`
}

export function AudioPlayer({ src, duration }: { src: string; duration?: number; senderName?: string }) {
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const [playing, setPlaying] = useState(false)
  const [progress, setProgress] = useState(0)
  const [dur, setDur] = useState(duration || 0)
  const [cur, setCur] = useState(0)

  useEffect(() => {
    const a = audioRef.current
    if (!a) return
    const onLoaded = () => {
      if (!isNaN(a.duration) && a.duration > 0) setDur(a.duration)
    }
    const onTime = () => {
      setCur(a.currentTime)
      if (a.duration > 0) setProgress(a.currentTime / a.duration)
    }
    const onEnd = () => {
      setPlaying(false)
      setProgress(0)
      setCur(0)
    }
    a.addEventListener('loadedmetadata', onLoaded)
    a.addEventListener('timeupdate', onTime)
    a.addEventListener('ended', onEnd)
    return () => {
      a.removeEventListener('loadedmetadata', onLoaded)
      a.removeEventListener('timeupdate', onTime)
      a.removeEventListener('ended', onEnd)
    }
  }, [])

  const toggle = () => {
    const a = audioRef.current
    if (!a) return
    if (playing) {
      a.pause()
      setPlaying(false)
    } else {
      a.play()
      setPlaying(true)
    }
  }

  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    const a = audioRef.current
    if (!a || !a.duration) return
    const rect = e.currentTarget.getBoundingClientRect()
    const ratio = (e.clientX - rect.left) / rect.width
    a.currentTime = ratio * a.duration
  }

  const bars = Array.from({ length: 36 }, (_, i) => {
    const seed = (src.charCodeAt(i % src.length) * (i + 1)) % 100
    return 0.2 + (seed / 100) * 0.8
  })

  return (
    <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/5 border border-blue-400/15 min-w-[220px] max-w-[320px]">
      <audio ref={audioRef} src={src} preload="metadata" />
      <button
        type="button"
        onClick={toggle}
        className="w-10 h-10 rounded-full mhc-gradient-btn text-white flex items-center justify-center shrink-0 shadow"
        aria-label={playing ? 'Pause' : 'Play'}
      >
        {playing ? <Pause size={16} /> : <Play size={16} className="ml-0.5" />}
      </button>
      <div className="flex-1 min-w-0">
        <div
          className="relative h-8 flex items-end gap-[2px] cursor-pointer"
          onClick={seek}
          title="Click to seek"
        >
          {bars.map((b, i) => {
            const filled = i / bars.length <= progress
            const bg = filled
              ? 'linear-gradient(180deg, #60a5fa, #34d399)'
              : 'rgba(147, 164, 214, 0.25)'
            return (
              <div
                key={i}
                data-i={i}
                className="flex-1 rounded-full"
                style={{
                  height: `${Math.max(15, b * 100)}%`,
                  minHeight: '3px',
                  background: bg,
                  transition: 'height 0.18s, background 0.18s',
                }}
              />
            )
          })}
        </div>
        <div className="flex items-center justify-between mt-1 text-[10px] text-blue-300/70 tabular-nums">
          <span>{formatDuration(cur)}</span>
          <span>{formatDuration(dur)}</span>
        </div>
      </div>
      <a
        href={src}
        download={`voice-${Date.now()}.webm`}
        className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-blue-200 shrink-0"
        title="Download voice message"
      >
        <Download size={14} />
      </a>
    </div>
  )
}
