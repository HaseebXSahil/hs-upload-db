'use client'

import { Dialog, DialogContent } from '@/components/ui/dialog'
import { Download, X } from 'lucide-react'

export function MediaPreviewWindow({
  msg,
  onClose,
}: {
  msg: any
  onClose: () => void
}) {
  if (!msg) return null
  return (
    <Dialog open={!!msg} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-4xl p-0 mhc-glass-strong border-blue-400/30 overflow-hidden">
        <div className="relative">
          <button
            onClick={onClose}
            className="absolute top-3 right-3 z-10 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white"
          >
            <X size={18} />
          </button>
          {msg.type === 'image' && (
             
            <img src={msg.content} alt={msg.fileName || 'image'} className="w-full max-h-[80vh] object-contain" />
          )}
          {msg.type === 'video' && (
            <video src={msg.content} controls autoPlay className="w-full max-h-[80vh]" />
          )}
          <div className="p-4 flex items-center justify-between text-sm text-blue-100">
            <div className="min-w-0">
              <div className="font-medium truncate">{msg.caption || msg.fileName || 'Media'}</div>
              <div className="text-xs text-blue-300/70">
                {msg.sender?.displayName} · {new Date(msg.createdAt).toLocaleString()}
              </div>
            </div>
            <a
              href={msg.content}
              download={msg.fileName || undefined}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg mhc-gradient-btn text-white text-xs"
            >
              <Download size={14} /> Download
            </a>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
