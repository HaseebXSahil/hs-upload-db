'use client'

import { useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { api } from '@/lib/api-client'
import { Loader2 } from 'lucide-react'

const REASONS = [
  { value: 'spam', label: 'Spam or repetitive content' },
  { value: 'harassment', label: 'Harassment or personal attacks' },
  { value: 'threats_bullying', label: 'Threats or bullying' },
  { value: 'hate_abuse', label: 'Hate or abusive content' },
  { value: 'explicit_content', label: 'Explicit adult content' },
  { value: 'illegal_content', label: 'Illegal content' },
  { value: 'malicious_file', label: 'Malicious file or link' },
  { value: 'impersonation', label: 'Impersonation' },
  { value: 'disruptive_behavior', label: 'Repeated disruptive behavior' },
  { value: 'other', label: 'Other (explain in details)' },
]

export function ReportDialog({
  open,
  onOpenChange,
  messageId,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  messageId: string | null
}) {
  const [reason, setReason] = useState('')
  const [details, setDetails] = useState('')
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const submit = async () => {
    if (!messageId || !reason) return
    setLoading(true)
    setErr(null)
    try {
      await api('/api/reports', {
        method: 'POST',
        body: JSON.stringify({ messageId, reason, details }),
      })
      setDone(true)
      setTimeout(() => {
        setDone(false)
        setReason('')
        setDetails('')
        onOpenChange(false)
      }, 1500)
    } catch (e: any) {
      setErr(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="mhc-glass-strong border-blue-400/30 text-blue-50">
        <DialogHeader>
          <DialogTitle className="text-blue-100">Report this message</DialogTitle>
        </DialogHeader>
        {done ? (
          <div className="py-6 text-center text-emerald-300">✓ Report submitted. Thank you — our admin team will review it.</div>
        ) : (
          <div className="space-y-4">
            <div>
              <label className="text-xs uppercase tracking-wider text-blue-300/70">Reason</label>
              <div className="grid gap-1 mt-2 max-h-60 overflow-y-auto mhc-no-scrollbar">
                {REASONS.map((r) => (
                  <label
                    key={r.value}
                    className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer text-sm ${
                      reason === r.value ? 'bg-blue-500/25 border border-blue-400/40' : 'hover:bg-white/5'
                    }`}
                  >
                    <input
                      type="radio"
                      name="reason"
                      value={r.value}
                      checked={reason === r.value}
                      onChange={() => setReason(r.value)}
                      className="accent-blue-500"
                    />
                    <span>{r.label}</span>
                  </label>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs uppercase tracking-wider text-blue-300/70">Additional details (optional)</label>
              <textarea
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                rows={3}
                className="mt-1 w-full bg-white/5 border border-blue-400/20 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-400/60"
              />
            </div>
            {err && <div className="text-sm text-red-300">{err}</div>}
          </div>
        )}
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancel
          </Button>
          <Button
            onClick={submit}
            disabled={loading || !reason}
            className="mhc-gradient-btn text-white border-0"
          >
            {loading ? <Loader2 className="animate-spin" size={14} /> : 'Submit Report'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
