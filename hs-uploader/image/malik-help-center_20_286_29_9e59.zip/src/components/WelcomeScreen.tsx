'use client'

import { useEffect, useRef, useState } from 'react'
import { ParticleBackground } from '@/components/ParticleBackground'
import { VerifiedBadge } from '@/components/VerifiedBadge'
import { api, setToken } from '@/lib/api-client'
import { Loader2, Upload, User as UserIcon, X, ShieldCheck, Sparkles, Lock } from 'lucide-react'

type Stage = 'form' | 'uploading' | 'verify' | 'success' | 'error'

export function WelcomeScreen({ onAuthenticated }: { onAuthenticated: () => void }) {
  const [stage, setStage] = useState<Stage>('form')
  const [username, setUsername] = useState('')
  const [avatarFile, setAvatarFile] = useState<File | null>(null)
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null)
  const [password, setPassword] = useState('')
  const [showPasswordField, setShowPasswordField] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [verifyProgress, setVerifyProgress] = useState(0)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Check if username is the admin username — show password field automatically
  const isAdminUsername = (u: string) => {
    return u.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '') === 'malik__mushahid'
  }

  // verification progress driver
  useEffect(() => {
    if (stage !== 'verify') return
    let p = 0
    const interval = setInterval(() => {
      p = Math.min(100, p + Math.random() * 12 + 6)
      setVerifyProgress(p)
      if (p >= 100) {
        clearInterval(interval)
        setTimeout(() => setStage('success'), 600)
      }
    }, 280)
    return () => clearInterval(interval)
  }, [stage])

  // After success stage, call /api/verify, then redirect.
  useEffect(() => {
    if (stage !== 'success') return
    let cancelled = false
    ;(async () => {
      try {
        await api('/api/verify', { method: 'POST' })
        setTimeout(() => {
          if (!cancelled) onAuthenticated()
        }, 1800)
      } catch (e: any) {
        if (!cancelled) {
          setError(e.message || 'Verification failed on the server.')
          setStage('error')
        }
      }
    })()
    return () => {
      cancelled = true
    }
  }, [stage, onAuthenticated])

  const onPickAvatar = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(file.type)) {
      setError('Profile picture must be JPG, PNG, WEBP, or GIF.')
      return
    }
    if (file.size > 5 * 1024 * 1024) {
      setError('Profile picture must be under 5MB.')
      return
    }
    setError(null)
    setAvatarFile(file)
    const reader = new FileReader()
    reader.onload = (ev) => setAvatarPreview(ev.target?.result as string)
    reader.readAsDataURL(file)
  }

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    if (!username.trim()) {
      setError('Username is required.')
      return
    }

    const isAdmin = isAdminUsername(username)
    if (isAdmin && !password) {
      setError('Admin login requires a password.')
      setShowPasswordField(true)
      return
    }

    // For non-admin users: avatar is required only on first login
    // For admin: avatar is required on first login too
    // We'll let backend decide if avatar is needed (existing user can re-login without avatar)
    setStage('uploading')
    try {
      const fd = new FormData()
      fd.append('username', username.trim())
      if (avatarFile) fd.append('avatar', avatarFile)
      if (isAdmin) fd.append('password', password)
      const res = await fetch('/api/join', { method: 'POST', body: fd })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        setError(data?.error || 'Failed to join.')
        setStage('form')
        if (data?.requiresAdminPassword) setShowPasswordField(true)
        return
      }
      setToken(data.token)
      setStage('verify')
    } catch (e: any) {
      setError(e?.message || 'Network error.')
      setStage('form')
    }
  }

  // Auto-show password field when admin username is typed
  useEffect(() => {
    if (isAdminUsername(username)) {
      // Defer setState to avoid synchronous setState-in-effect lint rule
      Promise.resolve().then(() => {
        setShowPasswordField(true)
      })
    } else {
      Promise.resolve().then(() => {
        setShowPasswordField(false)
        setPassword('')
      })
    }
  }, [username])

  return (
    <main className="relative min-h-screen flex items-center justify-center px-4 py-8 overflow-hidden">
      <ParticleBackground count={32} />

      {/* Top brand bar */}
      <div className="absolute top-6 left-1/2 -translate-x-1/2 flex items-center gap-3 z-10">
        <Logo size={36} />
        <div className="leading-tight">
          <div className="font-bold text-base sm:text-lg tracking-wide mhc-text-gradient">
            MALIK HELP CENTER
          </div>
          <div className="text-[10px] uppercase tracking-[0.25em] text-blue-300/70">
            Premium Community
          </div>
        </div>
      </div>

      <div className="relative z-10 w-full max-w-md mhc-glass-strong rounded-3xl p-6 sm:p-8 shadow-2xl">
        {stage === 'form' && (
          <FormStage
            username={username}
            setUsername={setUsername}
            avatarPreview={avatarPreview}
            onPickAvatar={onPickAvatar}
            fileInputRef={fileInputRef}
            error={error}
            onSubmit={onSubmit}
            showPasswordField={showPasswordField}
            password={password}
            setPassword={setPassword}
          />
        )}

        {stage === 'uploading' && (
          <CenteredStatus
            icon={<Loader2 className="animate-spin" size={40} />}
            title="Securing your spot…"
            subtitle="Encrypting profile & verifying identity"
          />
        )}

        {stage === 'verify' && (
          <VerificationStage progress={verifyProgress} />
        )}

        {stage === 'success' && (
          <SuccessStage />
        )}

        {stage === 'error' && (
          <CenteredStatus
            icon={<X size={40} className="text-red-400" />}
            title="Verification Failed"
            subtitle={error || 'Please try again.'}
            action={
              <button
                className="mt-4 px-5 py-2 rounded-xl mhc-gradient-btn text-white font-medium"
                onClick={() => setStage('form')}
              >
                Try Again
              </button>
            }
          />
        )}
      </div>

      <footer className="absolute bottom-4 left-0 right-0 text-center text-xs text-blue-300/50 z-10">
        By entering, you agree to follow our Community Guidelines.
      </footer>
    </main>
  )
}

function FormStage(props: any) {
  const {
    username, setUsername, avatarPreview, onPickAvatar, fileInputRef, error, onSubmit,
    showPasswordField, password, setPassword,
  } = props

  const isAdmin = username.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '') === 'malik__mushahid'

  return (
    <form onSubmit={onSubmit} className="space-y-5 mhc-anim-fade-up">
      <div className="text-center">
        <h1 className="text-2xl sm:text-3xl font-bold mhc-text-gradient">Welcome</h1>
        <p className="text-blue-200/70 text-sm mt-1">
          {isAdmin
            ? 'Admin login — please enter your password.'
            : 'Pick a unique username and upload a profile picture to join.'}
        </p>
      </div>

      {/* Avatar picker */}
      <div className="flex flex-col items-center gap-3">
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="relative w-24 h-24 rounded-full mhc-glass border border-blue-400/30 flex items-center justify-center overflow-hidden mhc-anim-glow"
          aria-label="Upload profile picture"
        >
          {avatarPreview ? (
            <img src={avatarPreview} alt="avatar preview" className="w-full h-full object-cover" />
          ) : (
            <div className="flex flex-col items-center text-blue-200">
              <Upload size={22} />
              <span className="text-[10px] mt-1">UPLOAD</span>
            </div>
          )}
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/gif"
          className="mhc-sr-file"
          onChange={onPickAvatar}
        />
        <p className="text-xs text-blue-300/60">
          {isAdmin ? 'Profile picture (optional on re-login)' : 'Profile picture (required on first login)'}
        </p>
      </div>

      {/* Username input */}
      <div className="space-y-2">
        <label className="text-xs uppercase tracking-wider text-blue-300/70">Username</label>
        <div className="relative">
          <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300/70" size={18} />
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="e.g. ahmad_ali"
            maxLength={24}
            className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-blue-400/20 focus:border-blue-400/60 focus:outline-none focus:ring-2 focus:ring-blue-500/30 text-white placeholder:text-blue-300/40"
          />
        </div>
        <p className="text-[11px] text-blue-300/50">
          3–24 chars, letters, numbers, underscore. Admin username: <code className="text-emerald-300">malik__mushahid</code>.
        </p>
      </div>

      {/* Password field (admin only) */}
      {showPasswordField && (
        <div className="space-y-2 mhc-anim-fade-up">
          <label className="text-xs uppercase tracking-wider text-emerald-300/80 flex items-center gap-1">
            <Lock size={12} /> Admin Password
          </label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-emerald-300/70" size={18} />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter admin password"
              className="w-full pl-10 pr-4 py-3 rounded-xl bg-emerald-500/5 border border-emerald-400/30 focus:border-emerald-400/60 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-white placeholder:text-emerald-200/30"
            />
          </div>
          <p className="text-[11px] text-emerald-300/60">Only the official administrator needs a password.</p>
        </div>
      )}

      {error && (
        <div className="rounded-xl bg-red-500/15 border border-red-500/30 px-4 py-3 text-sm text-red-200">
          {error}
        </div>
      )}

      <button
        type="submit"
        className="w-full py-3 rounded-xl mhc-gradient-btn text-white font-semibold text-base shadow-lg hover:shadow-blue-500/40 hover:scale-[1.01] transition-all"
      >
        {isAdmin ? 'Login as Admin' : 'Enter Chat'}
      </button>

      <div className="text-center text-[11px] text-blue-300/50">
        {isAdmin ? 'Admin authentication required.' : 'No email, no password. Just username + picture.'}
      </div>
    </form>
  )
}

function VerificationStage({ progress }: { progress: number }) {
  return (
    <div className="flex flex-col items-center text-center mhc-anim-fade-up">
      <RobotAvatar />
      <h2 className="mt-6 text-xl font-bold text-white">Verifying your identity…</h2>
      <p className="text-blue-200/70 text-sm mt-1">Our assistant is checking your account.</p>

      <div className="mt-6 w-full">
        <div className="h-2 rounded-full bg-white/5 overflow-hidden">
          <div
            className="h-full mhc-gradient-btn transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="mt-2 text-xs text-blue-300/70 flex items-center justify-between">
          <span>{progress < 30 ? 'Checking username…' : progress < 60 ? 'Validating avatar…' : progress < 95 ? 'Securing session…' : 'Finalizing…'}</span>
          <span>{Math.round(progress)}%</span>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-2 w-full text-[10px] text-blue-300/70">
        <CheckPill label="Unique username" done={progress > 30} />
        <CheckPill label="Avatar valid" done={progress > 60} />
        <CheckPill label="Session secured" done={progress > 95} />
      </div>
    </div>
  )
}

function CheckPill({ label, done }: { label: string; done: boolean }) {
  return (
    <div className={`rounded-lg px-2 py-1.5 border text-center ${done ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-200' : 'bg-white/5 border-white/10'}`}>
      {done ? '✓ ' : ''}{label}
    </div>
  )
}

function SuccessStage() {
  return (
    <div className="flex flex-col items-center text-center mhc-anim-fade-up">
      <div className="relative">
        <div className="w-24 h-24 rounded-full bg-emerald-500/15 border-2 border-emerald-400/60 flex items-center justify-center mhc-anim-glow">
          <svg viewBox="0 0 24 24" className="w-12 h-12 text-emerald-300" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12" />
          </svg>
        </div>
        <div className="absolute -top-1 -right-1">
          <VerifiedBadge size={26} />
        </div>
      </div>
      <h2 className="mt-6 text-2xl font-bold mhc-text-gradient">Verification Complete!</h2>
      <p className="mt-2 text-blue-200/80 text-base">Welcome to the Malik Help Center</p>
      <p className="mt-4 text-xs text-blue-300/60 flex items-center gap-1.5">
        <Sparkles size={12} /> Entering the community chat…
      </p>
    </div>
  )
}

function CenteredStatus({ icon, title, subtitle, action }: any) {
  return (
    <div className="flex flex-col items-center text-center mhc-anim-fade-up">
      <div className="text-blue-200">{icon}</div>
      <h2 className="mt-4 text-xl font-bold text-white">{title}</h2>
      <p className="mt-2 text-sm text-blue-200/70">{subtitle}</p>
      {action}
    </div>
  )
}

function RobotAvatar() {
  return (
    <div className="relative w-28 h-28">
      {/* pulse rings */}
      <div className="absolute inset-0 rounded-3xl bg-blue-500/20 mhc-pulse-ring" />
      <div className="absolute inset-0 rounded-3xl bg-emerald-500/15 mhc-pulse-ring" style={{ animationDelay: '1.2s' }} />
      {/* body */}
      <div className="absolute inset-2 rounded-3xl mhc-glass border border-blue-400/30 flex items-center justify-center overflow-hidden">
        {/* antenna */}
        <div className="absolute top-1 left-1/2 -translate-x-1/2 w-1 h-2 bg-blue-400/60 rounded-full">
          <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-emerald-400 mhc-anim-glow" />
        </div>
        {/* eyes */}
        <div className="flex gap-3 mt-1">
          <div className="w-3 h-3 rounded-full bg-blue-400 mhc-anim-blink" />
          <div className="w-3 h-3 rounded-full bg-emerald-400 mhc-anim-blink" style={{ animationDelay: '0.2s' }} />
        </div>
        {/* mouth — animated bars */}
        <div className="absolute bottom-3 flex gap-1 items-end h-3">
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              className="w-1 bg-blue-300 rounded-full"
              style={{
                height: '100%',
                animation: `mhc-blink 1.2s ${i * 0.15}s infinite`,
                transformOrigin: 'bottom',
              }}
            />
          ))}
        </div>
      </div>
    </div>
  )
}

function Logo({ size = 36 }: { size?: number }) {
  return (
    <div
      className="rounded-2xl mhc-gradient-btn flex items-center justify-center shadow-lg"
      style={{ width: size, height: size }}
    >
      <svg viewBox="0 0 24 24" className="w-2/3 h-2/3 text-white" fill="currentColor" aria-hidden="true">
        <path d="M12 2 3 7v10l9 5 9-5V7l-9-5zm0 2.3 6.5 3.6L12 11.5 5.5 7.9 12 4.3zM5 9.6l6 3.3v6.8l-6-3.3V9.6zm14 0v6.8l-6 3.3v-6.8l6-3.3z" />
      </svg>
    </div>
  )
}
