'use client'

import { useState } from 'react'

const CATEGORIES: { name: string; emojis: string[] }[] = [
  {
    name: 'Smileys',
    emojis: ['😀','😃','😄','😁','😆','😅','🤣','😂','🙂','🙃','😉','😊','😇','🥰','😍','🤩','😘','😗','😚','😙','😋','😛','😜','🤪','😝','🤗','🤭','🤔','🤐','😐','😑','😶','😏','😒','🙄','😬','😴','🤤','😷','🤒','🤕','🤢','🤮','😵','🤯','🥳','😎','🤓','🧐','😕','😟','🙁','😮','😯','😲','😳','🥺','😦','😧','😨','😰','😥','😢','😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡','😠','🤬','😈','👿','💀','💩','🤡','👹','👺','👻'],
  },
  {
    name: 'Gestures',
    emojis: ['👍','👎','👌','✌️','🤞','🤟','🤘','🤙','👈','👉','👆','👇','☝️','✋','🤚','🖐','🖖','👋','🤝','👏','🙌','👐','🙏','✍️','💪','🦾','🦿','🦵','👂','👃','👁','👅','👄','🦷','👶','🧒','👦','👧','🧑','👨','👩','🧓','👴','👵'],
  },
  {
    name: 'Symbols',
    emojis: ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❣️','💕','💞','💓','💗','💖','💘','💝','💟','🔥','✨','🌟','⭐','💫','💥','💯','🎉','🎊','🎁','🏆','🥇','🥈','🥉','✅','❌','⚠️','🚫','🔞','📱','💻','🖥','⌨️','🖱','💾','📷','📸','🎥','📞','☎️','📡','🔔','🔕','📢','📣','💬','💭'],
  },
  {
    name: 'Food',
    emojis: ['🍏','🍎','🍐','🍊','🍋','🍌','🍉','🍇','🍓','🫐','🍈','🍒','🍑','🥭','🍍','🥥','🥝','🍅','🍆','🥑','🥦','🥕','🌽','🌶','🥒','🥬','🥔','🍠','🥐','🍞','🥖','🥨','🧀','🥚','🍳','🥞','🥓','🥩','🍗','🍖','🌭','🍔','🍟','🍕','🥪','🌮','🌯','🥙','🍜','🍝','🍣','🍱','🍤','🍙','🍚','🍘','🍥','🥮','🍢','🍡','🍧','🍨','🍦','🥧','🧁','🍰','🎂','🍮','🍬','🍭','🍫','🍩','🍪','☕','🍵','🥤','🍶','🍺','🍻','🥃','🍷','🥂','🥁'],
  },
]

export function EmojiPicker({ onPick, onClose }: { onPick: (e: string) => void; onClose?: () => void }) {
  const [cat, setCat] = useState(0)
  return (
    <div className="mhc-glass-strong rounded-2xl p-2 shadow-2xl w-72 max-w-[90vw]">
      <div className="flex gap-1 mb-2 border-b border-white/10 pb-1">
        {CATEGORIES.map((c, i) => (
          <button
            key={c.name}
            onClick={() => setCat(i)}
            className={`px-2 py-1 text-[10px] rounded-md ${
              cat === i ? 'bg-blue-500/30 text-blue-100' : 'text-blue-300/70 hover:bg-white/5'
            }`}
          >
            {c.name}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-8 gap-1 max-h-44 overflow-y-auto mhc-no-scrollbar">
        {CATEGORIES[cat].emojis.map((e, i) => (
          <button
            key={i}
            onClick={() => onPick(e)}
            className="w-7 h-7 flex items-center justify-center text-lg rounded hover:bg-white/10"
          >
            {e}
          </button>
        ))}
      </div>
    </div>
  )
}
