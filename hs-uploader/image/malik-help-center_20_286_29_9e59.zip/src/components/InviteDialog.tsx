'use client'

import { useEffect, useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Copy, Share2, Check, Link2 } from 'lucide-react'
import { api } from '@/lib/api-client'

export function InviteDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const [inviteUrl, setInviteUrl] = useState<string>('')
  const [copied, setCopied] = useState(false)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!open) return
    let cancelled = false
    const load = async () => {
      try {
        const d = await api('/api/invite')
        if (!cancelled) {
          setInviteUrl(d.inviteUrl)
          setLoading(false)
        }
      } catch {
        if (!cancelled) setLoading(false)
      }
    }
    // Defer setState to avoid synchronous setState-in-effect lint rule
    Promise.resolve().then(() => {
      if (!cancelled) {
        setLoading(true)
        load()
      }
    })
    return () => { cancelled = true }
  }, [open])

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(inviteUrl)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {}
  }

  const share = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: 'Malik Help Center', text: 'Join me at Malik Help Center', url: inviteUrl })
      } catch {}
    } else {
      copy()
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="mhc-glass-strong border-blue-400/30 text-blue-50 max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-blue-100">
            <Link2 className="text-emerald-400" /> Invite Members
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p className="text-sm text-blue-200/80">
            Share this link with anyone you want to invite. Every new visitor must pick a unique username and upload a profile picture before joining.
          </p>
          <div className="flex items-center gap-2 p-3 rounded-xl bg-white/5 border border-blue-400/20">
            <input
              readOnly
              value={loading ? 'Loading…' : inviteUrl}
              className="flex-1 bg-transparent text-sm text-blue-100 focus:outline-none truncate"
            />
            <Button size="sm" onClick={copy} disabled={!inviteUrl} className="mhc-gradient-btn text-white border-0">
              {copied ? <Check size={14} /> : <Copy size={14} />}
            </Button>
          </div>
          {copied && <div className="text-xs text-emerald-300">✓ Link copied to clipboard.</div>}
          <Button onClick={share} disabled={!inviteUrl} className="w-full mhc-gradient-btn text-white border-0">
            <Share2 size={14} className="mr-2" /> Share via device
          </Button>
          <div className="text-[11px] text-blue-300/60">
            The invitation link does not grant administrator privileges.
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
