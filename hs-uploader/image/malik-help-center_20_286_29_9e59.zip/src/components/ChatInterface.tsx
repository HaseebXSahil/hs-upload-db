'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { io, Socket } from 'socket.io-client'
import { api, setToken } from '@/lib/api-client'
import { MessageBubble, ChatMessage } from './MessageBubble'
import { VoiceRecorder } from './VoiceRecorder'
import { EmojiPicker } from './EmojiPicker'
import { ReportDialog } from './ReportDialog'
import { MediaPreviewWindow } from './MediaPreviewWindow'
import { GuidelinesDialog } from './GuidelinesDialog'
import { InviteDialog } from './InviteDialog'
import { AdminDashboard } from './AdminDashboard'
import { VerifiedBadge } from './VerifiedBadge'
import {
  Send,
  Paperclip,
  Smile,
  Search,
  X,
  Users,
  Shield,
  LogOut,
  Image as ImageIcon,
  FileText,
  Loader2,
  WifiOff,
  VolumeX,
  ChevronDown,
  Menu,
  Link2,
  Sparkles,
} from 'lucide-react'

type MeUser = {
  id: string
  username: string
  displayName: string
  avatarUrl: string
  isAdmin: boolean
  isVerified: boolean
  isMuted: boolean
  isBanned: boolean
  muteReason: string | null
  mutedUntil: string | null
}

type PresenceMember = {
  userId: string
  username: string
  displayName: string
  avatarUrl: string
  isAdmin: boolean
  isVerified: boolean
}

export function ChatInterface({ onLogout }: { onLogout: () => void }) {
  const [me, setMe] = useState<MeUser | null>(null)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null)
  const [loadingMore, setLoadingMore] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const cursorRef = useRef<string | null>(null)
  const [connected, setConnected] = useState(false)
  const [showEmoji, setShowEmoji] = useState(false)
  const [showMembers, setShowMembers] = useState(false)
  const [showSearch, setShowSearch] = useState(false)
  const [search, setSearch] = useState('')
  const [searchResults, setSearchResults] = useState<ChatMessage[] | null>(null)
  const [reportTarget, setReportTarget] = useState<string | null>(null)
  const [preview, setPreview] = useState<ChatMessage | null>(null)
  const [showGuidelines, setShowGuidelines] = useState(false)
  const [showInvite, setShowInvite] = useState(false)
  const [showAdmin, setShowAdmin] = useState(false)
  const [onlineMembers, setOnlineMembers] = useState<PresenceMember[]>([])
  const [typingUsers, setTypingUsers] = useState<Record<string, number>>({})
  const [toast, setToast] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)

  const socketRef = useRef<Socket | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  const lastSeenAtRef = useRef<string | null>(null)
  const typingTimerRef = useRef<any>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const imageInputRef = useRef<HTMLInputElement>(null)

  // Load me + initial messages
  useEffect(() => {
    ;(async () => {
      try {
        const d = await api<{ user: MeUser }>('/api/me')
        setMe(d.user)
        if (d.user.isBanned) {
          alert('You are banned.')
          handleLogout()
          return
        }
        const md = await api<{ messages: ChatMessage[]; nextCursor: string | null }>('/api/messages?limit=50')
        setMessages(md.messages)
        cursorRef.current = md.nextCursor
        setHasMore(!!md.nextCursor)
        // scroll to bottom
        requestAnimationFrame(() => {
          if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight
        })
      } catch (e: any) {
        if (e.status === 401) handleLogout()
      }
    })()
     
  }, [])

  // Socket.io
  useEffect(() => {
    if (!me) return
    const token = localStorage.getItem('mhc_token')
    // WebSocket URL resolution:
    // 1. If NEXT_PUBLIC_WS_URL is set in .env, use it (production deploy).
    // 2. Otherwise, attempt a direct connection to the same hostname on port 3003
    //    (works for local/same-machine deployments where chat-service runs on 3003).
    // 3. Fall back to the gateway path with XTransformPort=3003 (works when a
    //    Caddy/Nginx gateway is configured to forward that query to port 3003).
    const configuredUrl = process.env.NEXT_PUBLIC_WS_URL
    const hostname = typeof window !== 'undefined' ? window.location.hostname : 'localhost'
    const directUrl = `http://${hostname}:3003`
    const gatewayUrl = '/?XTransformPort=3003'
    const wsUrl = configuredUrl || directUrl
    const wsQuery: any = wsUrl.includes('XTransformPort') ? { XTransformPort: '3003' } : undefined

    const sock = io(wsUrl, {
      transports: ['websocket', 'polling'],
      auth: { token },
      query: wsQuery,
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1500,
    })
    socketRef.current = sock

    sock.on('connect', () => setConnected(true))
    sock.on('disconnect', () => setConnected(false))
    sock.on('connect_error', () => {
      setConnected(false)
      // If direct connection fails after a few attempts, switch to gateway path
      if (!configuredUrl && wsUrl === directUrl) {
        setTimeout(() => {
          if (socketRef.current === sock && !sock.connected) {
            try {
              sock.io.uri = gatewayUrl
              sock.io.opts.query = { XTransformPort: '3003' }
              sock.connect()
            } catch {}
          }
        }, 4000)
      }
    })

    sock.on('me:update', (u: MeUser) => {
      setMe((prev) => (prev ? { ...prev, ...u } : prev))
      if (u.isBanned) {
        alert('You have been banned by an administrator.')
        handleLogout()
      }
      if (u.isMuted && !me?.isMuted) {
        showToast('You have been muted by an administrator.')
      }
    })

    sock.on('presence:update', (data: { onlineCount: number; members: PresenceMember[] }) => {
      setOnlineMembers(data.members)
    })

    // Real-time message events. To keep ordering consistent, server pushes
    // the message payload; we merge if it doesn't already exist (avoid dups
    // when our own send returns the message via REST as well).
    sock.on('message:new', (msg: ChatMessage) => {
      setMessages((prev) => {
        if (prev.some((m) => m.id === msg.id)) return prev
        // dedupe against optimistic
        return [...prev.filter((m) => m.id !== ('optimistic-' + msg.id)), msg]
      })
      requestAnimationFrame(() => {
        if (scrollRef.current) {
          const el = scrollRef.current
          // autoscroll if near bottom
          if (el.scrollHeight - el.scrollTop - el.clientHeight < 220) {
            el.scrollTop = el.scrollHeight
          }
        }
      })
    })

    sock.on('message:updated', (msg: ChatMessage) => {
      setMessages((prev) => prev.map((m) => (m.id === msg.id ? { ...m, ...msg } : m)))
    })
    sock.on('message:deleted', (data: { id: string; deletedBy: string }) => {
      setMessages((prev) =>
        prev.map((m) => (m.id === data.id ? { ...m, deleted: true, deletedBy: data.deletedBy } : m)),
      )
    })
    sock.on('reaction:update', (data: { messageId: string; reactions: string }) => {
      setMessages((prev) => prev.map((m) => (m.id === data.messageId ? { ...m, reactions: data.reactions } : m)))
    })

    sock.on('typing:start', (data: { userId: string; username: string }) => {
      setTypingUsers((prev) => ({ ...prev, [data.userId]: Date.now() }))
    })
    sock.on('typing:stop', (data: { userId: string }) => {
      setTypingUsers((prev) => {
        const next = { ...prev }
        delete next[data.userId]
        return next
      })
    })

    // Periodic presence ping
    const ping = setInterval(() => sock.emit('presence:ping'), 30000)
    // Clean stale typing indicators
    const cleanTyping = setInterval(() => {
      setTypingUsers((prev) => {
        const now = Date.now()
        const next: any = {}
        for (const [k, v] of Object.entries(prev)) {
          if (now - (v as number) < 4000) next[k] = v
        }
        return next
      })
    }, 2000)

    return () => {
      clearInterval(ping)
      clearInterval(cleanTyping)
      sock.disconnect()
    }
     
  }, [me?.id])

  // Notify server of new messages via REST (so server can persist + emit)
  const sendMessage = useCallback(
    async (payload: {
      type: string
      content: string
      caption?: string
      fileName?: string
      fileSize?: number
      mimeType?: string
      duration?: number
      replyToId?: string | null
    }) => {
      try {
        const d = await api<{ ok: boolean; message: ChatMessage } | { ok: false; error: string; muted?: boolean }>(
          '/api/messages',
          { method: 'POST', body: JSON.stringify(payload) },
        )
        if (!d.ok) {
          const err = d as any
          showToast(err.error || 'Could not send message.')
          if (err.muted) {
            setMe((prev) => (prev ? { ...prev, isMuted: true, muteReason: err.error } : prev))
          }
          return null
        }
        // Server emits message:new via socketio — but to be safe also merge locally if not received
        const msg = (d as any).message as ChatMessage
        setMessages((prev) => (prev.some((m) => m.id === msg.id) ? prev : [...prev, msg]))
        return msg
      } catch (e: any) {
        showToast(e.message)
        return null
      }
    },
    [],
  )

  const showToast = (msg: string) => {
    setToast(msg)
    setTimeout(() => setToast(null), 4000)
  }

  const handleLogout = () => {
    api('/api/logout', { method: 'POST' }).catch(() => {})
    setToken(null)
    onLogout()
  }

  const onSendText = async () => {
    if (!input.trim() || !me) return
    if (me.isMuted) {
      showToast(me.muteReason || 'You are muted.')
      return
    }
    const text = input.trim()
    setInput('')
    setReplyTo(null)
    setShowEmoji(false)
    socketRef.current?.emit('typing:stop')
    await sendMessage({
      type: 'text',
      content: text,
      replyToId: replyTo?.id || null,
    })
  }

  const onTyping = (val: string) => {
    setInput(val)
    if (me?.isMuted) return
    socketRef.current?.emit('typing:start')
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current)
    typingTimerRef.current = setTimeout(() => socketRef.current?.emit('typing:stop'), 2500)
  }

  const onPickEmoji = (e: string) => {
    setInput((v) => v + e)
  }

  const onReact = async (m: ChatMessage, emoji: string) => {
    try {
      const d = await api<{ reactions: string }>(`/api/messages/${m.id}/reactions`, {
        method: 'POST',
        body: JSON.stringify({ emoji }),
      })
      setMessages((prev) => prev.map((mm) => (mm.id === m.id ? { ...mm, reactions: d.reactions } : mm)))
      socketRef.current?.emit('reaction:toggle', { messageId: m.id, emoji })
    } catch (e: any) {
      showToast(e.message)
    }
  }

  const onEdit = async (m: ChatMessage, text: string) => {
    try {
      const d = await api<{ message: ChatMessage }>('/api/messages', {
        method: 'PATCH',
        body: JSON.stringify({ id: m.id, content: text }),
      })
      setMessages((prev) => prev.map((mm) => (mm.id === m.id ? { ...mm, ...d.message } : mm)))
      socketRef.current?.emit('message:edit', { id: m.id, content: text })
    } catch (e: any) {
      showToast(e.message)
    }
  }

  const onDelete = async (m: ChatMessage) => {
    if (!confirm('Delete this message?')) return
    try {
      await api(`/api/messages?id=${m.id}`, { method: 'DELETE' })
      setMessages((prev) => prev.map((mm) => (mm.id === m.id ? { ...mm, deleted: true } : mm)))
    } catch (e: any) {
      showToast(e.message)
    }
  }

  const loadMore = async () => {
    if (loadingMore || !hasMore) return
    setLoadingMore(true)
    try {
      const d = await api<{ messages: ChatMessage[]; nextCursor: string | null }>(
        `/api/messages?cursor=${cursorRef.current}&limit=50`,
      )
      const prevHeight = scrollRef.current?.scrollHeight || 0
      setMessages((prev) => [...d.messages, ...prev])
      cursorRef.current = d.nextCursor
      setHasMore(!!d.nextCursor)
      // keep scroll position
      requestAnimationFrame(() => {
        if (scrollRef.current) {
          const newHeight = scrollRef.current.scrollHeight
          scrollRef.current.scrollTop = newHeight - prevHeight
        }
      })
    } finally {
      setLoadingMore(false)
    }
  }

  const onScroll = () => {
    if (scrollRef.current && scrollRef.current.scrollTop < 40 && hasMore && !loadingMore) {
      loadMore()
    }
  }

  const onSearch = async () => {
    if (!search.trim()) {
      setSearchResults(null)
      return
    }
    try {
      const d = await api<{ messages: ChatMessage[] }>(`/api/messages?q=${encodeURIComponent(search)}`)
      setSearchResults(d.messages)
    } catch (e: any) {
      showToast(e.message)
    }
  }

  const uploadFile = async (file: File, kind: 'image' | 'video' | 'document') => {
    if (!me) return
    if (me.isMuted) {
      showToast(me.muteReason || 'You are muted.')
      return
    }
    setUploading(true)
    setUploadProgress(0)
    try {
      const fd = new FormData()
      fd.append('file', file)
      // Use XHR for progress
      const res = await new Promise<any>((resolve, reject) => {
        const xhr = new XMLHttpRequest()
        xhr.open('POST', '/api/upload')
        xhr.setRequestHeader('Authorization', `Bearer ${localStorage.getItem('mhc_token')}`)
        xhr.upload.onprogress = (ev) => {
          if (ev.lengthComputable) setUploadProgress(Math.round((ev.loaded / ev.total) * 100))
        }
        xhr.onload = () => {
          try {
            const data = JSON.parse(xhr.responseText)
            if (xhr.status >= 200 && xhr.status < 300) resolve(data)
            else reject(new Error(data.error || 'Upload failed'))
          } catch (e: any) {
            reject(new Error('Upload failed'))
          }
        }
        xhr.onerror = () => reject(new Error('Network error'))
        xhr.send(fd)
      })
      await sendMessage({
        type: kind,
        content: res.url,
        fileName: res.fileName,
        fileSize: res.fileSize,
        mimeType: res.mimeType,
        duration: res.duration,
        replyToId: replyTo?.id || null,
      })
      setReplyTo(null)
    } catch (e: any) {
      showToast(e.message)
    } finally {
      setUploading(false)
      setUploadProgress(0)
    }
  }

  const onPickImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) uploadFile(file, file.type.startsWith('video/') ? 'video' : 'image')
    e.target.value = ''
  }
  const onPickDoc = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) uploadFile(file, 'document')
    e.target.value = ''
  }

  const visibleMessages = searchResults || messages

  const mutedBanner = me?.isMuted ? (
    <div className="px-4 py-2 bg-orange-500/15 border-y border-orange-400/30 text-orange-200 text-xs flex items-center gap-2">
      <VolumeX size={14} /> {me.muteReason || 'You are muted.'} Contact the admin to be unmuted.
    </div>
  ) : null

  return (
    <div className="relative h-screen flex flex-col overflow-hidden">
      {/* Header */}
      <header className="mhc-glass-strong border-b border-blue-400/15 px-3 sm:px-4 py-2.5 flex items-center gap-3 z-30">
        <button
          className="md:hidden p-2 rounded-lg hover:bg-white/10 text-blue-200"
          onClick={() => setShowMembers(true)}
        >
          <Menu size={18} />
        </button>
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-9 h-9 rounded-xl mhc-gradient-btn flex items-center justify-center shadow shrink-0">
            <Sparkles size={16} className="text-white" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h1 className="font-bold text-sm sm:text-base mhc-text-gradient truncate">MALIK HELP CENTER</h1>
            </div>
            <div className="text-[10px] sm:text-xs text-blue-300/70 flex items-center gap-1.5">
              <span className={`w-1.5 h-1.5 rounded-full ${connected ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`} />
              {connected ? 'Connected' : 'Reconnecting…'}
              <span className="mx-1">·</span>
              <Users size={10} /> {onlineMembers.length} online
            </div>
          </div>
        </div>

        <div className="flex-1" />

        {/* Header actions */}
        <div className="flex items-center gap-1">
          <IconBtn onClick={() => setShowSearch((s) => !s)} title="Search messages">
            <Search size={16} />
          </IconBtn>
          <IconBtn onClick={() => setShowInvite(true)} title="Invite members">
            <Link2 size={16} />
          </IconBtn>
          <IconBtn onClick={() => setShowGuidelines(true)} title="Community guidelines">
            <Shield size={16} />
          </IconBtn>
          {me?.isAdmin && (
            <button
              onClick={() => setShowAdmin(true)}
              className="px-2.5 py-1.5 rounded-lg mhc-gradient-btn text-white text-xs font-semibold flex items-center gap-1"
              title="Admin dashboard"
            >
              <Shield size={14} /> <span className="hidden sm:inline">Admin</span>
            </button>
          )}
          {me && (
            <div className="flex items-center gap-2 pl-2 ml-1 border-l border-white/10">
              { }
              <img src={me.avatarUrl} alt={me.displayName} className="w-7 h-7 rounded-full object-cover" />
              <div className="hidden sm:flex items-center gap-1 max-w-[140px]">
                <span className="text-xs font-medium text-blue-100 truncate">{me.displayName}</span>
                {me.isAdmin && me.isVerified && <VerifiedBadge size={12} />}
              </div>
              <IconBtn onClick={handleLogout} title="Leave chat">
                <LogOut size={16} />
              </IconBtn>
            </div>
          )}
        </div>
      </header>

      {!connected && (
        <div className="px-4 py-2 bg-red-500/10 border-b border-red-400/30 text-red-200 text-xs flex items-center gap-2">
          <WifiOff size={14} /> Connection lost. Trying to reconnect…
        </div>
      )}
      {mutedBanner}

      {/* Search bar */}
      {showSearch && (
        <div className="px-3 py-2 mhc-glass border-b border-blue-400/15 flex items-center gap-2">
          <Search size={14} className="text-blue-300/70" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && onSearch()}
            placeholder="Search messages…"
            className="flex-1 bg-transparent text-sm text-blue-100 placeholder:text-blue-300/40 focus:outline-none"
          />
          <button onClick={onSearch} className="px-2 py-1 rounded bg-blue-500/30 text-blue-100 text-xs">Search</button>
          <button
            onClick={() => { setShowSearch(false); setSearch(''); setSearchResults(null) }}
            className="p-1 text-blue-300/70 hover:text-blue-100"
          >
            <X size={14} />
          </button>
          {searchResults && (
            <span className="text-xs text-blue-300/70">{searchResults.length} result(s)</span>
          )}
        </div>
      )}

      {/* Messages area */}
      <div
        ref={scrollRef}
        onScroll={onScroll}
        className="flex-1 overflow-y-auto px-2 sm:px-4 py-3 space-y-1"
      >
        {hasMore && !searchResults && (
          <div className="text-center py-2">
            <button
              onClick={loadMore}
              disabled={loadingMore}
              className="text-xs text-blue-300/70 hover:text-blue-100 inline-flex items-center gap-1"
            >
              {loadingMore ? <Loader2 className="animate-spin" size={12} /> : <ChevronDown size={12} />} Load older messages
            </button>
          </div>
        )}
        {visibleMessages.length === 0 ? (
          <div className="text-center py-12 text-blue-300/60">
            <Sparkles className="mx-auto mb-2 opacity-50" />
            <p className="text-sm">No messages yet. Be the first to say hi!</p>
          </div>
        ) : (
          visibleMessages.map((m) => (
            <MessageBubble
              key={m.id}
              msg={m}
              isMe={m.senderId === me?.id}
              currentUserId={me?.id || ''}
              onReply={(mm) => setReplyTo(mm)}
              onEdit={onEdit}
              onDelete={onDelete}
              onReact={onReact}
              onReport={(mm) => setReportTarget(mm.id)}
              onPreviewMedia={(mm) => setPreview(mm)}
            />
          ))
        )}
        {/* Typing indicator */}
        {Object.keys(typingUsers).length > 0 && (
          <div className="text-xs text-blue-300/70 italic px-2">
            {Object.values(typingUsers).length === 1
              ? 'Someone is typing…'
              : 'Several people are typing…'}
          </div>
        )}
      </div>

      {/* Reply preview */}
      {replyTo && (
        <div className="px-3 py-2 mhc-glass border-t border-blue-400/15 flex items-center gap-2 text-xs">
          <div className="flex-1 min-w-0">
            <div className="text-blue-300">Replying to {replyTo.sender.displayName}</div>
            <div className="text-blue-200/70 truncate">{replyTo.type === 'text' ? replyTo.content : `[${replyTo.type}]`}</div>
          </div>
          <button onClick={() => setReplyTo(null)} className="p-1 text-blue-300/70 hover:text-blue-100">
            <X size={14} />
          </button>
        </div>
      )}

      {/* Composer */}
      <div className="mhc-glass-strong border-t border-blue-400/15 p-2 sm:p-3">
        {uploading ? (
          <div className="px-3 py-2 rounded-xl bg-white/5 border border-blue-400/20">
            <div className="flex items-center justify-between text-xs text-blue-200 mb-1">
              <span>Uploading…</span>
              <span>{uploadProgress}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
              <div className="h-full mhc-gradient-btn transition-all" style={{ width: `${uploadProgress}%` }} />
            </div>
          </div>
        ) : (
          <div className="flex items-end gap-1.5 sm:gap-2">
            {/* Attach buttons */}
            <div className="flex gap-1">
              <IconBtn onClick={() => imageInputRef.current?.click()} title="Send image/video" disabled={me?.isMuted}>
                <ImageIcon size={18} />
              </IconBtn>
              <input ref={imageInputRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif,video/mp4,video/webm,video/quicktime" className="mhc-sr-file" onChange={onPickImage} />
              <IconBtn onClick={() => fileInputRef.current?.click()} title="Send document" disabled={me?.isMuted}>
                <FileText size={18} />
              </IconBtn>
              <input ref={fileInputRef} type="file" accept=".pdf,.doc,.docx,.txt,.csv,.xls,.xlsx,.ppt,.pptx,.zip,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain" className="mhc-sr-file" onChange={onPickDoc} />
            </div>

            {/* Voice recorder (only when input empty) */}
            {!input.trim() && <VoiceRecorder onSend={(info) => sendMessage({ type: 'audio', content: info.url, fileName: info.fileName, fileSize: info.fileSize, mimeType: info.mimeType, duration: info.duration, replyToId: replyTo?.id || null })} disabled={me?.isMuted} />}

            {/* Emoji */}
            <div className="relative">
              <IconBtn onClick={() => setShowEmoji((s) => !s)} title="Emoji" disabled={me?.isMuted}>
                <Smile size={18} />
              </IconBtn>
              {showEmoji && (
                <div className="absolute bottom-12 left-0 z-40">
                  <EmojiPicker onPick={onPickEmoji} onClose={() => setShowEmoji(false)} />
                </div>
              )}
            </div>

            {/* Text input */}
            <div className="flex-1 relative">
              <textarea
                value={input}
                onChange={(e) => onTyping(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault()
                    onSendText()
                  }
                }}
                placeholder={me?.isMuted ? 'You are muted…' : 'Type a message…'}
                disabled={me?.isMuted}
                rows={1}
                className="w-full resize-none max-h-32 bg-white/5 border border-blue-400/20 focus:border-blue-400/60 focus:outline-none rounded-2xl px-4 py-2.5 text-sm text-blue-50 placeholder:text-blue-300/40 disabled:opacity-60"
                style={{ minHeight: '40px' }}
              />
            </div>

            <button
              onClick={onSendText}
              disabled={!input.trim() || me?.isMuted}
              className="p-2.5 rounded-2xl mhc-gradient-btn text-white disabled:opacity-40 shadow-lg"
              title="Send"
            >
              <Send size={18} />
            </button>
          </div>
        )}
      </div>

      {/* Members panel (drawer on mobile, slide-in on desktop) */}
      {(showMembers || true) && (
        <MembersPanel
          members={onlineMembers}
          me={me}
          open={showMembers}
          onClose={() => setShowMembers(false)}
        />
      )}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 mhc-glass-strong px-4 py-2 rounded-xl text-sm text-blue-100 shadow-2xl max-w-[90vw] mhc-anim-fade-up">
          {toast}
        </div>
      )}

      {/* Modals */}
      <ReportDialog open={!!reportTarget} onOpenChange={(v) => !v && setReportTarget(null)} messageId={reportTarget} />
      <MediaPreviewWindow msg={preview} onClose={() => setPreview(null)} />
      <GuidelinesDialog open={showGuidelines} onOpenChange={setShowGuidelines} />
      <InviteDialog open={showInvite} onOpenChange={setShowInvite} />
      {me?.isAdmin && <AdminDashboard open={showAdmin} onOpenChange={setShowAdmin} />}
    </div>
  )
}

function IconBtn({ children, onClick, title, disabled }: any) {
  return (
    <button
      onClick={onClick}
      title={title}
      disabled={disabled}
      className="p-2 rounded-lg hover:bg-white/10 text-blue-200 disabled:opacity-40 disabled:cursor-not-allowed"
    >
      {children}
    </button>
  )
}

function MembersPanel({
  members,
  me,
  open,
  onClose,
}: {
  members: PresenceMember[]
  me: MeUser | null
  open: boolean
  onClose: () => void
}) {
  return (
    <>
      {/* Desktop side panel */}
      <aside className="hidden md:flex flex-col w-60 lg:w-72 mhc-glass border-l border-blue-400/15 absolute right-0 top-[57px] bottom-[64px] z-20">
        <MembersList members={members} me={me} />
      </aside>
      {/* Mobile drawer */}
      {open && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          <div className="flex-1 bg-black/60" onClick={onClose} />
          <aside className="w-72 mhc-glass-strong border-l border-blue-400/20 flex flex-col">
            <div className="flex items-center justify-between p-3 border-b border-white/10">
              <span className="text-sm font-semibold text-blue-100">Members</span>
              <button onClick={onClose} className="p-1 text-blue-300"><X size={16} /></button>
            </div>
            <MembersList members={members} me={me} />
          </aside>
        </div>
      )}
    </>
  )
}

function MembersList({ members, me }: { members: PresenceMember[]; me: MeUser | null }) {
  const sorted = useMemo(() => {
    return [...members].sort((a, b) => {
      if (a.isAdmin && !b.isAdmin) return -1
      if (!a.isAdmin && b.isAdmin) return 1
      return a.displayName.localeCompare(b.displayName)
    })
  }, [members])
  return (
    <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
      <div className="text-xs uppercase tracking-wider text-blue-300/70 mb-2">Online · {members.length}</div>
      {sorted.length === 0 ? (
        <div className="text-xs text-blue-300/50 italic">No one online.</div>
      ) : (
        sorted.map((m) => (
          <div key={m.userId} className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-white/5">
            <div className="relative">
              { }
              <img src={m.avatarUrl} alt={m.displayName} className="w-8 h-8 rounded-full object-cover" />
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-[#0c1338]" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1">
                <span className="text-sm text-blue-100 truncate">{m.displayName}</span>
                {m.isAdmin && m.isVerified && <VerifiedBadge size={11} />}
              </div>
              <div className="text-[10px] text-blue-300/60 truncate">@{m.username}</div>
            </div>
            {m.userId === me?.id && <span className="text-[10px] text-blue-300/50 italic">you</span>}
          </div>
        ))
      )}
    </div>
  )
}
