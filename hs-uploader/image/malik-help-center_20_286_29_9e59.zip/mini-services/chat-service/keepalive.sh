#!/bin/bash
# Keep the chat-service alive forever
cd /home/z/my-project/mini-services/chat-service
while true; do
  echo "[$(date)] Starting chat-service..."
  bun index.ts
  echo "[$(date)] Chat-service exited, restarting in 2s..."
  sleep 2
done
