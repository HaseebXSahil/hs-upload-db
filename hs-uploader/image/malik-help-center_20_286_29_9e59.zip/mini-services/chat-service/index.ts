/**
 * Malik Help Center — Real-time WebSocket service (Socket.io)
 *
 * Responsibilities:
 *  - Authenticate socket connections via session token (verified against DB).
 *  - Broadcast chat events: message-new, message-update, message-delete.
 *  - Track online members & broadcast presence.
 *  - Emit typing indicators.
 *  - Forward reaction events.
 *
 * Port: 3003 (must match the gateway XTransformPort convention).
 *
 * Security:
 *  - Every connection requires a valid session token issued by the Next.js API.
 *  - Banned users are rejected.
 *  - Muted users can listen but cannot send (send attempts are rejected server-side here too as defense in depth).
 */
import { createServer } from 'http'
import { Server, Socket } from 'socket.io'
import { PrismaClient } from '@prisma/client'
import { config } from 'dotenv'
import { resolve, dirname, join } from 'path'
import { existsSync, mkdirSync, writeFileSync, accessSync, constants } from 'fs'
import { homedir, tmpdir } from 'os'
import crypto from 'crypto'

// ---------- 1. Find project root ----------
function findProjectRoot(): string {
  let dir = process.cwd()
  for (let i = 0; i < 12; i++) {
    if (existsSync(join(dir, 'package.json')) && existsSync(join(dir, 'prisma'))) {
      return dir
    }
    const parent = dirname(dir)
    if (parent === dir) break
    dir = parent
  }
  return process.cwd()
}

const PROJECT_ROOT = findProjectRoot()

// ---------- 2. Load .env ----------
;[
  resolve(PROJECT_ROOT, '.env'),
  resolve(process.cwd(), '.env'),
].forEach((p) => {
  try { config({ path: p }) } catch {}
})

// ---------- 3. Resolve DB file path ----------
function toForwardSlashes(p: string): string {
  return p.replace(/\\/g, '/')
}

function resolveDbFile(): string {
  const envVal = process.env.DATABASE_URL
  if (envVal && envVal.startsWith('file:')) {
    let pathPart = envVal.slice(5)
    if (pathPart.startsWith('/') || /^[A-Za-z]:[\\/]/.test(pathPart)) {
      return resolve(pathPart)
    }
    return resolve(PROJECT_ROOT, pathPart)
  }
  return resolve(PROJECT_ROOT, 'db', 'custom.db')
}

function tryCreateDb(dbFile: string): boolean {
  try {
    const dir = dirname(dbFile)
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
    if (!existsSync(dbFile)) writeFileSync(dbFile, '')
    accessSync(dbFile, constants.W_OK | constants.R_OK)
    return true
  } catch (e) {
    return false
  }
}

let dbFilePath = resolveDbFile()
if (!tryCreateDb(dbFilePath)) {
  console.warn('[chat-service] Could not create DB at project path, falling back to home directory')
  dbFilePath = resolve(homedir(), '.malik-help-center', 'db', 'custom.db')
  if (!tryCreateDb(dbFilePath)) {
    console.warn('[chat-service] Falling back to temp directory')
    dbFilePath = resolve(tmpdir(), 'malik-help-center-db', 'custom.db')
    tryCreateDb(dbFilePath)
  }
}

const DATABASE_URL = `file:${toForwardSlashes(dbFilePath)}`

const db = new PrismaClient({
  datasourceUrl: DATABASE_URL,
  log: ['error'],
})

const SESSION_SECRET = process.env.SESSION_SECRET || 'malik-help-center-default-secret'
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'malik__mushahid'

function hashToken(token: string): string {
  return crypto.createHmac('sha256', SESSION_SECRET).update(token).digest('hex')
}

interface OnlineUser {
  userId: string
  username: string
  displayName: string
  avatarUrl: string
  isAdmin: boolean
  isVerified: boolean
  socketIds: Set<string>
}

const online = new Map<string, OnlineUser>()

const httpServer = createServer()
const io = new Server(httpServer, {
  path: '/',
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
  maxHttpBufferSize: 1e6, // 1MB — payloads are URLs not blobs
})

async function authenticate(socket: Socket, token: string): Promise<OnlineUser | null> {
  if (!token) return null
  const session = await db.session.findUnique({
    where: { token: hashToken(token) },
    include: { user: true },
  })
  if (!session || session.revoked || session.expiresAt.getTime() < Date.now()) return null
  if (session.user.isBanned) return null
  return {
    userId: session.user.id,
    username: session.user.username,
    displayName: session.user.displayName,
    avatarUrl: session.user.avatarUrl,
    isAdmin: session.user.isAdmin,
    isVerified: session.user.isVerified,
    socketIds: new Set(),
  }
}

function broadcastOnlineCount() {
  io.emit('presence:update', {
    onlineCount: online.size,
    members: Array.from(online.values()).map((u) => ({
      userId: u.userId,
      username: u.username,
      displayName: u.displayName,
      avatarUrl: u.avatarUrl,
      isAdmin: u.isAdmin,
      isVerified: u.isVerified,
    })),
  })
}

io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth?.token as string | undefined
    const user = await authenticate(socket, token)
    if (!user) {
      return next(new Error('unauthorized'))
    }
    ;(socket as any).user = user
    next()
  } catch (e) {
    next(new Error('unauthorized'))
  }
})

io.on('connection', (socket) => {
  const user = (socket as any).user as OnlineUser
  if (!user) {
    socket.disconnect(true)
    return
  }
  user.socketIds.add(socket.id)
  if (!online.has(user.userId)) {
    online.set(user.userId, user)
  } else {
    // merge socketIds
    const existing = online.get(user.userId)!
    existing.socketIds.add(socket.id)
  }
  // Refresh user record from DB to get latest mute/ban/admin flags
  db.user.findUnique({ where: { id: user.userId } }).then((u) => {
    if (u) {
      user.isAdmin = u.isAdmin
      user.isVerified = u.isVerified
      user.username = u.username
      user.displayName = u.displayName
      user.avatarUrl = u.avatarUrl
      socket.emit('me:update', {
        userId: u.id,
        username: u.username,
        displayName: u.displayName,
        avatarUrl: u.avatarUrl,
        isAdmin: u.isAdmin,
        isVerified: u.isVerified,
        isMuted: u.isMuted,
        isBanned: u.isBanned,
        muteReason: u.muteReason,
      })
      broadcastOnlineCount()
    }
  })

  // Join the single community room
  socket.join('community')

  socket.emit('hello', {
    userId: user.userId,
    username: user.username,
    displayName: user.displayName,
    avatarUrl: user.avatarUrl,
    isAdmin: user.isAdmin,
    isVerified: user.isVerified,
  })

  // typing indicator
  socket.on('typing:start', () => {
    socket.to('community').emit('typing:start', { userId: user.userId, username: user.displayName })
  })
  socket.on('typing:stop', () => {
    socket.to('community').emit('typing:stop', { userId: user.userId })
  })

  // reaction broadcast
  socket.on('reaction:toggle', (data: { messageId: string; emoji: string }) => {
    socket.to('community').emit('reaction:toggle', {
      messageId: data.messageId,
      emoji: data.emoji,
      userId: user.userId,
      username: user.displayName,
    })
  })

  // presence ping
  socket.on('presence:ping', () => {
    db.user.update({ where: { id: user.userId }, data: { lastSeenAt: new Date() } }).catch(() => {})
  })

  socket.on('disconnect', () => {
    const entry = online.get(user.userId)
    if (entry) {
      entry.socketIds.delete(socket.id)
      if (entry.socketIds.size === 0) {
        online.delete(user.userId)
      }
    }
    broadcastOnlineCount()
  })
})

const PORT = 3003
httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`[Malik Help Center] WebSocket server running on port ${PORT}`)
})

// Keep the bun process alive explicitly (defense against bun's auto-exit)
const keepAlive = setInterval(() => {}, 1 << 30)

process.on('SIGTERM', () => {
  clearInterval(keepAlive)
  httpServer.close(() => process.exit(0))
})
process.on('SIGINT', () => {
  clearInterval(keepAlive)
  httpServer.close(() => process.exit(0))
})
