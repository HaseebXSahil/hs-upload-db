#!/bin/bash
# Start the Malik Help Center chat-service (WebSocket) and keep it running.
cd /home/z/my-project/mini-services/chat-service

# Wait for the parent's Prisma client to be available
if [ ! -d "/home/z/my-project/node_modules/@prisma/client" ]; then
  echo "ERROR: parent @prisma/client not found"
  exit 1
fi

# Ensure node_modules links exist
mkdir -p node_modules
[ -L node_modules/@prisma ] || ln -sf /home/z/my-project/node_modules/@prisma node_modules/@prisma
[ -L node_modules/.prisma ] || ln -sf /home/z/my-project/node_modules/.prisma node_modules/.prisma

# Start in foreground so the process supervisor doesn't kill it
exec bun index.ts
