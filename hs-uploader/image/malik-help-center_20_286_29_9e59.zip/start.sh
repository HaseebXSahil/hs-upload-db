#!/bin/bash
# ============================================================
# Start Malik Help Center — Restart Script
# ============================================================
# Use this if services stopped or after computer restart.
# ============================================================

cd "$(dirname "$0")"
PROJECT_DIR="$(pwd)"

echo "🚀 Starting Malik Help Center..."
echo "================================"
echo ""

# Make sure directories + db file exist
mkdir -p db
mkdir -p public/uploads/avatars
mkdir -p public/uploads/media
touch db/custom.db
echo "✅ Directories + db file ready"

# Make sure .env exists
if [ ! -f ".env" ]; then
  echo "⚠️  .env not found. Running setup.sh first..."
  ./setup.sh
  exit 0
fi

# ---------- 1. Start chat-service ----------
echo "▶️  Starting chat-service (port 3003)..."
pkill -f "bun.*chat-service/index" 2>/dev/null
pkill -f "tsx.*chat-service/index" 2>/dev/null
sleep 1

cd mini-services/chat-service
mkdir -p node_modules
if [ -d "$PROJECT_DIR/node_modules/@prisma" ]; then
  rm -rf node_modules/@prisma 2>/dev/null
  cp -r "$PROJECT_DIR/node_modules/@prisma" node_modules/@prisma
fi
if [ -d "$PROJECT_DIR/node_modules/.prisma" ]; then
  rm -rf node_modules/.prisma 2>/dev/null
  cp -r "$PROJECT_DIR/node_modules/.prisma" node_modules/.prisma
fi
cd "$PROJECT_DIR"

if command -v bun &> /dev/null; then
  setsid -f bun mini-services/chat-service/index.ts > "$PROJECT_DIR/chat-service.log" 2>&1 < /dev/null
  echo "   ✅ Started chat-service with bun"
else
  setsid -f npx tsx mini-services/chat-service/index.ts > "$PROJECT_DIR/chat-service.log" 2>&1 < /dev/null
  echo "   ✅ Started chat-service with tsx"
fi
sleep 3
echo ""

# ---------- 2. Start Next.js ----------
echo "▶️  Starting Next.js dev server (port 3000)..."
pkill -f "next dev" 2>/dev/null
sleep 1

if command -v bun &> /dev/null; then
  nohup bun run dev > "$PROJECT_DIR/dev.log" 2>&1 &
  WEB_PID=$!
  echo "   ✅ Started Next.js with bun (PID: $WEB_PID)"
else
  nohup npm run dev > "$PROJECT_DIR/dev.log" 2>&1 &
  WEB_PID=$!
  echo "   ✅ Started Next.js with npm (PID: $WEB_PID)"
fi
sleep 5
echo ""

# ---------- 3. Show status ----------
echo "================================"
echo "🎉 Malik Help Center is running!"
echo ""
echo "   📱 Frontend:  http://localhost:3000"
echo "   🔌 WebSocket: ws://localhost:3003"
echo ""
echo "   👑 Admin Username:    malik__mushahid"
echo "   🔑 Admin Password:    khan@1373"
echo ""
echo "   Logs:"
echo "     - Frontend:    tail -f dev.log"
echo "     - Chat-service: tail -f chat-service.log"
echo ""
echo "   To stop: pkill -f 'next dev'; pkill -f 'bun.*chat-service'"
echo "================================"
echo ""
echo "Opening browser in 3 seconds..."
sleep 3

if command -v xdg-open &> /dev/null; then
  xdg-open http://localhost:3000
elif command -v open &> /dev/null; then
  open http://localhost:3000
fi
