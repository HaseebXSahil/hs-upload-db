# 🚀 Malik Help Center — Ready to Deploy!

Aap ka project **100% ready** hai. Kuch bhi change karne ki zaroorat nahi.

---

## 📦 Step 1: ZIP Extract karein

```bash
unzip malik-help-center.zip
cd malik-help-center
```

## ▶️ Step 2: Setup Script Run Karein

### Linux / Mac / WSL:
```bash
chmod +x setup.sh
./setup.sh
```

### Windows:
Windows pe WSL (Windows Subsystem for Linux) use karein ya phir Git Bash (https://gitforwindows.org) mein `./setup.sh` run karein.

Setup script automatically:
- ✅ `.env` file banayega
- ✅ Database directory + file banayega
- ✅ Database schema initialize karega
- ✅ Dependencies install karega
- ✅ WebSocket service start karega (port 3003)
- ✅ Next.js dev server start karega (port 3000)

## 🌐 Step 3: Browser mein kholen

**http://localhost:3000**

Bas! Website live ho gayi. 🎉

---

## 👑 Admin Login (sab kuch already set hai)

| Field | Value |
|-------|-------|
| **Username** | `malik__mushahid` |
| **Password** | `khan@1373` |

### Admin Login Steps:
1. Website kholen → http://localhost:3000
2. Username field mein likhein: `malik__mushahid`
   - **Note**: Do underscore hai (`__`)
3. Jaise hi username likhenge, **password field automatically aa jayega**
4. Password field mein likhein: `khan@1373`
5. Profile picture upload karein (pehli baar zaroori, re-login pe nahi)
6. **"Login as Admin"** button pe click karein
7. Robot verification animation chalegi (5-10 seconds)
8. "Verification Complete! Welcome to the Malik Help Center" message aayega
9. Aap admin hoon with **REAL BLUE TICK** ✅

---

## 👤 User Login (admin ke liye nahi)

1. Username likhein (koi bhi unique name)
2. Profile picture upload karein (pehli baar)
3. **"Enter Chat"** pe click karein
4. Bas! User ban gaya — **koi password nahi chahiye**

### Logout karne ke baad:
- Same username se dobara login karein
- Avatar dobara upload karne ki zaroorat nahi

---

## 🆘 Agar "Unable to open the database file" error aaye

Yeh fix hai:

### Solution 1: Setup.sh dobara run karein
```bash
./setup.sh
```

### Solution 2: Manual fix
```bash
cd malik-help-center
mkdir -p db
touch db/custom.db
# Delete .next cache (important!)
rm -rf .next
# Restart
./start.sh
```

### Solution 3: Poora fresh start
```bash
cd malik-help-center
rm -rf .next db/custom.db node_modules
./setup.sh
```

**Note**: db.ts ab automatically:
- Project root dhoondhta hai (cwd se)
- DB directory aur file banata hai agar nahi hain
- Agar project directory writable nahi hai to home directory use karta hai
- Windows ke liye path slashes normalize karta hai

---

## 🆘 Agar WebSocket "Reconnecting…" dikhaye

```bash
./start.sh
```

Yeh dono services (Next.js + Chat-service) restart kar dega.

---

## 🆘 Agar "Username already taken" error aaye

Pehle se account bana hua hai. Same username se dobara login karein (avatar ki zaroorat nahi).

---

## ✅ Sab kuch Already Configured Hai

- ✅ Admin username: `malik__mushahid`
- ✅ Admin password: `khan@1373`
- ✅ Database: auto-resolved (bulletproof — works on any OS)
- ✅ Session secret: 96-char strong random (already set)
- ✅ All API endpoints working
- ✅ WebSocket service configured
- ✅ Real blue verified tick for admin
- ✅ Premium design ready
- ✅ All features tested

---

## 🌍 Production Deploy (VPS / Cloud)

```bash
# Server pe ZIP upload karein aur extract karein
unzip malik-help-center.zip
cd malik-help-center

# Setup run karein
chmod +x setup.sh
./setup.sh
```

### Sirf yeh change karein production ke liye:

`.env` file edit karein aur `PUBLIC_BASE_URL` ko apne domain pe set karein:

```env
PUBLIC_BASE_URL=https://aapka-domain.com
```

---

## 📞 Help

Agar koi masla ho:
1. **`ADMIN_CREDENTIALS.txt`** — Admin login details
2. **`README.md`** — Complete technical documentation
3. **`dev.log`** — Frontend errors
4. **`chat-service.log`** — WebSocket errors

**Enjoy your premium community chat! 🎉**

— Built with ❤️ for Malik Help Center
