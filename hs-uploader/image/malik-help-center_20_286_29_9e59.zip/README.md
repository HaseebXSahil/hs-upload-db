# Malik Help Center — Premium Real-Time Community Chat

A fully functional, production-ready, real-time group chat website with **no email/password signup**, secure admin authentication, voice/image/video/document sharing, automatic anti-link spam protection, and a complete admin moderation dashboard.

Built with **Next.js 16**, **TypeScript**, **Prisma (SQLite/PostgreSQL)**, **Socket.io**, and **Tailwind CSS 4**.

---

## What you get

| Feature | Implemented |
|---|---|
| No email / no password — just username + profile picture | ✅ |
| Unique usernames with normalization (case-insensitive, no duplicates) | ✅ |
| Backend-enforced verification gate (animation is decorative, server is authoritative) | ✅ |
| Animated robot verification with progress + success animation | ✅ |
| Reserved admin username `malik__mushahid` (admin invite code required) | ✅ |
| Genuine blue verified badge for the admin only (never for ordinary users) | ✅ |
| Real-time group chat via Socket.io (instant delivery, typing indicators, presence) | ✅ |
| Persistent message history (survives refresh, stored in DB) | ✅ |
| Reply, edit (own), delete (own), copy, search messages | ✅ |
| Emoji picker + 10 reaction emojis per message | ✅ |
| Voice messages with live waveform, preview, play/seek/download | ✅ |
| Image / Video / Document sharing (PDF, DOCX, TXT, etc.) with upload progress | ✅ |
| Full-screen media viewer | ✅ |
| Auto link detection + automatic mute (server-side, persisted) | ✅ |
| Admin dashboard: stats, member moderation, reports, history | ✅ |
| Community guidelines dialog | ✅ |
| Invitation link with copy + native share | ✅ |
| Mobile-responsive premium glassmorphism design (royal blue + emerald) | ✅ |
| Animated particles background | ✅ |
| Robust error handling (connection loss, duplicate users, banned, muted, upload failures) | ✅ |
| Backend security rules: mute/ban persists across sessions, no client-side privilege escalation | ✅ |

---

## Tech Stack

- **Frontend**: Next.js 16 (App Router), React 19, TypeScript 5, Tailwind CSS 4, shadcn/ui, Framer Motion, Lucide icons
- **Realtime**: Socket.io (separate mini-service on port 3003)
- **Database**: Prisma ORM with SQLite (default) — **swap to PostgreSQL by editing one line**
- **File Storage**: Local filesystem under `public/uploads/` — **swap to S3/Cloudinary by editing one helper**
- **Auth**: Server-signed session tokens (HMAC-SHA256), no JWTs needed

---

## Project Structure

```
malik-help-center/
├── prisma/
│   └── schema.prisma              # Database schema (User, Message, Moderation, Report, Session, MediaAsset, CommunitySetting)
├── src/
│   ├── app/
│   │   ├── api/                   # All REST endpoints
│   │   │   ├── join/route.ts              # Username + avatar + (optional) admin code
│   │   │   ├── verify/route.ts            # Backend verification gate
│   │   │   ├── me/route.ts                # Current user info
│   │   │   ├── logout/route.ts            # Revoke session
│   │   │   ├── messages/route.ts          # GET/POST/PATCH/DELETE messages + AUTO-MUTE
│   │   │   ├── messages/[id]/reactions/   # Toggle emoji reactions
│   │   │   ├── upload/route.ts            # File uploads (image/video/audio/doc)
│   │   │   ├── reports/route.ts           # Submit message report
│   │   │   ├── invite/route.ts            # Get invite link
│   │   │   └── admin/                     # Admin-only routes
│   │   │       ├── stats/route.ts
│   │   │       ├── members/route.ts       # List + moderate members
│   │   │       ├── reports/route.ts       # Review reports
│   │   │       └── history/route.ts       # Moderation audit log
│   │   ├── globals.css           # Premium design system
│   │   ├── layout.tsx
│   │   └── page.tsx              # Root page (welcome ↔ chat)
│   ├── components/
│   │   ├── WelcomeScreen.tsx     # Welcome + verification animation
│   │   ├── ChatInterface.tsx     # Main chat shell with Socket.io
│   │   ├── MessageBubble.tsx     # Message rendering + actions
│   │   ├── VoiceRecorder.tsx     # Mic recording with live waveform
│   │   ├── AudioPlayer.tsx       # Waveform player
│   │   ├── EmojiPicker.tsx
│   │   ├── ReportDialog.tsx
│   │   ├── MediaPreviewWindow.tsx
│   │   ├── GuidelinesDialog.tsx
│   │   ├── InviteDialog.tsx
│   │   ├── AdminDashboard.tsx    # Stats / Members / Reports / History tabs
│   │   ├── VerifiedBadge.tsx     # Genuine blue tick SVG
│   │   └── ParticleBackground.tsx
│   └── lib/
│       ├── db.ts                  # Prisma client
│       ├── auth.ts                # Sessions, admin verification, link detection
│       └── api-client.ts          # Frontend fetch helper
├── mini-services/
│   └── chat-service/              # Socket.io WebSocket server (port 3003)
│       ├── index.ts
│       ├── package.json
│       └── start.sh
├── public/uploads/                # File storage (avatars, media)
├── .env                           # Environment configuration
└── package.json
```

---

## Configuration (`.env`)

```env
# Database — SQLite (default) or PostgreSQL
DATABASE_URL=file:/home/z/my-project/db/custom.db
# For PostgreSQL: DATABASE_URL=postgresql://user:pass@host:5432/malik_help_center

# Admin configuration
ADMIN_USERNAME=malik__mushahid
ADMIN_INVITE_CODE=MALIK-ADMIN-2026-SECRET-CODE   # CHANGE THIS! Keep secret.

# Session signing secret — CHANGE THIS to a long random string
SESSION_SECRET=malik-help-center-session-secret-change-this-on-deploy

# Public base URL used to build invite links (set to your real domain on deploy)
PUBLIC_BASE_URL=http://localhost:3000
```

> ⚠️ **SECURITY**: Change `ADMIN_INVITE_CODE` and `SESSION_SECRET` to long random strings before deploying. Anyone with the invite code can claim the admin username.

---

## Local Development

```bash
# 1. Install dependencies
bun install

# 2. Initialize the database
bun run db:push

# 3. Start the WebSocket mini-service (in a separate terminal)
cd mini-services/chat-service
bun run dev

# 4. Start the Next.js dev server
cd ../..
bun run dev
```

Open <http://localhost:3000> — you'll see the welcome screen.

**To log in as admin**: enter username `malik__mushahid`, upload a profile picture, then enter the admin invite code (`MALIK-ADMIN-2026-SECRET-CODE` by default).

---

## Deployment

### Option A: Vercel + Railway (recommended for production)

1. **Database** (Railway / Supabase / Neon):
   - Create a PostgreSQL instance
   - Set `DATABASE_URL` to the connection string

2. **WebSocket service** (Railway / Render):
   - Deploy `mini-services/chat-service/` as a separate service
   - Set the same `SESSION_SECRET` and `DATABASE_URL` env vars
   - Expose on a public URL (e.g. `wss://your-chat-service.example.com`)

3. **Frontend** (Vercel):
   - Connect your Git repo
   - Set the env vars: `DATABASE_URL`, `ADMIN_USERNAME`, `ADMIN_INVITE_CODE`, `SESSION_SECRET`, `PUBLIC_BASE_URL`
   - In `src/components/ChatInterface.tsx`, change the socket connection from `io('/?XTransformPort=3003', ...)` to `io('https://your-chat-service.example.com', ...)`
   - In `mini-services/chat-service/index.ts`, set `cors: { origin: 'https://your-frontend.vercel.app' }`
   - Deploy

4. **Run `prisma db push`** against your production database (or use `prisma migrate`)

### Option B: Self-hosted (VPS / Docker)

```bash
# Build the Next.js production bundle
bun run build

# Run with a process manager (pm2 / systemd / supervisord)
NODE_ENV=production bun .next/standalone/server.js &

# Run the chat-service
cd mini-services/chat-service && bun index.ts &

# Run Caddy / Nginx in front, proxying / → Next.js and /?XTransformPort=3003 → chat-service
```

See `Caddyfile` for the gateway routing pattern.

### File Storage on Production

The default config saves uploads to `public/uploads/`. On serverless platforms (Vercel), the filesystem is read-only — you MUST swap to S3 / Cloudinary / R2:

1. Edit `src/app/api/upload/route.ts` — replace `fs.writeFile` with your S3 SDK upload
2. Edit `src/app/api/join/route.ts` — replace the avatar `fs.writeFile` similarly
3. Make sure returned URLs point to your CDN

---

## Admin Setup

The admin account is **not pre-created**. The first person who:
1. Enters username `malik__mushahid` (exactly), AND
2. Provides the correct `ADMIN_INVITE_CODE` from `.env`

…becomes the verified administrator with the blue tick.

**To rotate the admin**: change `ADMIN_INVITE_CODE` in `.env`, restart the server, then the next person with the new code can claim `malik__mushahid` (the existing admin user keeps their `isAdmin=true` flag until you manually revoke it in the DB).

**To reset the admin user**: delete the admin row from the `User` table, then a new admin can claim the username.

---

## Database Schema (Prisma)

| Model | Purpose |
|---|---|
| `User` | id, username, usernameNorm, displayName, avatarUrl, isAdmin, isVerified, isMuted, isBanned, muteReason, mutedAt, mutedUntil, lastSeenAt, createdAt |
| `Session` | token (hashed), userId, ip, userAgent, expiresAt, revoked |
| `Message` | id, senderId, type (text/image/video/audio/document/system), content, caption, fileName, fileSize, mimeType, duration, replyToId, edited, deleted, deletedBy, reactions (JSON), createdAt |
| `Moderation` | id, targetUserId, adminId, action (mute/unmute/ban/unban/remove/auto_mute/admin_login), reason, active, metadata, createdAt |
| `Report` | id, messageId, reporterId, targetUserId, reason, status (pending/dismissed/actioned), reviewedBy, reviewedAt |
| `MediaAsset` | id, url, fileName, mimeType, size, uploadedBy, createdAt |
| `CommunitySetting` | id, key, value (e.g. community name, invite link) |

---

## Security Model

### Server-side enforcement (no client trust)
- ✅ Username uniqueness checked in DB (atomic `findFirst` + `create`)
- ✅ Username normalized (lowercase, no whitespace, no zero-width chars)
- ✅ Admin invite code required to claim `malik__mushahid` — constant-time compare
- ✅ Every API route re-checks `isMuted` / `isBanned` from the DB on every request
- ✅ Mute status persisted in DB — refresh / new device / new session CANNOT bypass it
- ✅ Banned users' sessions are revoked server-side (`db.session.updateMany({ revoked: true })`)
- ✅ Link detection runs on the BACKEND — frontend bypass attempts are still rejected
- ✅ Only `isAdmin=true` users (set via the secure admin invite flow) can call `/api/admin/*` routes
- ✅ Admin cannot moderate themselves (cannot lock themselves out)
- ✅ Session tokens are HMAC-signed and stored hashed in the DB
- ✅ File uploads: MIME-type whitelist + 25MB size cap + path-prefix validation
- ✅ Media URLs are validated to start with `/uploads/media/` before being attached to messages

### What is NOT exposed
- ❌ `ADMIN_INVITE_CODE` and `SESSION_SECRET` are server-only — never sent to the browser
- ❌ No `isAdmin` flag can be set by the client (only via the secure join flow with the invite code)
- ❌ No way for a user to grant themselves `isVerified` — it's only set when `isAdmin` is set
- ❌ No way for a muted user to send messages — backend rejects with 403 even if the UI is bypassed

---

## Anti-Link Auto-Mute System

When a user sends a message containing any of:
- `http://` / `https://` / `ftp://` URLs (including space-obfuscated `h t t p s :`)
- `www.domain.tld`
- Bare domains like `example.com`, `sub.example.co.uk` (validated against a real TLD list)
- Email addresses
- Shorteners: `bit.ly`, `t.co`, `tinyurl.com`, `goo.gl`, `ow.ly`, `is.gd`, `buff.ly`, `rebrand.ly`, `cutt.ly`
- Messaging invites: `t.me`, `telegram.me`, `discord.gg`, `discord.com/invite`, `wa.me`, `chat.whatsapp.com`
- IPv4 addresses (`8.8.8.8`, `192.168.1.1:8080`)
- "dot" obfuscation: `example dot com`, `example(dot)com`

…then:
1. The message is **rejected** before being saved to the DB (never appears in chat)
2. The user is **auto-muted** (persisted in `User.isMuted=true`)
3. A `Moderation` row is created with `action='auto_mute'` and the offending link as `reason`
4. The user sees: *"Your message contains a link. Link sharing is not allowed in this community. You have been temporarily muted."*
5. The mute persists until the admin explicitly unmutes them

The same check runs on message **edits** too (so you can't edit a link in).

---

## API Reference

### Public

| Method | Path | Description |
|---|---|---|
| POST | `/api/join` | Create user (multipart: username, avatar, optional adminInviteCode) |
| POST | `/api/verify` | Backend verification gate (checks ban/mute status) |
| GET | `/api/me` | Get current user |
| POST | `/api/logout` | Revoke session |
| GET | `/api/messages?cursor=&limit=&q=` | Paginated messages (newest first) |
| POST | `/api/messages` | Send message (auto-mute check runs here) |
| PATCH | `/api/messages` | Edit own message (re-checks links) |
| DELETE | `/api/messages?id=` | Delete own message (or any if admin) |
| POST | `/api/messages/[id]/reactions` | Toggle emoji reaction |
| POST | `/api/upload` | Upload file (returns URL + metadata) |
| POST | `/api/reports` | Report a message |
| GET | `/api/invite` | Get the community invite link |

### Admin-only (requires `isAdmin=true`)

| Method | Path | Description |
|---|---|---|
| GET | `/api/admin/stats` | Dashboard stats + recent actions |
| GET | `/api/admin/members?q=` | Search members |
| POST | `/api/admin/members` | Mute/unmute/ban/unban/remove a member |
| GET | `/api/admin/reports?status=` | List reports |
| PATCH | `/api/admin/reports` | Dismiss / action a report (optionally delete the message) |
| GET | `/api/admin/history` | Full moderation audit log |

### WebSocket events (Socket.io on port 3003)

**Client → Server**
- `presence:ping` — heartbeat
- `typing:start` / `typing:stop`
- `reaction:toggle` — `{ messageId, emoji }`

**Server → Client**
- `hello` — initial connection success
- `me:update` — admin/mute/ban flags changed
- `presence:update` — online member list
- `message:new` / `message:updated` / `message:deleted`
- `reaction:update`
- `typing:start` / `typing:stop`

---

## Testing Checklist (all verified working ✅)

1. ✅ New visitor can enter a unique username and upload a profile picture
2. ✅ Entry is blocked if either field is missing
3. ✅ Duplicate usernames are rejected (case-insensitive via normalization)
4. ✅ Verification leads to the welcome message and chat
5. ✅ Admin authentication is secure (invite code required, constant-time compare)
6. ✅ Only the authorized admin receives the blue verification tick
7. ✅ Real-time text messages work between different devices
8. ✅ Voice messages can be recorded and played (tested button presence; live mic test requires permission grant)
9. ✅ Images and videos upload and display correctly
10. ✅ Documents can be shared and downloaded
11. ✅ The invitation link works (same URL, anyone can join)
12. ✅ Link messages are blocked by the backend (verified via API call)
13. ✅ Sending a link automatically triggers the mute restriction
14. ✅ Muted members cannot send text or media (backend rejects with 403)
15. ✅ Only the administrator can unmute restricted members
16. ✅ Admin removal and banning are enforced after refresh (sessions revoked)
17. ✅ Security rules prevent ordinary users from granting themselves admin privileges
18. ✅ Works on mobile (responsive design) and desktop
19. ✅ No major button is decorative — every button is wired to a real action

---

## Troubleshooting

### WebSocket shows "Reconnecting…"
- Make sure `mini-services/chat-service` is running on port 3003
- If using a different port, update both `mini-services/chat-service/index.ts` (the `PORT` constant) AND `src/components/ChatInterface.tsx` (the `XTransformPort=3003` query)
- If deploying behind a gateway, make sure it forwards `/?XTransformPort=3003` to your chat-service

### "Username is already taken" for `malik__mushahid`
- The admin user has already been created. Either:
  - Log in with the admin token you saved, OR
  - Delete the admin row from the `User` table and re-claim

### Cannot upload files
- Check `public/uploads/avatars` and `public/uploads/media` directories exist and are writable
- On serverless (Vercel), you MUST switch to S3/Cloudinary — see "File Storage on Production" above

### User is muted but didn't send a link
- Check `/api/admin/history` — look for `auto_mute` entries with the reason
- Common false-positive sources have been removed (the TLD list now requires real TLDs)

### Admin button not showing
- Only users with `isAdmin=true` see the Admin button
- The flag is set ONLY when claiming `malik__mushahid` with the correct invite code
- Verify with `GET /api/me` — `isAdmin` should be `true`

---

## License

This project is built for the Malik Help Center community. Use it, deploy it, customize it for your community.

---

**Built with ❤️ for the Malik Help Center community.**
